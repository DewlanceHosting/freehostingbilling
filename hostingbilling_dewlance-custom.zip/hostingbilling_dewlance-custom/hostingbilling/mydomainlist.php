 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Domain Section</h3>

<style>
.entriessect {
    background: #036290;
    padding: 10px;
    color: #fff;
    border-top-right-radius: 10px;
    border-top-left-radius: 10px;
}
.entriessect h5 {
    font-size: 14px;
    margin-top: 10px;
}

.pagersect {
    padding: 10px;
    border: solid 1px #f9f9f9;
}
.pagersect h5 {
    font-size: 14px;
    margin-top: 6px;
}

.pagersect .pagination {
    display: inline-block;
    padding-left: 0;
    margin: 0px 0;
    border-radius: 4px;
}
</style>

<div class="entriessect">
<div class="row">
<div class="col-sm-9">
<h5>Show 1 to 4 of 4 entries</h5>
</div>
<div class="col-sm-3">
<div class="input-group">
  <input type="text" class="form-control" placeholder="Search..." aria-describedby="basic-addon2">
  <span class="input-group-addon" id="basic-addon2"><i class="fa fa-search" aria-hidden="true"></i></span>
</div>
</div>
</div>
</div>

<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
    <th></th>
      <th>Domain Name</th>
      <th>Date of Registration</th>
      <th>Next Due Date</th>
       <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    
    <td><input type="checkbox" /></td>
    
      <td>
    <h4> <a href="#">www.dewlance.com</a></h4>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td><button class="btn btn-danger form-control">Pending</button></td>
    </tr>
    
    <tr>
      <td><input type="checkbox" /></td>
      <td>
    <h4> <a href="#">www.dewlance.com</a></h4>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td><button class="btn btn-success form-control">Active</button></td>
    </tr>
    
        <tr>
    
    <td><input type="checkbox" /></td>
    
      <td>
    <h4> <a href="#">www.dewlance.com</a></h4>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td><button class="btn btn-danger form-control">Pending</button></td>
    </tr>
    
    <tr>
      <td><input type="checkbox" /></td>
      <td>
    <h4> <a href="#">www.dewlance.com</a></h4>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td><button class="btn btn-success form-control">Active</button></td>
    </tr>  
    
  </tbody>
</table>
</div>

<div class="pagersect">
<div class="row">
<div class="col-sm-9">
<h5>Showing <select style="color:#000;">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>10</option>
<option>11</option>
</select> entries</h5>
</div>
<div class="col-sm-3">
  <ul class="pagination pagination-sm pull-right">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</div>
</div>
</div>

</div> 

</div>

</section>


 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>