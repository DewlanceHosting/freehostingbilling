<?php         include_once('../fn/connect.php'); 
  
 if(isset($_POST['ProductNameSubmit']))
{
		 
		      $ProductName =  $_POST['ProductName'];
			//  $dp_code =  $_POST['dp_code'];
		  //  $status =  $_POST['status'];
		  //$created_by ="admin";
		  $created_date  = date("d-m-Y");
			 
        $result = mysqli_query($con,"SELECT * FROM productgroupadd"); while($row = mysqli_fetch_array($result))
      {
	   $val=$row['producname'];}
	   if($val != $ProductName){ 
		  
		if($ProductName==''){
		echo "<script>alert('any field is empty')</script>";
		exit();
		}  
		else{ 
		  
		$insert_query = "INSERT INTO `productgroupadd`(`producname`, `catManudate`, `status`)
															 VALUES ('$ProductName','$created_date','0')";
		$run = mysqli_query($con,$insert_query);
		if($run) {
		echo "<center> <img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Please wait while you are redirected in 1 seconds..</h6></center>"."<br />";
	header('Refresh:1; url=hostingproduct.php'); 
		}
	}
				  
  }else{ echo "This Product already exist";}
 }
 
 ////////////////////////////////Produc//////////////////////////////////////////////////////////////////
 //  '&Module='+ Module + '&pnameGroup='+ pnameGroup + '&descrip='+ descrip + '&Email='+ Email + '&domain='+ domain + '&PriceType='+ PriceType + '&Price='+ Price + '&BillingType='+ BillingType
 if(isset($_POST['Module']))
{
			    
			  $Module =  $_POST['Module'];
		      $pnameGroup =  $_POST['pnameGroup'];
		      $descrip = $_POST['descrip']; 
			  $Email =  $_POST['Email'];
			  $domain =  $_POST['domain'];
		      $PriceType =  $_POST['PriceType'];
		      $Price = $_POST['Price']; 
			  $BillingType =  $_POST['BillingType']; 
		      $created_date  = date("d-m-Y");
		     
			 
        $result = mysqli_query($con,"SELECT * FROM productadd"); while($row = mysqli_fetch_array($result))
      {
	     $val=$row['Module'];}
	   if($val != $Module){ 
		if($Module==''){
		echo "<script>alert('any field is empty')</script>";
		exit();
		}  
		else{
		 
		  $insert_query = "INSERT INTO `productadd` (`modulid`, `groupid`, `decrip`, `pemail`, `rdomailn`, `pricetype`, `price`, `billtype`, `adddate`, `status`) 
								VALUES ('$Module', '$pnameGroup', '$descrip', '$Email', '$domain', '$PriceType', '$Price', '$BillingType', '$created_date', '0')";
		
		$run = mysqli_query($con,$insert_query); 
		if($run) {
		echo "Produd Add Successfully"; 
		}echo"no";
	}
				  
  }else{ echo "This Product already exist";}
 }
 
 
 if(isset($_POST['UModule']))
{
			     $idData =  $_POST['idData'];
			  $Module =  $_POST['UModule'];
		      $pnameGroup =  $_POST['UpnameGroup'];
		      $descrip = $_POST['Udescrip']; 
			  $Email =  $_POST['UEmail'];
			  $domain =  $_POST['domain'];
		      $PriceType =  $_POST['PriceType'];
		      $Price = $_POST['UPrice']; 
			  $BillingType =  $_POST['UBillingType']; 
		      //$created_date  = date("d-m-Y"); 
		 
		  $insert_query = "UPDATE `productadd` SET `modulid`='$Module', `groupid`='$pnameGroup', `decrip`='$descrip', `pemail`='$Email', `rdomailn`='$domain', `pricetype`='$PriceType', `price`='$Price', `billtype`='$BillingType' WHERE `producid` = '$idData'";
		
		$run = mysqli_query($con,$insert_query); 
		if($run) {
		echo "Update Row Successfully"; 
		}else {echo"no";}
	 
 }
 
 
 
 
 
 if(isset($_GET['D']))
{
		   $idData =  base64_decode($_GET['D']); 
		   $Module =  $_POST['textval']; //exit();
		  $insert_query = "UPDATE `productgroupadd` SET `producname`='$Module' WHERE pgroupid= '$idData'";
	    $run = mysqli_query($con,$insert_query); 
		if($run) {
		echo "<center> <img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
		echo "<center></h6>Update Row Successfully..</h6></center>"."<br />";
	header('Refresh:1; url=config-product.php'); 
		}else {echo"No Data Found";}
	 
 }
  
  
   
 if(isset($_GET['1']))
{  
		   $idData =  base64_decode($_GET['1']); 
		   $fname =  $_POST['First'];        $lname =  $_POST['Last']; 
		   $cmpname =  $_POST['Compony'];		$email_id =  $_POST['Email'];
		   $userpass =  $_POST['Password'];		$add =  $_POST['Address'];
		   $contryid =  $_POST['country'];		$stateid =  $_POST['state'];
		   $cityid =  $_POST['city'];		$pin =  $_POST['Pin'];
		   $mobile =  $_POST['Mobile'];		$status =  $_POST['status']; 
		  
		  $insert_query = "UPDATE `user_ragistration` SET `fname`='$fname', `lname`='$lname', `cmpname`='$cmpname', `email_id`='$email_id', `userpass`=MD5('$userpass'), `add`= '$add', `contryid`='$contryid', `stateid`='$stateid', `cityid`='$cityid', `pin`='$pin', `mobile`='$mobile', `status`='$status'  WHERE id='$idData'";
	    $run = mysqli_query($con,$insert_query); 
		if($run) {
		echo "<center> <img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
		echo "<center></h6>Update Row Successfully..</h6></center>"."<br />";
	header('Refresh:1; url=clientprofile.php?1='.base64_encode($idData).''); 
		}else {echo"No Data Found"; header('Refresh:1; url=clientprofile.php?1='.base64_encode($_GET['1']).'');}
	 
 }
  
 ?>