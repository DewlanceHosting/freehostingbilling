<?php 
  include_once('../fn/connect.php');  

 $que=mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($que);  
 
 ?>
 
 <title><?php echo $rowdata['cmpname']; ?></title>