<?php
class DBController {
	private $host = "HOST_NAME";
	private $user = "DB_USER";
	private $password = "DB_PASSWORD";
	private $database = "DB_NAME";
	
	function __construct() {
		$conn = $this->connectDB();
		if(!empty($conn)) {
			$this->selectDB($conn);
		}
	}
	
	function connectDB() {
		$conn = mysql_connect($this->host,$this->user,$this->password);
		return $conn;
	}
	
	function selectDB($conn) {
		mysql_select_db($this->database,$conn);
	}
	
	function selectQuery($query) {
		$result = mysql_query($query);
		while($row=mysql_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysql_query($query);
		$rowcount = mysql_num_rows($result);
		return $rowcount;	
	}
	
	function insertQuery($query) {
		$result = mysql_query($query);
		if(!empty($result)) {
			$insert_id = mysql_insert_id();
			return $insert_id;
		}
	}
}
?>