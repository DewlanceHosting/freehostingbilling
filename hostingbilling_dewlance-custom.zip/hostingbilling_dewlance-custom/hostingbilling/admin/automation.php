 <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>

<?php
$page = $_SERVER['PHP_SELF'];
$sec = "86400";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
     
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
  <?php include_once('header.php'); ?>
  
  <!--headerpart-end  sus_no
term_no
checkedno
first_renewal
second_renewal
ticketclosed-->  

<div class="clientprofile">
<div class="container">
<div class="atomations">
<h3>Automation</h3>

<p>This cron job will run and execute various function like : invoice, creation, suspension, terminate, on overdue invoice</p>
<?php $nudata = mysqli_query($con,"SELECT * FROM `automation_table`"); $nrowdat=mysqli_fetch_array($nudata); ?>


<div class="inffosection">

<h5><i class="fa fa-check"></i> &nbsp; Cron Status Ok last run : 04/05/2017 04:00</h5>
<p>The System Cron automates task within Dewlance. it should be configured to execute every five minute, or as frequently as your web hosting provider allows.</p>

<div class="input-group">
  <span class="input-group-addon" id="basic-addon3">Cron Command</span>
  <input type="text" class="form-control" id="basic-url" placeholder="*/5****php-q/home/dewlance/public_html/client/crones/crone.php">
</div>

<h4>Module Function</h4>
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>

<p>Suspend Days <span><input type="number" value="<?php echo $susday= $nrowdat['sus_no']; ?>" id="1" style="width:50px;"></span>  Enter the number of  days after the payment date you will wait before suspending any service</p>


<p class="mdlfn">Enable/Disable Termination <span><input type="checkbox" id="2" value="1" checked></span> Tick this box to enable automatic termination</p>


<p class="mdlfn">Termination days <span><input type="number" id="3" value="<?php echo $Terday= $nrowdat['term_no']; ?>" style="width:50px;"></span> Enter the number of  days after due date. service will be terminated.</p>
<?php 
 
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`
  $date = date("d-m-Y", strtotime('-3 day'));
 
$sqlCommand = "SELECT * FROM  `user_hostingpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail For Your Plan";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>User Name: &nbsp;'. $cpuser.'</strong></p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>This Your domain : &nbsp;'. $Domain.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $newmailid.'</strong></p>  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
 } 
 
 ///////////////////////////////////////Suspend Days  Enter the number of days after the payment date you will wait before suspending any service////////
  
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`
  $date = date("d-m-Y", strtotime('+'.$susday.' day'));
 
$sqlCommand = "SELECT * FROM  `user_hostingpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail for Your Domain";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$rowDetai['fname'].'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Domailn is expired to: &nbsp; '.$mydatas['nexduedate'].' &nbsp; Please Update your Palan</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
   
    $susname = $rowDetai['fname'];
   $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/suspendacct?api.version=1&user=$susname&reason=Nonpayment";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
      $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
	 
		   $grn="UPDATE `user_ragistration` SET `viewcpanelstatus`='2' WHERE `user_ragistration`.`id` ='$userR'";
       $dataup=mysqli_query($con,$grn);
        echo "User Suspend";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
 
}


 /////////////////////////////////////// Termination days  Enter the number of days after the payment date you will wait before suspending any service////////  
 
 
 
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`
  $date = date("d-m-Y", strtotime('+'.$Terday.' day'));
 
$sqlCommand = "SELECT * FROM  `user_hostingpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail for Your Domain";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$rowDetai['fname'].'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Domailn is expired to: &nbsp; '.$mydatas['nexduedate'].' &nbsp; Please Update your Palan</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
$username =  $rowDetai['fname'];
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/removeacct?user=$username";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		 
       $dataup=mysqli_query($con,"UPDATE `user_ragistration` SET `viewcpanelstatus`='3' WHERE `user_ragistration`.`id` ='$userR'");
		//print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
 
 } 
?>



<h4>Domain  Reminder Setting</h4>

<p>First Renewal Reminder Notice <span><input type="number" id="4" value="<?php echo $fir=$nrowdat['first_renewal']; ?>" style="width:50px;"></span> Enter the number of  days first renewal reminder Notice will be send</p>

<p>Second Renewal Reminder Notice <span><input type="number" id="5" value="<?php echo $secd=$nrowdat['second_renewal']; ?>" style="width:50px;"></span> Enter the number of  days second renewal reminder Notice will be send</p>

<?php 
 // first reminder notic//////////////////////////////////////////////////////////////////////////////////////////////////
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`
  $date = date("d-m-Y", strtotime('-'.$fir.' day'));
 
$sqlCommand = "SELECT * FROM  `user_domainpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail for Your Domain";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$rowDetai['fname'].'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Domailn is expired to: &nbsp; '.$mydatas['nexduedate'].' &nbsp; Please Update your Palan</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
 } 
 // //////////////////////////////////   Second Renewal Reminder Notice/   /////////////////////////////////////////////////////////////////////////////////////////
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`
  $date = date("d-m-Y", strtotime('-'.$secd.' day'));
 
$sqlCommand = "SELECT * FROM  `user_domainpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail for Your Domain";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$rowDetai['fname'].'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Domailn is expired to: &nbsp; '.$mydatas['nexduedate'].' &nbsp; Please Update your Palan</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
 } 
?>


<h4>Ticket Automation</h4>

<p>Automatically close ticket after <span><input type="number" id="6" value="<?php echo $nrowdat['ticketclosed']; ?>" style="width:50px;"></span> Enter the number of  Hours. after ticket will automatically closed if no response received from client</p>
<?php 
 
//SELECT * FROM `user_domainpay`
//id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `nexduedate`, `status`, `domainstatus`, `ordercancel`


 /* $date = date("d-m-Y", strtotime('-3 day'));
 
$sqlCommand = "SELECT * FROM  `user_domainpay` WHERE nexduedate='$date'"; 

$query = mysqli_query($con, $sqlCommand) or die (mysqli_error($con)); 
$mydatas= mysqli_fetch_array($query);
 if($query){ 
 
 $userR = $mydatas['user_rid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Mail for Your Domain";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$rowDetai['fname'].'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Domailn is expired to: &nbsp; '.$mydatas['nexduedate'].' &nbsp; Please Update your Palan</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
 } */
?>

<br>
<button class="btn btn-danger" onClick="SubmitFormData();">Click to Save Setting</button>

</div> 

</div> 
</div>
</div> 
<div class="clearfix"></div>
<div id="results"></div>
 <script>
 function SubmitFormData() {
    var sus = $("#1").val();
    var term = $("#3").val();
    var fist = $("#4").val();
	 var secod = $("#5").val();
    var tecket = $("#6").val();    
    var checkdata = $("input[type=checkbox]:checked").val();
    $.post("ts.php", { sus: sus, term: term, fist: fist, secod: secod, tecket: tecket, checkdata: checkdata },
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
    });
}
 </script>
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->

  

  </body>
</html>