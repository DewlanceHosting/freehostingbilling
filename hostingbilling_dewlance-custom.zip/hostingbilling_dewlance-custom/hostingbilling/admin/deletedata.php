<?php
   include_once('../fn/connect.php');  
   
if (isset($_GET['id']) && is_numeric($_GET['id']))
 {
 // get id value
 $id = $_GET['id'];;
 } 

$rec1 = "DELETE FROM `productadd` WHERE  producid='$id'";

if(mysqli_query($con,$rec1)){
	echo "<center><img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Please wait while you are redirected in 1 seconds..</h6></center>"."<br />";
	header('Refresh:1; url=hostingproduct.php');
}
else{
	die("Data failed to delete in the database");
}

 

if (isset($_GET['uid']) && is_numeric($_GET['uid']))
 {
 // get id value
 $id = $_GET['uid'];
 } 
  

$rec3 = "DELETE FROM `user_ragistration` WHERE   id='$id'";

if(mysqli_query($con,$rec3)){
	 
	header('Refresh:1; url=clientprofile.php');
}
else{
	die("Data failed to delete in the database");
}




/////////////////////////////Delete Admin/////////////////////////////////////

if (isset($_GET['1ad']) && is_numeric($_GET['1ad']))
 {
 // get id value
 $id = $_GET['1ad'];
 }  
$rec5 = "DELETE FROM `admin` WHERE   id='$id'";

if(mysqli_query($con,$rec5)){
	 
	header('Refresh:1; url=user-control.php');
}
else{
	die("Data failed to delete in the database");
}

/////////////////////////////Delete Manage Order  manage-order.php/////////////////////////////////////

if (isset($_GET['mano']) && is_numeric($_GET['mano']))
 {
 // get id value
 $id = $_GET['mano'];
 }  
$rec6 = "DELETE FROM `user_hostingpay` WHERE   id='$id'";

if(mysqli_query($con,$rec6)){
	 
	header('Refresh:1; url=manage-order.php');
}
else{
	die("Data failed to delete in the database");
}
 
 


 /////////////////////////////Delete Tex Rules  Rules/////////////////////////////////////
   
if (isset($_GET['voi']) && is_numeric($_GET['uifp']))
 {
 // get id value
 $uifp = base64_encode($_GET['uifp']);
 
 $id = $_GET['voi'];
 }  
$rec4 = "DELETE FROM `user_hostingpay` WHERE   id='$id'";

if(mysqli_query($con,$rec4)){
	 
	header('Refresh:1; url=clientprofile.php?1='.$uifp.'');
}
else{
	die("Data failed to delete in the database");
	header('Refresh:1; url=clientprofile.php?1='.$uifp.'');
} 


/////////////////////////////////

if (isset($_GET['domain']) && is_numeric($_GET['uifp']))
 {
 // get id value
 $uifp = base64_encode($_GET['uifp']);
 
 $id = $_GET['domain'];
 }  
$rec4 = "DELETE FROM `user_domainpay` WHERE   id='$id'";

if(mysqli_query($con,$rec4)){
	 
	header('Refresh:1; url=clientprofile.php?1='.$uifp.'');
}
else{
	die("Data failed to delete in the database");
	header('Refresh:1; url=clientprofile.php?1='.$uifp.'');
} 

?>
