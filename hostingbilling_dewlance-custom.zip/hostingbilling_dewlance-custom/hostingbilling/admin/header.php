  <?php 
  include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');} ?>
  <div class="header">
    <nav class="navbar navbar-top">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="#"><img src="../images/<?php echo $rowdata['urlink']; ?>" alt="logo"></a>
        </div>
        <div class="navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
          <li><form class="navbar-form" action="clientprofile.php" method="post" >
        <div class="input-group">
        <input type="text" list="livesearch" name="item_id" onChange="getComboA(this)"  onkeyup="showResult(this.value)" class="form-control" placeholder="Search"/>  
 <datalist id="livesearch">
   <div id="livesearch"></div> 
   </datalist>
        <button class="input-group-addon gropbtn" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>  
        </form>
        </li>
             <li><a href="logout.php?edit=<?php echo $_SESSION['adminemailSession'];?>">Logout</a></li>
            
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <nav class="navbar navbar-default">
      <div class="container">
      <div class="row">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <!-- <a class="navbar-brand" href="#">Project name</a>-->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class=""><a href="home.php">Home</a></li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Client <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="viewclient.php">View Client</a></li>
                <li><a href="searchclient.php">Search Client</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Product <span class="caret"></span></a>
              <ul class="dropdown-menu">
               <!-- <li><a href="allproduct.php">All Product</a></li>-->
                <li><a href="hostingproduct.php">Hosting Product</a></li>
                <!--<li><a href="otherproduct.php">Other Product</a></li>-->
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Orders <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="listoforder.php">List of Order</a></li>
              
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Support <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="support.php">Support</a></li>
                <li><a href="support-ticket-department.php">Support Department</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Config <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="configmenu.php">General</a></li>
                <li><a href="automation.php">Automation</a></li>
                <li><a href="config-gateway.php">Gateway</a></li>
                <li><a href="config-modules.php">Modules</a></li>
               <!-- <li><a href="config-product.php">Products</a></li>-->
                <li><a href="domainregistrar.php">Domain Registrar</a></li>
                <li><a href="domainpricing.php">Domain Pricing</a></li>
                <li><a href="email-template.php">Email Template</a></li>
                <li><a href="tax-rules.php">Tax Rules</a></li>
                
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Help <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Domain</a></li>
                <li><a href="#">Support</a></li>
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">My Account <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <!--<li><a href="clientprofile.php">Profile</a></li>-->
                <li><a href="password.php">Password</a></li>
                <li><a href="user-control.php">User Control</a></li>
              </ul>
            </li>
          </ul>
          
        </div><!--/.nav-collapse -->
      </div>
      </div>
    </nav>
  </div>
  <script>
function showResult(str) {
  if (str.length==0) { 
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","Data_livesearch.php?q="+str,true);
  xmlhttp.send();
}
</script>





 <script src="js/markdown.js" type="text/javascript"></script>
