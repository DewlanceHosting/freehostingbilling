<?php         include_once('../fn/connect.php'); 
 
 ////////////////////////////////Price//////////////////////////////////////////////////////////////////
 // name: name, email: email, phone: phone, checkValues: checkValues
 if(isset($_POST['name']))
{
			    
			  $domainname =  $_POST['name'];
		      $domainprice =  $_POST['email'];
		      $autoregistration = $_POST['phone']; 
			  $checkValues =  $_POST['checkValues'];
			  
			   //print_r($checkValues); 
						 
			 $dsnmanagement = $checkValues[0];
			 $emailforwarding = $checkValues[1];
			 $idprotection = $checkValues[2];
			 $eppcode = $checkValues[3];
 
			 
        $result = mysqli_query($con,"SELECT * FROM productadd"); while($row = mysqli_fetch_array($result))
      {
	     $val=$row['domainname'];}
	   if($val != $domainname){ 
		if($domainname==''){
		echo "<script>alert('any field is empty')</script>";
		exit();
		}  
		else{
		 
		  $insert_query = "INSERT INTO `priceadd`(`domainname`, `domainprice`, `dsnmanagement`, `emailforwarding`, `idprotection`, `eppcode`, `autoregistration`)  
								VALUES ('$domainname', '$domainprice', '$dsnmanagement', '$emailforwarding', '$idprotection', '$eppcode', '$autoregistration')";
		
		$run = mysqli_query($con,$insert_query); 
		if($run) { 
		   echo "New Domain Add";
		}echo"no";
	}
				  
  }else{ echo "This Product already exist";}
 }
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 
 if(isset($_POST['Updatename']))
{   $edit=$_POST['upid'];
			    
			  $domainname =  $_POST['Updatename'];
		      $domainprice =  $_POST['Updateprice'];
		      $autoregistration = $_POST['updatephone']; 
			  $checkValues =  $_POST['checkValues']; 
			   //print_r($checkValues); 
						 
			 $dsnmanagement = $checkValues[0];
			 $emailforwarding = $checkValues[1];
			 $idprotection = $checkValues[2];
			 $eppcode = $checkValues[3]; 
		 
		  $insert_query = "UPDATE `priceadd` SET `domainname` = '$domainname', `domainprice` = '$domainprice', `dsnmanagement` = '$dsnmanagement', `emailforwarding` = '$emailforwarding', `idprotection` = '$idprotection', `eppcode` ='$eppcode', `autoregistration` = '$autoregistration' WHERE `priceid` ='$edit'"; 
		$run = mysqli_query($con,$insert_query); 
		if($run) { 
		   echo "Update Domain";
		}echo"no";
	 
 }
  
 ?>