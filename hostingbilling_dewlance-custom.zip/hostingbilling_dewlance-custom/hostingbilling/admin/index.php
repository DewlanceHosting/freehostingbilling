<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script type="text/javascript">$(document).ready(function(){
$("#UserLoginN").click(function(){
										 
var adminName = $("#adminName").val();   //alert(adminName);
var adminpass = $("#adminpass").val(); //alert(PicDate);
 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'adminName='+ adminName + '&adminpass='+ adminpass ;
 // alert(dataString);
if(adminName==''|| adminpass=='')
{
alert("Please Fill All cheked compony name");
}
else
{
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "datalogin.php",
data: dataString,
cache: false,
success: function(result){ 
$('#resd').html(result);
 //alert(result);
//location.reload();
 window.open('home.php','_self');
// $("#loginmodel").modal('hide');
 
}
});
}
return false;
});
});</script>
  </head>
  <body>
  
  <div class="header">
    <nav class="navbar navbar-top" style="box-shadow: 0 1px 10px rgba(0, 0, 0, 0.118), 0 1px 7px rgba(0, 0, 0, 0.118);">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="#"><img src="images/logo.png" alt="logo"></a>
        </div>
        <div class="navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
            <li><a href="">Welcome to Dewlance Admin</a></li>
            
          </ul> 
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    
  </div>
  
  <!--headerpart-end-->
  
<section class="">
<div class="container">
<div class="row">

<div class="col-md-offset-3 col-md-6 col-md-offset-3">

<div class="loginadmin">
<div class="loginpart">
<h4>Login</h4>
     
  <div class="form-group">
    <label for="email">User Name:</label>
    <input type="email" class="form-control" id="adminName" placeholder=" Enter User Name"> 
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="adminpass" placeholder=" Enter Password">
  </div>
  <button type="button" class="btn btn-danger form-control" id="UserLoginN">Login</button> 
     </div>
     <samp id="resd">
	</samp>

</div>

</div>




</div>
</div>
</section>
 
 
 <!--home--contant----end--->
 
 
 <div class="footer">
 <div class="container">
 <div class="powered">
 <h4>Powered by : <span>Dewlance</span></h4>
 </div>
 </div>
 
 <div class="copyright">
 <div class="container">
 <p>© 2017 Dewlance Web Hosting All Rights Reserved. | Developed by <a href="http://dewlance.com/">dewlance</a></p>
 </div>
 </div>
 
 </div>
 <!----------footer---end------->




<style>
.loginadmin {
    box-shadow: 0 1px 10px rgba(0, 0, 0, 0.118), 0 1px 7px rgba(0, 0, 0, 0.118);
    background: #fff;
    padding: 20px;
    margin: 20% 0;
    border: solid 1px #ddd;
}

.loginpart h4 {
    font-size: 24px;
    color: #d9534f;
    border-bottom: dashed 1px #ddd;
    padding-bottom: 7px;
}

</style>

  </body>
</html>