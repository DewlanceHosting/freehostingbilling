<?php //idup: idup, opticket: opticket
include_once('../fn/connect.php');
if(isset($_POST['opticketn']))
{  
		   $opticket =  $_POST['opticketn'];
		   $idup =  $_POST['idup']; //exit();
		  $insert_query = "UPDATE `ticket_sale` SET `openstatus`='$opticket' WHERE id= '$idup'";
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		echo " Update Row Successfully.. "; 
		}else {echo"No Data Found";} 
 }
 
 
 if(isset($_GET['opticket']))
{  
		   $opticket =  $_GET['opticket'];
		   $idup =  $_GET['idup']; //exit();
		  $insert_query = "UPDATE `ticket_sale` SET `closeticket`='1' WHERE id= '$opticket'";
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		header('Refresh:1; url=support.php');
		echo "<center>clos Ticket Successfully.. </center>"; 
		}else {echo"No Data Found";} 
 }
 ?>
 
 
 <?php  session_start();
  
//include_once('fn/connect.php'); date_default_timezone_set("asia/kolkata");
  
if(isset($_POST['ticketsub'])){
 $ticketsub = $_POST['ticketsub']; 
$Massage = $_POST['content'];
$opticket = $_POST['opticket'];
$email = 'jitendragurgao@gamil.com';
//$file = $_POST['file'];
  $post_image =  $_FILES['file']['name'];
		  $image_tmp =  $_FILES['file']['tmp_name'];
 $str=$_SESSION['userid'];
  $que=mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$getiddata' || fname='$searchdaata'"); $rowdata=mysqli_fetch_array($que);
  $Name=$rowdata['contryid'].' '.$rowdata['contryid'];
  $ip = $_SERVER['REMOTE_ADDR'];
$datime=date('d-m-Y h:i:s a');
  move_uploaded_file($image_tmp,"images/$post_image");
			$insert_query = "INSERT INTO `suporttickte_maildata` (`subject`, `mailto`, `mailfrom`, `massagedata`, `attechfile`, `senddate`, `userip`) VALUES ('$ticketsub', '$email', '$Name', '$Massage', '$post_image', '$datime', '$ip')"; 
		$run = mysqli_query($con,$insert_query);
		if($run) {
		echo "Ragistration sucsessfully created"; 
 
		$to = $email;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">';
   $imgdata=mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdaim=mysqli_fetch_array($imgdata); 
echo '<img src="http://dewlance.xyz/hostingbilling/images/'.$rowdaim['urlink'].'"alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Name : &nbsp;'.$Name.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Subject : &nbsp;'.$ticketsub.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Massage: &nbsp;</strong><textarea cols="80" rows="5">'. $Massage.'</textarea></p> <p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Ticket Is :'.$opticket.'</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
<p style="font:16px/45px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee; padding-left:60px;"><strong>Email Frome To: &nbsp;'. $email.'</strong></p>
 </div>

</body>
</html>
';

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: dewlance@gmail.com>' . "\r\n";
$headers .= 'Cc:dewlance@gmail.com' . "\r\n";

// Send email
mail($to,$ticketsub,$htmlContent,$headers);
 header('Refresh:1; url=support-ticket.php');
		}} 
		
		
		if(isset($_POST['newmailid']))
{  // Domain: Domain, cpuser: cpuser, password: password, newmailid: newmailid

		  echo $Domain =  $_POST['Domain'];
		 echo  $cpuser =  $_POST['cpuser'];		   
		 echo  $password =  $_POST['password'];
		 echo  $Email =  $_POST['newmailid']; 
		   
		  $to = $Email;
$subject = "Your Cpanel Account Creating";
$txt = "Name - ".$cpuser."Your Domain Name is -".$Domain ;
$headers = "jir.oh04@gmail.com"; 
mail($to,$subject,$txt,$headers);

 
 }

 ?>
 
 
 
 