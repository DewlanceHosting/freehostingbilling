  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">	</script> 
	<script type="text/javascript" language="javascript" class="init"> 
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
     <style> 
#example tr:nth-child(2n) {  background-color: #F3F3F3;}

#example tr {  background-color: white;} 
</style> 
  </head>
  <body>
  
   <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata");  ?>
  
  <!--headerpart-end--> 
<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Support Ticket Department</h3>
<p>Here you can configure your support ticket department, edit, modify, delete.</p>
<p>Email Piping allows tickets to be opened and responded to by email and can be setup using one of the methods below.</p>
<div class="linkedfrm">
<form>
<div class="input-group">
  <span class="input-group-addon" id="basic-addon1">Ticket Importing using Email Forwarders</span>
  <input type="text" class="form-control" placeholder="..! -Desktop/hostingbilling/admin/support-ticket-department.php">
</div>


<div class="input-group">
  <span class="input-group-addon" id="basic-addon1">Ticket Importing using POP3 Import (Requires IMAP Installed on server)</span>
 <input type="text" class="form-control" placeholder="file:///C:/Users/Hw%201/Desktop/hostingbilling/admin/support-ticket-department.php" >
</div>

</form>

<a href="addnewticket-department.php"><button class="btn btn-info">Add New Ticket Department</button></a>
<br>
<br>
</div>
<h3>Existing Ticket Department</h3>
<div class="table-responsive">
<table id="example" class="table table-hover" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th>Department Name</th>
      <th>Email Address</th>
      <th>Ticket Department Description</th>
       <th></th>
       <th></th>
    </tr>
  </thead>
  <tbody> <!--`tdpid`, `name`, `emailid`, `description`, `hostname`, `pop`, `hemail`, `hemailpass`, `status`-->
  <?php $query = mysqli_query($con,"SELECT * FROM `add_ticket_depart`"); while($rowdata=mysqli_fetch_array($query)){ ?>
    <tr>
      <td>
      <h4><?php echo $rowdata['name']; ?></h4>
      </td>
      <td><?php echo $rowdata['emailid']; ?></td>
       <td><?php echo $rowdata['description']; ?></td>
       <td><a href="addnewticket-department.php?edit=<?php echo $rowdata['tdpid']; ?>"><i class="fa fa-pencil-square-o fa-3x"></i></a></td>
       <td><a href="deletedata2.php?tdpid=<?php echo $rowdata['tdpid']; ?>"><i class="fa fa-trash-o fa-3x"></i></a></td>
    </tr>
    <?php }?> 
  </tbody>
</table>
</div> 
</div> 
</div>

</section> 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  </body>
</html>