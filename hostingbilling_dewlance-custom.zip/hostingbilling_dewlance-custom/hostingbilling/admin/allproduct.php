  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} );

	</script> 
     <style> 
#example tr:nth-child(2n) {
  background-color: #F3F3F3;
}

 
#example tr {
  background-color: white;
}
 
</style>     
  </head>
  <body>
  
  <?php include_once('header.php'); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh"> 
<div class="container">

<div class="listservisdata">
<h3>All Product</h3>
<div class="table-responsive"> 
<table id="example" class="table table-hover" cellspacing="0" width="100%">
				<thead>
					<tr>
		<th>Product Name</th> 
        <th>Payment Method</th>
        <th>Price</th>	
        <th>Billing Cycle</th>			 
      <th>Date Created</th>
       <th>Next Due Created</th>
      <th>Status</th> 
					</tr>
				</thead>
				 
				<tbody>
  <!-- `producid`, `modulid`, `groupid`, `decrip`, `pemail`, `rdomailn`, `pricetype`, `price`, `billtype`, `adddate`, `status`-->
 <?php  $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `productadd` ");  $rowcount=mysqli_num_rows($queser); 
  								while($rowser=mysqli_fetch_array($queser)){  $usrid = $rowser['user_rid']; 
								$date1=$rowser['adddate'];
 $date=date_create($date1);
date_add($date,date_interval_create_from_date_string("180 days"));
 $tiondate=date_format($date,"d-m-Y");  ?>
   
    <tr> 
     <td><?php echo $rowser['modulid']; ?></td>   
      <td>Paytm</td>
      <td><?php echo $rowser['price']; ?></td>
      <td><?php echo $rowser['billtype']; ?></td>
      <td>  <h4><?php echo $rowser['adddate']; ?></h4>      </td>
      <td>  <h4><?php echo $tiondate; ?></h4>      </td>
      <?php if($rowser['status'] == '0'){?>

  <td>Active</td>

<?php } else{?>

  <td>In-Active</td>

 <?php } ?> 
        
    </tr>
    <?php }?>
     
    
  </tbody>
			</table>
</div>

</div> 

</div>

</section>


 
 
 <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>