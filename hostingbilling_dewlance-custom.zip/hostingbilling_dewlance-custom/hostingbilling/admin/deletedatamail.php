<?php
   include_once('../fn/connect.php');  
   
if (isset($_GET['1r']) && is_numeric($_GET['1r']))
 {
 // get id value
 $id = $_GET['1r'];;
 } 

$rec1 = "DELETE FROM `suporttickte_maildata` WHERE  id='$id'";

if(mysqli_query($con,$rec1)){
	echo "<center><img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Please wait while you are redirected in 1 seconds..</h6></center>"."<br />";
	header('Refresh:1; url=support-ticket.php');
}
else{
	die("Data failed to delete in the database");
}?>