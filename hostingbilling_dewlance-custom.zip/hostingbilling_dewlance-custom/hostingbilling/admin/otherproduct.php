  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
  <div class="header">
    <nav class="navbar navbar-top">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="#"><img src="images/logo.png" alt="logo"></a>
        </div>
        <div class="navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
          <li><form class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" name="q">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form></li>
             <li><a href="">Logout</a></li>
            
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <nav class="navbar navbar-default">
      <div class="container">
      <div class="row">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <!-- <a class="navbar-brand" href="#">Project name</a>-->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class=""><a href="home.php">Home</a></li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Client <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="viewclient.php">View Client</a></li>
                <li><a href="searchclient.php">Search Client</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Product <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="allproduct.php">All Product</a></li>
                <li><a href="hostingproduct.php">Hosting Product</a></li>
                <li><a href="otherproduct.php">Other Product</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Orders <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="listoforder.php">List of Order</a></li>
              
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Support <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="support.php">Support</a></li>
                <li><a href="support-ticket-department.php">Support Department</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Config <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="configmenu.php">General</a></li>
                <li><a href="automation.php">Automation</a></li>
                <li><a href="config-gateway.php">Gateway</a></li>
                <li><a href="config-modules.php">Modules</a></li>
                <li><a href="config-product.php">Products</a></li>
                <li><a href="domainregistrar.php">Domain Registrar</a></li>
                <li><a href="domainpricing.php">Domain Pricing</a></li>
                <li><a href="email-template.php">Email Template</a></li>
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Help <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Domain</a></li>
                <li><a href="#">Support</a></li>
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">My Account <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <!--<li><a href="clientprofile.php">Profile</a></li>-->
                <li><a href="password.php">Password</a></li>
              </ul>
            </li>
          </ul>
          
        </div><!--/.nav-collapse -->
      </div>
      </div>
    </nav>
  </div>
  
  <!--headerpart-end-->
  

<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<div class="row">
<div class="col-md-6">
<h3>Search Product</h3>
</div>
<div class="col-md-6">

  
</div>
</div>

<div class="row">
  <div class="col-md-6">
  <div class="prodform">
<form class="form-horizontal">
  <div class="form-group">
    <label class="control-label col-sm-3" for="Type">Product Type:</label>
    <div class="col-sm-9"> 
      <select class="form-control" id="">
      <option>Product/Service</option>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">Product/Service :</label>
    <div class="col-sm-9"> 
      <select class="form-control" id="">
      <option>Any</option>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Cycle">Billing Cycle :</label>
    <div class="col-sm-9"> 
      <select class="form-control" id="">
      <option>Any</option>
      <option>Monthly</option>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Domain">Domain :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">Client Name :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="">
    </div>
  </div>
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-danger">Search</button>
    </div>
  </div>
</form>

</div>





</div>
</div>

<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Date Created</th>
      <th>Payment Method</th>
      <th>Status</th>
       <th>Product Name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
    <tr>
      <td>
      <h4>18/04/2013</h4>
      </td>
      <td>Paypal</td>
       <td>Active</td>
       <td>Bronze Hosting</td>
    </tr>
  </tbody>
</table>
</div>

</div>





</div>

</section>



<div class="clearfix"></div>
 
 
 <!--home--contant----end--->
 
 
 
 
 
 
 
 
 <div class="footer">
 <div class="container">
 <div class="powered">
 <h4>Powered by : <span>Dewlance</span></h4>
 </div>
 </div>
 
 <div class="copyright">
 <div class="container">
 <p>© 2017 Dewlance Web Hosting All Rights Reserved. | Developed by <a href="http://dewlance.com/">dewlance</a></p>
 </div>
 </div>
 
 </div>
 <!----------footer---end------->
 

  

  </body>
</html>