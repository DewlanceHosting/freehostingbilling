<?php
   include_once('../fn/connect.php');   
/////////////////////////////Delete Depatment  support-ticket-department.php/////////////////////////////////////

if (isset($_GET['tdpid']) && is_numeric($_GET['tdpid']))
 {
 // get id value
 $id = $_GET['tdpid'];
 }  
$rec7 = "DELETE FROM `add_ticket_depart` WHERE   tdpid='$id'";

if(mysqli_query($con,$rec7)){
	 
	header('Refresh:1; url=support-ticket-department.php');
}
else{
	die("Data failed to delete in the database");
}

?>