 <?php include_once('../fn/connect.php');  ?>
 <?php   $name=$_POST['inputModule']; if(isset($_POST['inputModule'])){ ?>
 <?php if($name =="cpanel"){ ?>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Module">Select Package:</label>
    <div class="col-sm-9">
      <?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
          <select class="form-control" id="Module"><option value="">select</option>
   <?  
    $user = "root";
    $token = $rowc['apikdy']; 
    $query = "https://$stval/json-api/listpkgs?api.version=1"; 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query); 
      $result = curl_exec($curl); 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            echo "<option value=". $userdetails->{'name'} .">" . $userdetails->{'name'} ." Supercheap ". "</option>";
        }
    } 
    curl_close($curl); ?>   
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Group:</label>
    <div class="col-sm-9">  
      <select class="form-control" id="pnameGroup"><option value="">select</option>
      <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productgroupadd` where status='1'"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?>
      <option value="<?php echo $ProducName['pgroupid']; ?>"><?php echo $ProducName['producname']; ?></option>
      <?php }?>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Description:</label>
    <div class="col-sm-9"> 
      <textarea class="form-control" rows="4" placeholder="Enter Description" id="descrip"></textarea>
    </div>
  </div> 
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <div class="checkbox">
        <label><input type="checkbox" class="checkbox1"> Allow domain registration with with this product</label>
      </div>
    </div>
  </div>
  
  
  <div class="checkkedtoggle">
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
     <label class="radio-inline">
      <input type="radio" name="optradio" class="frrbtn" value="Free">Free
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio" class="ontm" value="One Time">One Time
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio" class="requir" value="Requiring">Requiring
    </label>
    </div>
  </div>
  
  <div class="form-group ontim1 free">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="Price" placeholder="Enter Price">
    </div>
  </div> 
  
  <script>
$(document).ready(function(){
    $(".ontm").click(function(){
        $(".ontim").show();
    });
	
	  $(".ontm").click(function(){
        $(".ontim1").hide();
    });
	
	    $(".requir").click(function(){
        $(".ontim , .ontim1").show();
    });
	
		    $(".frrbtn").click(function(){
        $(".ontim , .ontim1").hide();
    });
});
</script>
  
  <div class="form-group ontim free">
    <label class="control-label col-sm-3" for="Price">Price : Billing Cycle</label>
    <div class="col-sm-9"> 
     <select class="form-control" id="BillingType">
     <option>Monthly</option>
     <option>Quarterly</option>
     <option>Annualy</option>
     </select>
    </div>
  </div>
    <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-danger" id="submit">Submit</button>
    </div>
  </div>
   <?php  }else{ ?>
   <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Description:</label>
    <div class="col-sm-9"> 
      <textarea class="form-control" rows="4" placeholder="Enter Description" id="descrip"></textarea>
    </div>
  </div>
  <?php  }} ?> 
  <script>$(document).ready(function(){
$("#submit").click(function(){
							//alert();
//var pname = $("#pname").val();
var Module = $("#Module").val();
var pnameGroup = $("#pnameGroup").val();
var descrip = $("#descrip").val();
var Email = $("#Email").val();
var  domain = $("input[type=checkbox]:checked").val();
var PriceType = $("input[type=radio]:checked").val();
var Price = $("#Price").val();
var BillingType = $("#BillingType").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString =  '&Module='+ Module + '&pnameGroup='+ pnameGroup + '&descrip='+ descrip + '&Email='+ Email + '&domain='+ domain + '&PriceType='+ PriceType + '&Price='+ Price + '&BillingType='+ BillingType; 
if(Module==''||pnameGroup==''||descrip==''||Email==''|| domain==''||PriceType==''||Price==''|| BillingType=='')
{
alert("Please Fill All Fields");
}
else
{
 //alert(dataString);
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "Datafunction.php",
data: dataString,
cache: false,
success: function(result){
alert(result);
}
});
}
return false;
});
});

</script>