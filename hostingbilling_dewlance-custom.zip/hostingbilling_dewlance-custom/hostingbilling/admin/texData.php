<?php  session_start();
include_once('../fn/connect.php'); 

				
	if(isset($_POST['AddRule'])){			
						 $Enabled = $_POST['Enabled'];
						 $textype = $_POST['textype'];
						 $Level = $_POST['Level'];
						 $texName = $_POST['texName'];
						 $optradio = $_POST['optradio'];
						 $countryid = $_POST['countryid'];
						 $stateoption = $_POST['stateoption'];
						 $state = $_POST['state'];
						 $texRate = $_POST['texRate'];
	 $inserq="INSERT INTO `texdataadd` (`tex_enable`, `textype`, `level`, `texname`, `c_val`, `countryid`, `s_val`, `statename`, `texrate`, `status`) VALUES ('$Enabled', '$textype', '$Level', '$texName', '$optradio', '$countryid', '$stateoption', '$state', '$texRate', '0')";
	  $Run=mysqli_query($con,$inserq);
	if($Run){
	echo "Rule Add";
	header('Refresh:1; url=tax-rules.php');
	}else {echo"Rule Note Add"; 
	header('Refresh:1; url=tax-rules.php');}
		}				
?>