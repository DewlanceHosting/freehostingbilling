  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
$(document).ready(function() {
	$('#example1').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
     <style> 
#example tr:nth-child(2n) {
  background-color: #F3F3F3;
}

 
#example tr {
  background-color: white;
}
 
</style>    
    <style>
    .bcolor{ background:#EFEFEF;
	    margin-left: -13px;
    margin-top: -10px; 
	padding-bottom: 2px;}
    </style>
       
  </head>
  <body>
  
   <?php include_once('header.php'); ?>
  <form  action="texData.php" method="post" enctype="multipart/form-data"> 
   
  <!--headerpart-end--> 
<section class="clientdashh">
<div class="container"> 
<div class="listservisdata">
<h3>Tax Rules</h3> 
<!--<p>This is where tax rules are configured. Tax can be either exclusive (added to on prices) or inclusive ( prices include it). you are allowed to create two seperate level of tax rules allowing you to charge multiple taxes such as state an country taxes.</p>--> 
<div class="tax_forms">
<div class="form-horizontal">
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Tax Enabled :</label>
    <div class="col-sm-10 bcolor">
      <div class="checkbox">
        <label><input type="checkbox" name="Enabled" value="1"> Tick this box to enable tax support</label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Tax Type :</label>
    <div class="col-sm-10 bcolor"> 
    
    <label class="radio-inline">
      <input type="radio" name="textype" value="Exclusive">Exclusive
    </label>
    <label class="radio-inline">
      <input type="radio"  name="textype" value="Inclusive">Inclusive
    </label> 
    </div>
  </div>
 <!-- <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Apply Tax To :</label>
    <div class="col-sm-10 bcolor">
      
      <label class="checkbox-inline">
      <input type="checkbox" name="ApplyTo[]" value="Domains">Domains
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="ApplyTo[]" value="Billable Items">Billable Items
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" name="ApplyTo[]"value="Late Fees">Late Fees
    </label>
      
          <label class="checkbox-inline">
      <input type="checkbox" name="ApplyTo[]" value="Custom Invoices">Custom Invoices (Product & Addons are set per item)
    </label> 
      
    </div>
  </div>
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Compound Tax :</label>
    <div class="col-sm-10 bcolor">
      <div class="checkbox">
        <label><input type="checkbox" name="Compound" value="level2"> Tick this box to charge compound tax on level 2</label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Deduct Tax Amount :</label>
    <div class="col-sm-10 bcolor">
      <div class="checkbox">
        <label><input type="checkbox" name="TaxAmount"> Tick this box to deduct the amount that would be charged as tax from inclusive prices if no tax rules are met</label>
      </div>
    </div>
  </div>-->
  <!--<center><button type="submit" class="btn btn-primary">saveChange</button></center><br>-->
  </div> 
</div> 


<div class="proftabb">
<ul class="navadminn">
<li class="active"> <a data-toggle="tab" href="#Level1" aria-expanded="true">Level 1 Rules</a></li>
  <li class=""> <a data-toggle="tab" href="#Level2" aria-expanded="false"> Level 2 Rules</a></li> 
  <li class=""> <a data-toggle="tab" href="#Create" aria-expanded="false">Add New Tax Rule</a></li>
</ul>
 
<div class="tab-content">
<div id="Level1" class="tab-pane fade active in">
   <div id="pricelisupdate">
  <h3>Level 1 Rules</h3>
  <div class="table-responsive">
 <table id="example" class="table table-hover" cellspacing="0" width="100%">
<thead>
<tr role="row"> 
<th>Name</th>
<th>Country</th>
<th>State/Region</th>
<th>Tax Rate</th>
<th> Action </th>
<th></th>
</tr>
</thead>
<tbody>
<?php 
/*`tid`, `tex_enable`, `textype`, `level`, `texname`, `c_val`, `countryid`, `s_val`, `statename`, `texrate`, `status`*/
$querydata =mysqli_query($con,"SELECT * FROM `texdataadd` where level='1'"); while($rowData=mysqli_fetch_array($querydata)){ 
$cid=$rowData['countryid'];
$sid=$rowData['s_val'];?>
 <tr>  
     <td><?php echo $rowData['texname']; ?></td>  
     <?php if($rowData['c_val'] ==2 ){ ?> 
     <?php $queryc =mysqli_query($con,"SELECT * FROM `country` where id='$cid'");  $rowc=mysqli_fetch_array($queryc); ?> 
      <td><?php echo $rowc['country']; ?></td>
      <?php }else{?>
      <td><?php echo "Apply Rule to All Countries"; ?></td> 
      <?php }?>
         <?php if($rowData['s_val'] ==2 ){ ?> 
     <?php $querysa =mysqli_query($con,"SELECT * FROM `state` where id='$sid'");  $rows=mysqli_fetch_array($querysa); ?> 
      <td><?php echo $rows['statename']; ?></td>
      <?php }else{?>
      <td><?php echo "Apply Rule to All State"; ?></td> 
      <?php }?>
      <td><?php echo $rowData['texrate']; ?>%</td>
       <?php if($rowData['tex_enable'] ==1 ){ ?> 
    <th><a  href="edittxt.php?txtid=<?php echo $rowData['tid'];  ?>&val=0"> Enable</a></th> 
      <?php }else{?>
      <th><a  href="edittxt.php?txtid=<?php echo $rowData['tid'];  ?>&val=1">Disable</a></th>
      <?php }?>
      <td><a  href="deletetex.php?tid=<?php echo $rowData['tid'];  ?>"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>   
    </tr>
    <?php }?>
    
 <!-- <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>
     <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>
  <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>-->
    
    </tbody>
	</table>
  
  </div>
</div>
  </div>
<div id="Level2" class="tab-pane fade">
  <h3>Level 2 Rules</h3>
 <div class="table-responsive">
 <table id="example1" class="table table-hover" cellspacing="0" width="100%">
<thead>
<tr role="row">
<th>Name</th>
<th>Country</th>
<th>State/Region</th>
<th>Tax Rate</th>
<th></th>
</tr>
</thead>
<tbody>
<?php 
/*`tid`, `tex_enable`, `textype`, `level`, `texname`, `c_val`, `countryid`, `s_val`, `statename`, `texrate`, `status`*/
$querydata =mysqli_query($con,"SELECT * FROM `texdataadd` where level='2'"); while($rowData=mysqli_fetch_array($querydata)){ 
$cid=$rowData['countryid'];
$sid=$rowData['s_val'];?>
 <tr> 
     <td><?php echo $rowData['texname']; ?></td>  
     <?php if($rowData['c_val'] ==2 ){ ?> 
     <?php $queryc =mysqli_query($con,"SELECT * FROM `country` where id='$cid'");  $rowc=mysqli_fetch_array($queryc); ?> 
      <td><?php echo $rowc['country']; ?></td>
      <?php }else{?>
      <td><?php echo "Apply Rule to All Countries"; ?></td> 
      <?php }?>
         <?php if($rowData['s_val'] ==2 ){ ?> 
     <?php $querysa =mysqli_query($con,"SELECT * FROM `state` where id='$sid'");  $rows=mysqli_fetch_array($querysa); ?> 
      <td><?php echo $rows['statename']; ?></td>
      <?php }else{?>
      <td><?php echo "Apply Rule to All State"; ?></td> 
      <?php }?>
      <td><?php echo $rowData['texrate']; ?>%</td>
      <td><a  href="deletetex.php?tid=<?php echo $rowData['tid'];  ?>"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>   
    </tr>
    <?php }?>
    
 <!-- <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>
     <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>
  <tr> 
     <td>IGST</td>   
      <td>India</td>
      <td>Applies to any state</td>
      <td>18.00%</td>
      <td><a href="#"><i class="fa fa-minus-circle pull-right" style="color:#FF6600;"></i></a> </td>

    </tr>-->
    
    </tbody>
	</table>
  
  </div>
  
  </div>
 
 <div id="Create" class="tab-pane fade">
  <h3>Add New Tax Rule</h3> 
   <div class="tax_forms">
<div class="form-horizontal">
  <div class="form-group">
    <label class="control-label lbls col-sm-2 " for="">Level :</label>
    <div class="col-sm-10 bcolor">
      <select class="inptfld" name="Level" id="Level"><option>1</option><option>2</option></select>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Name :</label>
    <div class="col-sm-10 bcolor"> 
  <input type="text" name="texName" id="texName" class="inptfld"/>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Country :</label>
    <div class="col-sm-10 bcolor"> 
    
    <label class="radio-inline bcolor">
      <input type="radio" name="optradio" id="Country" value="1">Apply Rule to All Countries 
    </label><br>

    <label class="radio-inline bcolor">
      <input type="radio" name="optradio" id="Country" value="2">Apply to Specific Country
    </label>
    
        <label class="radio-inline bcolor">
     <select  class="inptfld" id="countryid"  name="countryid" onChange="showUser(this.value)">
                      <option value="0">Select Country</option>
                      <?php  $content = "SELECT * FROM   country"; 
					  $cat_quer = mysqli_query($con,$content) ; 
					while($mycat_row = mysqli_fetch_array($cat_quer)){ 
					$patientid=$mycat_row['id'];?>
                      <option value="<?php  echo $mycat_row['id'];?>">
                      <?php  echo $mycat_row['country'];?>
                      </option>
                      <?php }?>
                    </select>
    </label>
    
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">State :</label>
    <div class="col-sm-10 bcolor"> 
    
    <label class="radio-inline">
      <input type="radio" name="stateoption" id="stateoption" value="1">Apply Rule to All State 
    </label><br>

    <label class="radio-inline">
      <input type="radio" name="stateoption" id="stateoption" value="2">Apply to Specific State
    </label>
    
        <label class="radio-inline ">
     <select  class="inptfld" id="state"  name="state">
                      <option value="0">Select</option>
                    </select>
    </label>
    
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label lbls col-sm-2" for="">Tax Rate :</label>
    <div class="col-sm-10 bcolor"> 
  <input type="text" name="texRate" class="inptfld" id="texRate"/>
    </div>
  </div>
 <center> <button type="submit" name="AddRule" class="btn btn-primary">Add Rule</button></center><br>
    </div> 
  
 </div>
  </div>
</div> 
</div> 
</div>  
</div> 
</section>
</form>
<script>
function SubmitFormData() {
    var name = $("#name").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var gender = $("input[type=radio]:checked").val();
	 var phone = $("#phone").val();
	var stateoption = $("input[type=radio]:checked").val();
	 var phone = $("#phone").val();
    $.post("texData.php", { name: name, email: email, phone: phone, gender: gender,name: name, email: email, phone: phone, gender: gender },
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
    });
}
</script> 
 <script> 
function showUser(str) { 
    if (str == "") { 
        document.getElementById("state").innerHTML = ""; 
        return;
 
    } else { 
 
        if (window.XMLHttpRequest) { 
            // code for IE7+, Firefox, Chrome, Opera, Safari 
            xmlhttp = new XMLHttpRequest(); 
        } else {
 
            // code for IE6, IE5 
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
        }
 
        xmlhttp.onreadystatechange = function() { 
            if (this.readyState == 4 && this.status == 200) { 
                document.getElementById("state").innerHTML = this.responseText; 
            } 
        };
 
        xmlhttp.open("GET","../getstate.php?q="+str,true); 
        xmlhttp.send(); 
    } 
} 
</script>
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end-------> 

  </body>
</html>