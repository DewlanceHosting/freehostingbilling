   <?php  include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script> 
    <script src="function.js"></script>
   
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
 $(document).ready(function(){
  var date_input=$('input[name="dateofbirth"]'); //our date input has the name "date"
  var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
  date_input.datepicker({
   format: 'dd/mm/yyyy',
   container: container,
   todayHighlight: true,
   autoclose: true,
  })
 })
</script>
   <style> 
#example tr:nth-child(2n) {
  background-color: #F3F3F3;
}

 
#example tr {
  background-color: white;
}
 
</style>
<script>
function domailnname() {
  var domainId = $("#domainId").val(); //alert(domainId);
    var Domain = $("#Domain").val();  //alert(Domain); 
      $.post("actionwork.php", { domainId: domainId, Domain: Domain },
    function(data) {
	 $('#domainRs').html(data);
	 // alert(data);
	// location.reload();
	 $('#myForm')[0].reset();
    });
}
</script>  
<script>
function OnchangeDataAccept() {
  var Accepid = $("#Accepid").val(); //alert(Accepid);
    var Statusdata = $("#Statusdata").val(); // alert(Statusdata);
	 var Product = $("#Product").val(); // alert(Statusdata);
      $.post("actionwork.php", { Accepid: Accepid, Statusdata: Statusdata, Product: Product},
    function(data) {
	 $('#results').html(data);
	 // alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script> 
<script>
function BillingCycle() {
    var producid = $("#producid").val(); //alert(Accepid);
    var Billing = $("#Billing").val(); // alert(Statusdata);
	$.post("actionwork.php", { producid: producid, Billing: Billing },
    function(data) {
	 $('#NewBillDataview').html(data);
	  alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script> 
<script>
function rightDataonchage() {
	var Amount = $("#Amount").val(); // alert(Statusdata);
    var Requiring = $("#Requiring").val(); // alert(Statusdata);
	var NextDue = $("#NextDue").val(); //alert(Accepid);
    var OrderPlacedOn = $("#OrderPlacedOn").val(); // alert(Statusdata);
	var UserIddata = $("#UserIddata").val(); //alert(Accepid);
      $.post("actionwork.php", { Amount: Amount, Requiring: Requiring, NextDue: NextDue, OrderPlacedOn: OrderPlacedOn, UserIddata: UserIddata  },
    function(data) {
	 $('#RightView').html(data);
	 // alert(data);
	 //location.reload();
	 $('#myForm')[0].reset();
    });
	}
</script>   
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!----------------------------------headerpart-end-------------------------------------> 
  
<div class="clientprofile">
<div class="container">
<h3><strong>View/Modify Product</strong></h3><br />
<div class="proftabb">
<ul class="navadminn">
  <li class="active"> <a data-toggle="tab" href="#Modify">Modify Profile</a></li>
  <li> <a data-toggle="tab" href="#Invoice">Invoice</a></li>
  <li> <a data-toggle="tab" href="#Transaction">Transaction</a></li>
</ul>

<div class="tab-content">
  <div id="Modify" class="tab-pane fade in active">
<!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
<div class="modiffyprodct">
 <?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where  status='1'"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
 
<?php  $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where  ordercancel='0' && transactionid ='$getid'");  $rowcount=mysqli_num_rows($queser); 
  $rowser=mysqli_fetch_array($queser); $usrid = $rowser['user_rid']; $slfals = $rowser['id']; ?>
   <input type="hidden" id="UserIddata" value="<?php echo $slfals; ?>">
   
 <?php $queser1=mysqli_query($con,"SELECT * FROM `user_domainpay` where  ordercancel='0' && transactionid ='$getid'");  $rowcount1=mysqli_num_rows($queser1); 
  $rowser1=mysqli_fetch_array($queser1);    $usrid1 = $rowser1['id']; ?>
  
    <input type="hidden" id="domainId" value="<?php echo $usrid1; ?>">
  <input type="hidden" id="Accepid" value="<?php echo $getid; ?>">
   <?php   $_SESSION['sts']=$usrid; $que=mysqli_query($con,"SELECT * FROM `user_ragistration` where  id ='$usrid'");  $rowdata=mysqli_fetch_array($que); 
   $pass=md5($rowdata['userpass']);   $usrp=$rowser['producid'];   
   
    $queprodu=mysqli_query($con,"SELECT * FROM `productadd` where  producid='$usrp'");  $rowqueprodu=mysqli_fetch_array($queprodu); 
   $billtype=$rowqueprodu['billtype'];
   //$dataView=$rowdata['id']; $fsf=$rowdata['contryid'];?>
   <input type="hidden" id="producid" value="<?php echo $usrp; ?>">
   <?php 
  $uds=$rowser['plan_name']; //base64_decode($_GET['1']);
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
         $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
      //  echo  "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		//echo $json->{'data'}->{'acct'}
		  //print_r($json);
        // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
		if($userdetails->{'name'} == $uds){
		 // echo "\t" . $userdetails->{'name'} . "\n"; 
     } }
    } 
    curl_close($curl); 
	?>
    
    <input type="hidden" id="pakname" value="<?php echo $userdetails->{'name'}; ?>" > 
     <form action="Datafunction.php?1=<?php  echo base64_encode($rowdata['id']);?>" method="post">
<div class="row">
<div class="col-sm-6">
<div class="form-horizontal">
 <?php //echo $rowdata['viewcpanelstatus']; 
	if(isset($_GET['domainpro'])){ }else{ ?>

  <div class="form-group">
    <label class="control-label col-sm-3" for="Product">Product/Service :</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="Product" onChange="OnchangeDataAccept();"><option><?php echo $rowqueprodu['modulid']; ?></option>
    <?php $quePro=mysqli_query($con,"SELECT * FROM `productadd`"); while($rowPro=mysqli_fetch_array($quePro)){ ?> 
    <option><?php echo $rowPro['modulid']; ?></option>
    <?php } ?>
    </select> 
    </div>
  </div>   
  
  <?php }?>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Domain">Domain Name :</label>
    <div class="col-sm-9" id="domainRs"> 
      <input type="text" class="form-control" id="Domain" value="<?php echo $rowser1['domain_name']; ?>" onChange="domailnname();" placeholder="Example.com">
    </div>
  </div>
   <?php //echo $rowdata['viewcpanelstatus']; 
	if(isset($_GET['domainpro'])){ }else{ ?>
    <div class="form-group">
    <label class="control-label col-sm-3" for="cpuser">Cpanel User :</label>
    <div class="col-sm-5"> 
      <input type="text" class="form-control" id="cpuser"  value="<?php echo $rowdata['fname']; ?>" placeholder="cpuser">
    </div>
    <?
    $user = "root";
     $token = $rowc['apikdy']; 
    $query = "https://$stval/json-api/listaccts?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
        $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		// print_r($json);
        
        foreach ($json->{'data'}->{'acct'} as $userdetails) { 
	 if(($userdetails->{'user'} == $rowdata['fname']) && ($userdetails->{'email'} == $rowdata['email_id'])){ 
	 
	 $whmusername = "root";
$cpanel_user = $rowdata['fname'];
# The contents of /root/.accesshash
$token = $rowc['apikdy']; 
    $query = "https://$stval/json-api/create_user_session?api.version=1&user=$cpanel_user&service=cpaneld";

$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);

$header[0] = "Authorization: WHM $whmusername:" . preg_replace("'(\r|\n)'","",$token);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl, CURLOPT_URL, $query);

$result = curl_exec($curl);

if ($result == false) {
  
    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");
}


$decoded_response = json_decode( $result, true );
$session_url = $decoded_response['data']['url'];
$cookie_jar = 'cookie.txt';
//print_r($session_url);
curl_setopt($curl, CURLOPT_HTTPHEADER, null);             // Unset the authentication header.
curl_setopt($curl, CURLOPT_COOKIESESSION, true);          // Initiate a new cookie session.
curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie_jar);       // Set the cookie jar.
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie_jar);      // Set the cookie file.
curl_setopt($curl, CURLOPT_URL, $session_url);            // Set the query url to the session login url.

echo $result = curl_exec($curl); 
                              // Execute the session login call.
if ($result == false) {
    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");
                                                    // Log an error if curl_exec fails.
} ?>
      
		 <div class="col-sm-4"> 
      <a href="<?php echo $session_url; ?>"><button type="button" >Login to cPanel</button></a>
    </div>
<?php //echo $session_url; 
//print_r(str_replace("URL=/","URL=https://167.160.174.209:2087/",$result));
 		
		 }  }   } 
    curl_close($curl); 
?>    
    
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="examplepass">Cpanel Pass :</label>
    <div class="col-sm-9"> 
      <input type="password" class="form-control"   id="password"   maxlength="16"  value="<?php echo $pass; ?>"  >
    </div>
  </div> <?php }?>
  <script>function checkLength(el) {
  if (el.value.length <= 4) {
    alert("length must be Min 5 characters")
  }
}</script>
  <?php   $stdta=$rowser['status']; ?>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">Service Status :</label>
    <div class="col-sm-9"> 
       <select class="form-control" id="Statusdata" onChange="OnchangeDataAccept();"> 
        <option value="<?php if($stdta == '1'){  echo"1";  } elseif($stdta == '0'){ echo"0"; }elseif($stdta == '2'){ echo"2"; }elseif($stdta == '3'){ echo"3"; }elseif($stdta == '4'){ echo"4"; } ?> "> <?php if($stdta == '1'){  echo"Active";  } elseif($stdta  == '0'){ echo"Pending"; }elseif($stdta == '2'){ echo"Suspended"; }elseif($stdta == '3'){ echo"Terminated"; }elseif($stdta == '4'){ echo"Cancelled"; } ?> </option>
       <option value="0">Pending</option>
       <option value="1">Active</option> 
       <option value="2">Suspended</option>
       <option value="3">Terminated</option>
       <option value="4">Cancelled</option>
       </select>
    </div>
  </div> 
</div>
</div>
<!---------------------------------------fffffffffffffffffffffffffffffffffff------------------>
 
<div class="col-sm-6">
<div class="form-horizontal">
  <div class="form-group">
    <label class="control-label col-sm-4" for="Payment">Payment Method :</label>
    <div class="col-sm-8">
      <select class="form-control" id="Payment" onChange="BillingCycle();">
      <option>PayPal</option>
      <!-- <option>MasterCard</option>-->
      </select>
    </div>
  </div>
   <!-----------------------------------------------optionMasterCardoption--------------------------->
  <div id="RightView">
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Amount">Amount :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="Amount" value="<?php echo $rowser['total']; ?>"  onChange="rightDataonchage();">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Requiring">Requiring Amount :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="Requiring" value="<?php echo"0"; ?>" onChange="rightDataonchage();">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Orderplaced">Order Placed On :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" name="dateofbirth" id="OrderPlacedOn"  value="<?php echo $rowser['transectiondate']; ?>" onChange="rightDataonchage();" >
    </div>
  </div> 
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Orderplaced">Next Due Date :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control"  name="dateofbirth" id="NextDue"  value="<?php echo $rowser['nexduedate']; ?>" onChange="rightDataonchage();"  >
    </div>
  </div> 
   
  </div>
   
  <!-----------------------------------------------optionMasterCardoption--------------------------->
  <div class="form-group">
    <label class="control-label col-sm-4" for="Terminated">Terminated On :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="TerminatedOn"  value="<?php echo $rowser['trasfsnsectiondate']; ?>" onChange="rightDataonchage();" >
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-4" for="Billing">Billing Cycle :</label>
    <div class="col-sm-8"> 
       <select class="form-control" id="Billing" onChange="BillingCycle();">
       <option ><?php if($billtype  == 'Monthly'){  echo"Monthly";  } elseif($billtype == 'Quarterly'){ echo"Quarterly"; }elseif($billtype == 'Annualy'){ echo"Annualy"; }?> </option>
      <option>Monthly</option>
     <option>Quarterly</option>
     <option>Annualy</option>
       </select>
    </div>
  </div>  
</div>
</div>
 
</div>
<!--<center><button>savechange</button></center>
--></form>
					
<!-------------------------------ghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh---------------------------->

<!--<div class="listservisdata">
<h3>Product And Services</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Item</th>
      <th>Description</th>
      <th>Billing Cycle</th>
       <th>Amount</th>
       <th>Status</th>
       <th>Payment Status</th>
    </tr>
  </thead>
  <tbody>
<?php //`user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`?>
  <?php $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where  status='1' && id ='$getid'");  $rowcount=mysqli_num_rows($queser); 
  while($rowser=mysqli_fetch_array($queser)){  
  
    $date1=$rowser['transectiondate'];
 $date=date_create($date1);
date_add($date,date_interval_create_from_date_string("40 days"));
 $tiondate=date_format($date,"d-m-Y"); ?>
    <tr>
      <td><h4><?php echo $rowser['plan_name']; ?></h4> </td>
      <td><?php echo $rowser['transectiondate']; ?></td>
       <td><?php echo $tiondate; ?></td>
       <td><a href="view-modifyproduct.php?edit=<?php echo $rowser['id']; ?>"><h4>Modify/View</h4></a></td>
       <td><a href="#"><h4>Delete</h4></a></td>
    </tr>
    <?php }?>
   
  </tbody>
</table>
</div>
 
</div>-->
<script>
$(document).ready(function(){
    $(document).ajaxStart(function(){
        $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $("#wait").css("display", "none");
    });
   // $("button").click(function(){
//        $("#results").load("cpanelcreate.php");
//    });
	 
});
</script>

<script>
$(document).ready(function(){
    $(document).ajaxStart(function(){
        $("#wait1").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $("#wait1").css("display", "none");
    });
     
	// $("button").click(function(){
//        $("#results").load("cpanelcreate.php");
//    });
	 
});
</script>
<script>
$(document).ready(function(){
    $(document).ajaxStart(function(){
        $("#wait2").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $("#wait2").css("display", "none");
    });  
	 $("button").click(function(){
        $("#Rmailmais").load("actionwork1.php");
    });
});
</script>
<!--ghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh-->
<div id="results"></div>
<div id="Rmailmais"></div>
<!--<div id="wait" style="display:none;width:69px;height:189px; position:absolute;top:50%;left:50%;padding:2px;"><img src='loading.gif' width="164" height="164" /><br>Loading..</div>
<div id="wait1" style="display:none;width:69px;height:189px; position:absolute;top:50%;left:50%;padding:2px;"><img src='loading.gif' width="164" height="164" /><br>Loading..</div>
<div id="wait2" style="display:none;width:69px;height:189px; position:absolute;top:50%;left:50%;padding:2px;"><img src='loading.gif' width="164" height="164" /><br>Loading..</div>
<div id="waitz" style="display:none;width:69px;height:189px; position:absolute;top:50%;left:50%;padding:2px;"><img src='loading.gif' width="164" height="164" /><br>Loading..</div>-->
<script>function Createmsg() {alert("You are already created Cpanel A\c"); }</script>
<script>function supendmsg() {alert("You are already Suspend Cpanel A\c"); }</script>
<script>function temintmsg() {alert("You are already Terminate Cpanel A\c"); }</script>
 <?php //echo $rowdata['viewcpanelstatus']; 
	if(isset($_GET['domainpro'])){ }else{ ?>
<div class="modulebutn">
<div class="row">
<div class="col-md-12">
<div class="form-group">

    <label class="control-label col-sm-3" for="Product">Module Function :</label>
    <div class="col-sm-9">
    <?php //echo $rowdata['viewcpanelstatus']; 
	 
	
	 if ($rowdata['viewcpanelstatus'] == '1') { 
    ?>
      <button type="button" class="btn btn-default" style="background:#CCCCCC;" onClick="Createmsg();">Create</button>
       <button type="button" class="btn btn-default" onClick="SuspendApiFormData();">Suspend</button>
        <button type="button" class="btn btn-default" onClick="UNSuspendApiFormData();">Unsuspend</button>
         <button type="button" class="btn btn-default" onClick="DeleteApiFormData();">Terminate</button>
          <button type="button" class="btn btn-default" onClick="ChagePackage();">Change Package</button>
           <button type="button" class="btn btn-default" onClick="ChangePassWord();">Change Password</button>
           <?php }else if ($rowdata['viewcpanelstatus'] == '2') { ?>
        <button type="button" class="btn btn-default" onClick="Createmsg();">Create</button>
       <button type="button" class="btn btn-default"  style="background:#CCCCCC;" onClick="supendmsg();">Suspend</button>
        <button type="button" class="btn btn-default" onClick="UNSuspendApiFormData();">Unsuspend</button>
         <button type="button" class="btn btn-default" onClick="DeleteApiFormData();">Terminate</button>
          <button type="button" class="btn btn-default" onClick="ChagePackage();">Change Package</button>
           <button type="button" class="btn btn-default" onClick="ChangePassWord();">Change Password</button>
   <?php }else if ($rowdata['viewcpanelstatus'] == '3') { ?>
          <button type="button" class="btn btn-default" onClick="CreateApiFormData();">Create</button>
       <button type="button" class="btn btn-default" onClick="SuspendApiFormData();">Suspend</button>
        <button type="button" class="btn btn-default" onClick="UNSuspendApiFormData();">Unsuspend</button>
         <button type="button" class="btn btn-default"   style="background:#CCCCCC;" onClick="temintmsg();">Terminate</button>
          <button type="button" class="btn btn-default" onClick="ChagePackage();">Change Package</button>
           <button type="button" class="btn btn-default" onClick="ChangePassWord();">Change Password</button>
    <?php  }?>
            
    </div>
  </div>
  </div>
</div>
</div>

<center>
<button type="button" class="btn btn-success btn-lg" onClick="MailSendData();">Resend Welcome E-mail</button>
</center>
<input type="hidden" id="newmailid" value="<?php echo $rowdata['email_id']; ?>"> 
 <input type="hidden" id="peremailid" value="<?php echo $rowdata['email_id']; ?>"> 
 <input type="hidden" id="uSerid" value="<?php echo $usrid; ?>">
</div> 
</div><span id="Rmailmais"></span>
<?php }?>
<script>
function MailSendData() {
    var Domain = $("#Domain").val();
    var cpuser = $("#cpuser").val();
    var password = $("#password").val(); 
	 var newmailid = $("#newmailid").val();
	 var uSerid = $("#uSerid").val();  //alert(uSerid); 
    $.post("mailsend.php", { Domain: Domain, cpuser: cpuser, password: password, newmailid: newmailid, uSerid: uSerid },
    function(data) {
	 $('#Rmailmais').html(data);
	     alert(data);
	 $('#myForm')[0].reset();
    });
}
</script>
<!-----------------------1--------Creat User in cPenal process-------------------------------------->
<script>function CreateApiFormData() {
confirm("Do You want create");
    var Product = $("#Product").val(); // alert(Product);
    var Domain = $("#Domain").val();  //alert(Domain);
    var cpuser = $("#cpuser").val(); // alert(cpuser);
    var password = $("#password").val(); // alert(password);
	 var peremailid = $("#peremailid").val();  //alert(peremailid);
	  
    $.post("cpanelcreate.php", { Product: Product, Domain: Domain, cpuser: cpuser, password: password, peremailid: peremailid },
    function(data) {
	 $('#results').html(data);
	 window.open('view-modifyproduct.php','_self');
	   //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
<!---------------2----------------Delete User in cPenal process-------------------------------------->
<script>function DeleteApiFormData() {
confirm("Do You want delete This User");
    var name = $("#cpuser").val(); //alert(Product); 
	  
    $.post("removeacct.php", { name: name  },
    function(data) {
	 $('#results').html(data);
	  window.open('view-modifyproduct.php','_self');
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
<!------------------------3-------Suspend User in cPenal process-------------------------------------->
<script>function SuspendApiFormData() {
confirm("Do You want Suspend This User");
    var susname = $("#cpuser").val(); //alert(Product); 
	  
    $.post("removeacct.php", {susname: susname  },
    function(data) {
	 $('#results').html(data);
	  window.open('view-modifyproduct.php','_self');
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
<!-----------------------4-------- UNSuspend User in cPenal process-------------------------------------->
<script>function UNSuspendApiFormData() {
confirm("Do You want Unsuspend This User");
    var unsusname = $("#cpuser").val(); //alert(Product); 
	  
    $.post("removeacct.php", {unsusname: unsusname  },
    function(data) {
	 $('#results').html(data);
	  window.open('view-modifyproduct.php','_self');
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
<!---------------------5----------ChangePassWord User in cPenal process-------------------------------------->
<script>function ChangePassWord() {
confirm("Do You want Change Password This User");
    var passunsusname = $("#cpuser").val(); //alert(unsusname); 
	 var password = $("#password").val(); //alert(password); 	  
    $.post("removeacct.php", {passunsusname: passunsusname, password: password  },
    function(data) {
	 $('#results').html(data);
	  window.open('view-modifyproduct.php','_self');
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>

<!---------------------6----------Chage Package Name User in cPenal process-------------------------------------->
<script>function ChagePackage() {
confirm("Do You want Change Package Name This User");
    var Packuser = $("#cpuser").val(); //alert(unsusname); 
	 var PackageName = $("#PackageName").val(); //alert(password); 	  
    $.post("removeacct.php", {Packuser: Packuser, PackageName: PackageName },
    function(data) {
	 $('#results').html(data);
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>

  <div id="Invoice" class="tab-pane fade">
<div class="listservisdata">
<h3>Invoice List</h3>
<div class="table-responsive">
 


<table id="example1" class="table table-hover" cellspacing="0" width="100%">
				<thead>
				 <tr>
                     <th>SR</th>
      <th>Date of Registration</th>
      <th>Invoice Amount</th>
      <th>Product</th>
       <th>Payment Method</th>  
         <th>Payment Status</th>
       <th>View</th>
       <th>Action</th>
    </tr>
				</thead>
				 
				<tbody>
   <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
 <?php $i=0; $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay`");  $rowcount=mysqli_num_rows($queser); 
  								while($rowser=mysqli_fetch_array($queser)){  $usrid = $rowser['user_rid']; $i++;  ?>
   
   <tr>
    <td><?php echo $i; ?></td>
      <td>
      <h4><?php echo $rowser['transectiondate']; ?></h4>
      </td>
      <td>&dollar;<?php echo $rowser['total']; ?></td>
       <td><?php echo $rowser['plan_name']; ?></td>
        <td><?php echo $rowser['paymethod'];?></td> 
       <?php if($rowser['total'] == '0'){?>
       <td><span style="color:#FF0000">Unpaid</span></td>  
<?php } else{?>
  <td>Paid</td>
 <?php } ?>
       <td><a  href="invoice_detail.php?voi=<?php echo $rowser['id'];  ?>"><h4>View</h4></a></td>
       <td><a  href="view-modifyproduct.php?voi=<?php echo $rowser['id'];  ?>"><h4>Delete</h4></a></td>
    </tr>
      <?php }?>
    
    
  </tbody>
			</table>
</div>
</div>


  </div>
  
  
  <div id="Transaction" class="tab-pane fade">
<div class="listservisdata">
<h3>Transaction List</h3>
<div class="table-responsive">
 
 
<table id="example" class="table table-hover" cellspacing="0" width="100%">
				<thead>
					<tr>
      <th>Payment Gateway</th>
      <th>Transaction ID</th>
      <th>Amount</th>
       <th>Date</th>
       <th>Modify</th>
       <th>Delete</th>
    </tr>
				</thead>
				 
				<tbody>
  <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
 <?php  $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay`");  $rowcount=mysqli_num_rows($queser); 
  								while($rowser=mysqli_fetch_array($queser)){  $usrid = $rowser['user_rid'];  ?>
   
    <tr>
      <td>
      <h4><?php echo $rowser['paymethod']; ?></h4>
      </td>
      <td><?php echo $rowser['transactionid']; ?></td>
       <td>&dollar;<?php echo $rowser['total']; ?></td>
        <td><?php echo $rowser['transectiondate']; ?></td>
       <td><a href="#"><h4>Edit</h4></a></td>
       <td><a href="#"><h4>Delete</h4></a></td>
    </tr>
    <?php }?>
     
  </tbody>
			</table>
</div>
</div>
  </div>
</div>
</div>
</div>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example1').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
 
 
 <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end-------> 

  </body>
</html>