<?php  include_once('../fn/connect.php'); ?> 
<?php  if(isset($_POST['dname'])){
$upid = $_POST['dname'];
 $rundata = mysqli_query($con,"UPDATE `cpenal_control` SET `status` = '1' WHERE id='$upid'");
 		if($rundata){
echo '<center><button onClick="CpenalControl();" class="btn btn-danger">Deactivate</button> <button class="btn btn-danger" id="confbtn1">Configure</button></center></span>';	
	} } ?>  
    
    <?php  if(isset($_POST['name'])){
$upid = $_POST['name'];
 $rundata = mysqli_query($con,"UPDATE `cpenal_control` SET `status` = '0' WHERE id='$upid'");
 		if($rundata){
echo '<center><button onClick="DpenalControl();" class="btn btn-danger">Activate</button></center></span>';	
	} } ?>
	
     <?php  if(isset($_POST['ipname'])){
  $upid = $_POST['idd'];
  $ipnumber = $_POST['ipname'];
  $apikey = $_POST['apikey'];
 $rundata = mysqli_query($con,"UPDATE cpenal_control SET ipnumber='$ipnumber', apikdy='$apikey' WHERE id='$upid'");
 		if($rundata){
echo 'save chage compleated';	
	} } ?>
	
     
     
     
     
    
    <?php /////////////////////////////////////////////////////////////////////// 
	
	  if(isset($_POST['username'])){
$upid = $_POST['dname'];
 echo $rundata = mysqli_query($con,"UPDATE modulecontrol SET status='1'");
 		if($rundata){
echo '<center><button onClick="CpenalControl();" class="btn btn-danger">Deactivate</button> <button class="btn btn-danger" id="confbtn1">Configure</button></center></span>';	
	} } ?>  
    
    <?php  if(isset($_POST['dusername'])){
$upid = $_POST['name'];
 $rundata = mysqli_query($con,"UPDATE `modulecontrol` SET `status`= '0'");
 		if($rundata){
echo '<center><button onClick="DpenalControl();" class="btn btn-danger">Activate</button></center></span>';	
	} } ?>
	 
    
     <?php //APIUsername: APIUsername, WSMS: WSMS, SMS: SMS, Accesss: Accesss	 
	   if(isset($_POST['APIUsername'])){
$APIUsername = $_POST['APIUsername'];
$WSMS = $_POST['WSMS'];
$SMS = $_POST['SMS'];
$Accesss = $_POST['Accesss'];
 $rundata = mysqli_query($con,"INSERT INTO `modulecontrol` (`userName`, `fieldname`, `accesstype`, `access_status`, `nor_status`, `cpenal_status`, `status`)
 														VALUES ('$APIUsername', '$WSMS', '$SMS', '$Accesss', '0', '1', '1')");
 		if($rundata){
echo 'User Data saved';	
	} } ?>
    
    
    
    
    