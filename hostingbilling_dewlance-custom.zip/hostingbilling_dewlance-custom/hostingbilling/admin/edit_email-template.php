  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
  <?php include_once('header.php'); ?> 
  <!--headerpart-end--> 

<?php $updatedata=$_GET['edit']; $queryProduc = mysqli_query($con,"SELECT * FROM `cat_template` where id='$updatedata'"); $ProducName =mysqli_fetch_array($queryProduc);  ?>
<section class="clientdashh">
<div class="container">
<div class="listservisdata">
<div class="row">
  <div class="col-md-offset-2 col-md-8 col-md-offset-2">
  <div class="prodform">
<form class="form-horizontal" action="passcheck.php" method="post" enctype="multipart/form-data">
<h4>Edit Email Template Account Registration</h4><br>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Type">From Name :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="fromname" name="fromname" value="<?php echo $ProducName['fromname']; ?>" placeholder="Billing Department">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">From Email :</label>
    <div class="col-sm-9"> 
       <input type="text" class="form-control" id="" name="frommail" value="<?php echo $ProducName['frommail']; ?>" placeholder="Sales@domain.com">
    </div>
  </div>
   
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">Subject :</label>
    <div class="col-sm-9"> 
       <input type="text" class="form-control" id="" name="subject" value="<?php echo $ProducName['subject']; ?>" placeholder="Welcome to (company.name)">
    </div>
  </div>
  
  <div class="form-group" style="margin:0 5px 10px;">
   <textarea name="content" data-provide="markdown" rows="8" class="md-input"><?php echo $ProducName['description']; ?></textarea>
    </div>
  
   <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <div class="checkbox">
        <label><input type="checkbox" name="Enabled" value="1"> Enabled</label>
      </div>
    </div>
  </div>
 
 
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
    <div class="pull-right">
    <button type="reset" class="btn btn-default">Cancel</button>
    <?php if(isset($updatedata)){ ?>
     <input type="hidden" name="updateid" value="<?php echo $updatedata;?>">
      <button type="submit" class="btn btn-danger" name="UpdateData">Update Template</button>
      <?php }else{ ?>
        <input type="hidden" name="type" value="<?php echo $_POST['EmailType'];?>">
  <input type="hidden" name="tempname" value="<?php echo $_POST['templatname'];?>">
      <button type="submit" class="btn btn-danger" name="submitdata">Create Template</button>
      <?php } ?>
      </div>
    </div>
  </div>
</form> 
</div> 
</div> 
</div> 

</div>
</div>
</section> 

 <!--home--contant----end---> 
 <?php include_once('footer.php'); ?>
 <!----------footer---end-------> 

  </body>
</html>