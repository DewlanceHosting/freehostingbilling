  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script> 
      <script src="function.js"></script>
    <script>
    $(document).ready(function() {
$(".ndx").click(function(){
  // alert(); 
var element = $(this);
var updatename = element.attr("pid");
  
 var data = 'r=getmyvitaldetails1' + '&updatename=' + escape(updatename);

 // alert(data); 
 $.ajax({
   type: "POST",
    url:'editpackage.php',
   data: data,
   success: function(data){   
  // alert(data); 
$("#pricelisupdate").html(data);
 }
 
}); 
return false; 
});
});

function SubmitFormData() {
 
 $("#imgLoading").show();
   $("#imgLoading").hide(1500);
					 
//alert();
    var inputModule = $("#inputModule").val(); //alert(inputModule); 
    //var gender = $("input[type=radio]:checked").val();
    $.post("productsData.php", { inputModule: inputModule},
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
	 //alert(data); 
    });
}
</script> 
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!--headerpart-end--> 
<div class="clientprofile">
<div class="container">
<div class="listservisdata">
<h3><strong>Hosting Product List</strong></h3>
<div class="proftabb">
<ul class="navadminn">
<li  class="active"> <a data-toggle="tab" href="#Duplicate">Group List</a></li>
  <li> <a data-toggle="tab" href="#Group"> Create New Group</a></li> 
  <li> <a data-toggle="tab" href="#Create">Create product</a></li>
</ul>

<div class="tab-content">

<div id="Group" class="tab-pane fade">
  <h3>Create Group</h3>
  <div class="row">
  <div class="col-md-6">
  <div class="prodform">
<form class="form-horizontal" action="Datafunction.php" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label class="control-label col-sm-3" for="Module">Product Group Name</label>
    <div class="col-sm-9">
          <input type="text" class="form-control" id="" name="ProductName">
    </div>
  </div>

  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-danger" name="ProductNameSubmit">Submit</button>
    </div>
  </div>
</form>

</div> 
</div>
</div>
<h3>List of group list</h3>
  <div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Group Name</th>
      <th>product Assigned</th>
    </tr>
  </thead>
  <tbody>
  <?php // producid modulid groupid decrip pemail rdomailn pricetype price billtype adddate status
  
  $queryProduc = mysqli_query($con,"SELECT * FROM `productgroupadd`"); while($ProducName = mysqli_fetch_array($queryProduc)){ $matchdata=$ProducName['pgroupid'];?>
    <tr>
      <td><?php   $update=base64_decode($_GET['1']); 
	  if($update == $matchdata){ 
	  ?>
     <form action="Datafunction.php?D=<?php  echo base64_encode($ProducName['pgroupid']);  ?>" method="post">
       <input type="text" class="form-control" name="textval" value="<?php echo $ProducName['producname']; ?>">
      <?php } else{?>
     
      <h4><?php echo $ProducName['producname']; ?></h4>
      <?php }?>
      </td>
        <?php if($ProducName['status'] == '1'){?> 
<td> 
       <a href="deletegroup.php?Assign=<?php  echo $ProducName['pgroupid'];?>&Val=0"><button class="btn btn-info">Not Assign</button></a> 

<?php } else{?>

 <td>
       <a href="deletegroup.php?Assign=<?php  echo $ProducName['pgroupid'];?>&Val=1"><button class="btn btn-info">Assigned</button></a> 

 <?php } ?> 
 <?php if($update == $matchdata){ 	  ?>
       <button type="submit" class="btn btn-warning">Update</button> </form>
      <?php } else{?> 
     <a href="hostingproduct.php?1=<?php  echo base64_encode($ProducName['pgroupid']);  ?>"><button class="btn btn-danger">Edit</button></a>
      <?php }?>
        
      <a href="deletegroup.php?Groupid=<?php  echo $ProducName['pgroupid'];  ?>"><button class="btn btn-danger">Delele</button></a>
       </td>
       
    </tr>
    <?php }?>
    <!--<tr>
      <td>
      <h4>XXXXXXX XXXXXXX</h4>
      </td>
       <td>
       <button class="btn btn-info">Assign</button>
       <button class="btn btn-danger">Delele</button>
       </td>
       
    </tr>-->
  </tbody>
</table>
</div>
  </div>


  <div id="Duplicate" class="tab-pane fade in active">
   <div id="pricelisupdate">
  <h3>List of group list</h3>
  <div class="table-responsive">
<table class="table table-hover">
  
 <?php $queryProductG = mysqli_query($con,"SELECT * FROM `productgroupadd` where status=1"); while($ProducNameG = mysqli_fetch_array($queryProductG)){ 
 $pdata=$ProducNameG['pgroupid'];?>
   <thead>
  <tr>
      <th colspan="6"><?php  echo $ProducNameG['producname']; ?></th>
    </tr>
    <tr>
      <th>Product Name</th>
      <th>Payment Type</th>
      <th>Stock</th>
      <!--<th>Auto Setup</th>-->
      <th>Categories</th>
      <th>Order Link</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
     <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productadd` where groupid='$pdata'"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?>
    <tr> 
      <td><h4><?php echo $ProducName['modulid']; ?></h4></td>
       <td><?php echo $ProducName['pricetype']; ?></td>
       <td>-</td>
        <!--<td>Yes After First Payment</td>-->
        <td><a href="../hosting-category.php">XXXXXXXX</a></td>
        <td><a href="../hosting-category.php?1p=<?php echo $ProducName['modulid']; ?>">XXXXXXXX</a></td>
       <td><a  href="#" class="ndx"pid="<?php echo $ProducName['producid'];  ?>"><button class="btn btn-info" type="button"> Edit </button></a>&nbsp;&nbsp;
       <a  href="deletedata.php?id=<?php echo $ProducName['producid'];  ?>"><button class="btn btn-danger">Delete</button></a></td> 
    </tr>
      <?php } ?>
  </tbody>
   <?php } ?>
</table>
</div>
</div>
  </div>
 

 <script>
$(document).ready(function() {
$(".ndx").click(function(){
  // alert(); 
var element = $(this);
var updatename = element.attr("pid");
  
 var data = 'r=getmyvitaldetails1' + '&updatename=' + escape(updatename);

 // alert(data); 
 $.ajax({
   type: "POST",
    url:'editpackage.php',
   data: data,
   success: function(data){   
  // alert(data); 
$("#pricelisupdate").html(data);
 }
 
}); 
return false; 
});
});

function SubmitFormData() {
 
 $("#imgLoading").show();
   $("#imgLoading").hide(1500);
					 
//alert();
    var inputModule = $("#inputModule").val(); //alert(inputModule); 
    //var gender = $("input[type=radio]:checked").val();
    $.post("productsData.php", { inputModule: inputModule},
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
	 //alert(data); 
    });
}
</script> 






  
  <div id="Create" class="tab-pane fade">
  <h3>Create Product</h3> 
  <div class="row">
  <div class="col-md-6">
  <div class="prodform" style="min-height:120px;">
<div class="form-horizontal">

 <div class="form-group">
    <label class="control-label col-sm-3" for="Email">Module Name:</label>
    <div class="col-sm-7">
      <select name="servertype" id="inputModule" class="form-control select-inline" onChange="SubmitFormData();">
      <option class="active" value="">None</option>
      <option value="cpanel">cPanel</option>
      <option value="plesk">ABC</option></select>
    </div>
     <div class="col-sm-2">
      <div id='imgLoading' style='display:none; height:35px;'><img src="loading.gif"  width="10" alt="Uploading...."/></div>
     </div>
  </div>
 <?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
  <div id="results">
<!-- <div class="form-group">
    <label class="control-label col-sm-3" for="Module">Select Package:</label>
    <div class="col-sm-9">
          <select class="form-control" id="Module"><option value="">select</option>
   <?  $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O"; 
    $query = "https://$stval:2087/json-api/listpkgs?api.version=1"; 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query); 
      $result = curl_exec($curl); 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            echo "<option value=". $userdetails->{'name'} .">" . $userdetails->{'name'} ." Supercheap ". "</option>";
        }
    } 
    curl_close($curl); ?>   
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Group:</label>
    <div class="col-sm-9">  
      <select class="form-control" id="pnameGroup"><option value="">select</option>
      <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productgroupadd` where status='1'"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?>
      <option value="<?php echo $ProducName['pgroupid']; ?>"><?php echo $ProducName['producname']; ?></option>
      <?php }?>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Description:</label>
    <div class="col-sm-9"> 
      <textarea class="form-control" rows="4" placeholder="Enter Description" id="descrip"></textarea>
    </div>
  </div>
  
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Email">Product Email:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" id="Email" placeholder="Enter Email">
    </div>
  </div>
  
  
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <div class="checkbox">
        <label><input type="checkbox" class="checkbox1"> Allow domain registration with with this product</label>
      </div>
    </div>
  </div>
  
  
  <div class="checkkedtoggle">
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
     <label class="radio-inline">
      <input type="radio" name="optradio">Free
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio">One Time
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio">Requiring
    </label>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="Price" placeholder="Enter Price">
    </div>
  </div> 
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price : Billing Cycle</label>
    <div class="col-sm-9"> 
     <select class="form-control" id="BillingType">
     <option>Monthly</option>
     <option>Quarterly</option>
     <option>Annualy</option>
     </select>
    </div>
  </div>
  </div>
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-danger" id="submit">Submit</button>
    </div>
  </div>-->
  </div> 
  
  
</div>

</div> 
</div>
</div> 
 
  
  </div>  
</div> 
</div> 
</div>
</div>
</div>


 
 
 <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>