<?php include_once('../fn/connect.php'); 

// sus: sus, term: term, fist: fist, secod: secod, tecket: tecket, checkdata: checkdata 


$sus=$_POST['sus'];
$term=$_POST['term'];
$fist=$_POST['fist'];
$secod=$_POST['secod'];
$tecket=$_POST['tecket'];
$checkdata=$_POST['checkdata'];

$updateq = "UPDATE automation_table SET `sus_no`= '$sus',`term_no`='$term', `checkedno`='$checkdata', `first_renewal`='$fist', second_renewal='$secod', `ticketclosed`='$tecket'";
 $rundata =mysqli_query($con,$updateq);
if($rundata){
echo "Update Data";
}
 
 ?>
   