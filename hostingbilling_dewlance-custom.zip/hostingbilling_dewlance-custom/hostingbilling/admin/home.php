  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<script>
 $(document).ready(function(){
  var date_input=$('input[name="dateofbirth"]'); //our date input has the name "date"
  var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
  date_input.datepicker({
   format: 'mm/dd/yyyy',
   container: container,
   todayHighlight: true,
   autoclose: true,
  })
 })
</script>
  </head>
  <body>
  
   <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata"); $add=0;  ?>
  
  <!--headerpart-end-->
   
<div class="admin-section">
<div class="container">
<div class="row">

<!--<div class="col-md-4">
<div class="admin_box">
<h3>Important Link</h3>
<ul class="admnn_list">
<li><a href="#">Shortcut</a></li>
<li><a href="#">Link-</a></li>
<li><a href="#">Most Usable</a></li>
<li><a href="#">Link- on</a></li>
</ul>


</div>

</div>-->
  

<div class="col-md-4">
<div class="admin_box">
<h3>This Year <?php echo date('Y');?> <input type="hidden"  value="" name="dateofbirth" id="yeardata"></h3> 
 
<?php  $todaydate= date('d-m-Y');    $querydata=mysqli_query($con,"SELECT * FROM `user_hostingpay` WHERE status=1 && transectiondate = '$todaydate'"); 
  while($rowquery=mysqli_fetch_array($querydata)){     $Today= $Today + $rowquery['total'];  $_SESSION['TodayVall'] = $Today; }  ?> 
  
<h4>Today : <span>&dollar;<?php if(isset($_SESSION['TodayVall'])){ echo $_SESSION['TodayVall']; }else{ echo "0";} ?> </span></h4>

<?php $todaydate = date('01-m-Y'); $querydata=mysqli_query($con,"SELECT * FROM `user_hostingpay` WHERE status=1 &&  transectiondate >= '$todaydate'"); 
  while($rowquery=mysqli_fetch_array($querydata)){     $addMon= $addMon + $rowquery['total'];  $_SESSION['MonthlyVall'] = $addMon; }  ?> 
  
<h4>This Month : <span>&dollar; <?php if(isset($_SESSION['MonthlyVall'])){ echo $_SESSION['MonthlyVall']; }else{ echo "0";} ?></span></h4>
  
 <?php  $todaydate= date('01-01-Y');    $querydata=mysqli_query($con,"SELECT * FROM `user_hostingpay` WHERE status=1 &&  transectiondate >= '$todaydate'"); 
  while($rowquery=mysqli_fetch_array($querydata)){     $add= $add + $rowquery['total'];   ?> 
 <?php $_SESSION['YearVall'] = $add; }?>
 <h4>Total : <span>&dollar; <?php if(isset($_SESSION['YearVall'])){ echo $_SESSION['YearVall']; }else{ echo "0";}?></span></h4>
</div>

</div>
<?php $querc=mysqli_query($con,"SELECT * FROM `ticket_sale` where status =0"); $rowTicket=mysqli_num_rows($querc); $rowc=mysqli_fetch_array($querc); $stval=$rowc['status']; ?> 

<div class="col-md-4">
<div class="admin_box">
<h3>Total ticket</h3>

<h4><a href="support.php">Number of open ticket : <span><?php echo $rowTicket; ?></span></a></h4>

<h4><a href="support.php">Number of existing ticket : <span><?php echo $rowTicket; ?></span></a></h4>

<ul class="admnn_list">
<!--<li><a href="#">Maximum list of open ticket (10)</a></li>
-->
</ul>


</div>

</div>
<?php $querc=mysqli_query($con,"SELECT * FROM `user_hostingpay` where status =1"); $rowcount1=mysqli_num_rows($querc); $rowc=mysqli_fetch_array($querc); $stval=$rowc['status']; ?> 
<?php $querc=mysqli_query($con,"SELECT * FROM `user_hostingpay` where status =2"); $rowcount=mysqli_num_rows($querc);  $stval=$rowc['status']; ?>
<div class="col-md-4">
<div class="admin_box" >
<h3>Order</h3>

<h4><a href="listoforder.php">Pendig Order : <span><?php echo $rowcount1; ?></span></a></h4>

<h4><a href="">Cancellation Order : <span><?php echo $rowcount; ?></span></a></h4>

</div>

</div>

</div>


<div class="row"> 

<div class="col-md-4">
<div class="admin_box">
<h3>Admin last login (5)</h3>

<!--(`id`, `subscriber_name`, `action_performed`, `date_added`)-->
<?php $querydata=mysqli_query($con,"SELECT * FROM `audit_loginadmin` ORDER BY `id` DESC limit 5"); while($rowdata=mysqli_fetch_array($querydata)){ ?>
<div class="iplogin">
<h5><?php echo $rowdata['ip']." ".$rowdata['action_performed']; ?></h5>
<p><span class="datsys"><?php echo $rowdata['date_added']; ?></span> <span class="admnuser"><?php echo $rowdata['subscriber_name']; ?></span></p>
</div>
<?php } ?>

<!--<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>

<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>

<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>

<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>-->


</div>

</div> 

<div class="col-md-4">
<div class="admin_box" style="height: 359px; overflow: scroll;">
<h3>Client last login (100)</h3>
<!--(`id`, `subscriber_name`, `action_performed`, `date_added`)-->
<?php $querydata=mysqli_query($con,"SELECT * FROM `audit_loginuser`ORDER BY `id` DESC limit 100"); while($rowdata=mysqli_fetch_array($querydata)){ ?>
<div class="iplogin">
<h5><?php echo $rowdata['ip']." ".$rowdata['action_performed']; ?></h5>
<p><span class="datsys"><?php echo $rowdata['date_added']; ?></span> <span class="admnuser"><?php echo $rowdata['subscriber_name']; ?></span></p>
</div>
<?php } ?>

<!--
<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>

<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>

<div class="iplogin">
<h5>122.161.240.214,</h5>
<p><span class="datsys">yyyyMMddHHmmss</span> <span class="admnuser">dewlance</span></p>
</div>-->


</div>

</div>



</div>


</div>
</div>
 
  <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 
  

  </body>
</html>