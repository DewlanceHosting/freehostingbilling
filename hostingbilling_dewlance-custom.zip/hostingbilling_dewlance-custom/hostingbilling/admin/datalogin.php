<?php  session_start();
include_once('../fn/connect.php');  
date_default_timezone_set("asia/kolkata");
  
?>  
 <?php   
 if(isset($_POST['adminName'])){
$username = $_POST['adminName'];
$userpass = md5($_POST['adminpass']);
$datime=date('d-m-Y h:i:s a');
$qry = "SELECT * FROM admin WHERE useremail='".$username."' AND userpass='".$userpass."' AND status='0'";
$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);
if( $num_row == 1 ) {
	echo '<center><img src="images/Crystal_Login-successful.png" style="width:100px; height:100px;"></center>';
	$nad=$row['username'];
  $ip = $_SERVER['REMOTE_ADDR'];
$run = mysqli_query($con,"INSERT INTO `audit_loginadmin` (`subscriber_name`, `action_performed`,`ip`, `date_added`) VALUES ('$nad','Login', '$ip', '$datime')");
	$_SESSION['adminemailSession'] = $username;
	$_SESSION['adminpassSession'] = $userpass;
	 $_SESSION['fnamessSession'] = $row['useremail'];
	  $_SESSION['fnamessSession'] = $row['mobile'];
	  $_SESSION['adminid'] = $row['id'];
	}
else {
	echo 'false';
}}
   ?>  