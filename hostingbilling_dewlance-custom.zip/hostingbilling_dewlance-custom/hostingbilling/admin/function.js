
//////////////////////////////////////////////SUBMIT/////////////////////////////////////////////////////////////////////
$(document).ready(function(){
$("#submit").click(function(){
							//alert();
//var pname = $("#pname").val();
var Module = $("#Module").val();
var pnameGroup = $("#pnameGroup").val();
var descrip = $("#descrip").val();
var Email = $("#Email").val();
var  domain = $("input[type=checkbox]:checked").val();
var PriceType = $("input[type=radio]:checked").val();
var Price = $("#Price").val();
var BillingType = $("#BillingType").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString =  '&Module='+ Module + '&pnameGroup='+ pnameGroup + '&descrip='+ descrip + '&Email='+ Email + '&domain='+ domain + '&PriceType='+ PriceType + '&Price='+ Price + '&BillingType='+ BillingType;

if(Module==''||pnameGroup==''||descrip==''||Email==''|| domain==''||PriceType==''||Price==''|| BillingType=='')
{
alert("Please Fill All Fields");
}
else
{
	alert(dataString);
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "Datafunction.php",
data: dataString,
cache: false,
success: function(result){
alert(result);
}
});
}
return false;
});
});

