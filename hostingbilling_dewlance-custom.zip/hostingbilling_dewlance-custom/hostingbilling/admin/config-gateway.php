  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!--headerpart-end--> 
<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<div class="row">
<div class="col-md-6">
<h3>Gateway List</h3>
</div>
<div class="col-md-6">



<div class="form-group">
    <label class="control-label col-sm-5" style="margin-top:6px;">Gateway module to configure:</label>
    <div class="col-sm-7">
    <select class="form-control" id="">
    <option>Select</option>
    <option>Paypal</option> 
    </select>
        </div>
  </div>
  
</div>
</div> 


<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th width="10">API Username</th>
      <th width="10">API Password</th>
       <th width="10">Signature </th>
       <th width="10">Bussiness Email Id</th>
       <th width="10">Bussiness Transection URL for Paypal</th>   
         </tr>
  </thead>
  <tbody>
  <?php $queryProduc = mysqli_query($con,"SELECT * FROM `paygetwaydata`"); while($ProducName =mysqli_fetch_array($queryProduc)){  ?>
    <tr>
      <td >
      <h4><?php echo $ProducName['paymentaccount']; ?></h4> </td>
      <td><?php echo $ProducName['apipass']; ?></td>
      <td><h4><?php echo $ProducName['apising']; ?></h4></td>
      
       <td><?php echo $ProducName['paymentaccount']; ?></td>
      <td><h4><?php echo $ProducName['ticketenmode']; ?></h4></td> 
    </tr>
    <?php } ?>  
  </tbody>
</table>
</div>

</div> 
</div>

</section> 
 
 <!--home--contant----end--->
   
 <div class="footer">
 <div class="container">
 <div class="powered">
 <h4>Powered by : <span>Dewlance</span></h4>
 </div>
 </div>
 
 <div class="copyright">
 <div class="container">
 <p>© 2017 Dewlance Web Hosting All Rights Reserved. | Developed by <a href="http://dewlance.com/">dewlance</a></p>
 </div>
 </div>
 
 </div>
 <!----------footer---end-------> 
<script>
$(document).ready(function(){
$('select').change(function () {
    if ($(this).val() == "Paypal") {
        $('#paypalmodl').modal('show');
    }
});
});
</script>

<script>function EmailIdData() {
confirm("Do You want create PayPal,Email ID");
    var email = $("#email").val(); //alert(Product);
	var optradio = $("#paypalurl").val(); //alert(Product);
    var Username = $("#Username").val(); //alert(Domain); 
    var Password = $("#Password").val(); //alert(cpuser);
	 var Signature = $("#Signature").val(); //alert(peremailid); 
	  var idEnable = $("input[type=checkbox]:checked").val();
    $.post("fData.php", { email: email, optradio: optradio, Username: Username, Password: Password, Signature: Signature, idEnable: idEnable },
    function(data) {
	 $('#SMSemail').html(data);
	 //alert(data);
	 setTimeout(function () { location.reload(1); }, 2000);
	 $('#myForm')[0].reset();
    });
}</script> 
<!-- MODAL paymentaccount paymentOption apiusername apipass  apising ticketenmode status-->
<div class="modal fade" id="paypalmodl">
  <div class="modal-dialog"> 

  <?php $quePro=mysqli_query($con,"SELECT * FROM `paygetwaydata`");  $rowPro=mysqli_fetch_array($quePro)  ?> 
    <div class="modal-content">
      <div class="modal-body"> 
      <button type="button" class="close" data-dismiss="modal"> <span aria-hidden="true">&times;</span> </button>
      <div class="payppalsec">
     <h4 class="modal-title">Manage Paypal Payment Standard</h4>
<form>
<div class="form-group">
    <label for="email" class="ppl">Bussiness Email Id</label>
    <input type="text" class="form-control"  value="<?php echo $rowPro['paymentaccount']; ?>" id="email" required>
  </div>
  <div class="form-group">
    <label for="email" class="ppl">Bussiness Transection URL for Paypal</label>
    <select class="form-control" id="paypalurl"><option><?php echo $rowPro['ticketenmode']; ?></option>
    <option>https://www.paypal.com/cgi-bin/webscr</option>
    <option>https://www.sandbox.paypal.com/cgi-bin/webscr</option>
     
    </select>
  </div>
  <div class="form-group">
    <label for="email" class="ppl">API Username</label>
    <input type="email" class="form-control"  value="<?php echo $rowPro['paymentaccount']; ?>" id="Username" required>
  </div>
  <!--<div class="form-group">
    <label for="Paymentopn" class="ppl">Payment Option</label><br> 
       <label class="radio-inline">
      <input type="radio" name="optradio" value="One time and subscription payment when possible">One time and subscription payment when possible
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio" value="One time payment only">One time payment only
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio" value="subscription payment only">subscription payment only
    </label> 
  </div>--> 
  
  <div class="form-group">
    <label for="Password" class="ppl">API Password</label>
    <input type="text" class="form-control" id="Password" value="<?php echo $rowPro['apipass']; ?>">
  </div> 
  <div class="form-group">
    <label for="Username" class="ppl">Signature</label>
    <input type="text" id="Signature" value="<?php echo $rowPro['apising']; ?>" class="form-control" id="Username">
  </div>
   <!-- <div class="form-group">
    <label for="Signature" class="ppl">API Signature</label>
    <input type="text" class="form-control" id="Signature">
  </div>
  <div class="checkbox">
    <label><input type="checkbox" name="idEnable" value="Tick Enable"> Tick to Enable Test Sandbox Mode ?</label>--><br>
<br>
<br>

  </div> 
  <button type="button" class="btn btn-danger" onClick="EmailIdData();">Updade Setting</button>
</form> 

<span id="SMSemail"></span>

<!--
<img src="camera.jpg" />
<h3>Camera <br> $0.01</h3>
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type='hidden' name='business' value='Paypal_Business_TestAccount_Id'>
<input type='hidden' name='item_name' value='Camera'>
<input type='hidden' name='item_number' value='CAM#N1'>
<input type='hidden' name='amount' value='0.01'>
<input type='hidden' name='no_shipping' value='1'>
<input type='hidden' name='currency_code' value='USD'>
<input type='hidden' name='notify_url' value='http://SITE NAME/payment.php'>
<input type='hidden' name='cancel_return' value='http://SITE NAME/cancel.php'>
<input type='hidden' name='return' value='http://SITE NAME/success.php'>
<!-- COPY and PASTE Your Button Code  
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="### COPY FROM BUTTON CODE ###">
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
</form>-->



</div>

      </div>
      
      
      
    </div>
    
    
    
    
  </div>
</div>

<?php  
/*
if (strcmp ($res, "VERIFIED") == 0) {
	// assign posted variables to local variables
	$item_name = $_POST['item_name'];
	$item_number = $_POST['item_number'];
	$payment_status = $_POST['payment_status'];
	$payment_amount = $_POST['mc_gross'];
	$payment_currency = $_POST['mc_currency'];
	$txn_id = $_POST['txn_id'];
	$receiver_email = $_POST['receiver_email'];
	$payer_email = $_POST['payer_email'];
	
	include("dbcontroller.php");
	$db = new DBController();
	
	// check whether the payment_status is Completed
	$isPaymentCompleted = false;
	if($payment_status == "Completed") {
		$isPaymentCompleted = true;
	}
	// check that txn_id has not been previously processed
	$isUniqueTxnId = false; 
	$result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
	if(empty($result)) {
        $isUniqueTxnId = true;
	}	
	// check that receiver_email is your PayPal email
	// check that payment_amount/payment_currency are correct
	if($isPaymentCompleted && $isUniqueTxnId && $payment_amount == "0.01" && $payment_currency == "USD") {
		$payment_id = $db->insertQuery("INSERT INTO payment(item_number, item_name, payment_status, payment_amount, payment_currency, txn_id) VALUES('$item_number', '$item_name', $payment_status, '$payment_amount', '$payment_currency', '$txn_id')");
	}
	// process payment and mark item as paid. 
	
	if(DEBUG == true) {
		error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
	} 
}
 */
 ?>

  

  </body>
</html>