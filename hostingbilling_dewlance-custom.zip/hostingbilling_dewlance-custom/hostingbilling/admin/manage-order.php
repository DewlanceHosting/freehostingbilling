  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
     
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script> 
    
  </head>
  <body>
  
   <?php include_once('header.php'); ?>
  
  <!--headerpart-end- --> 
  
   <?php   
   	$getiddata =base64_decode($_GET['edit']);
		//$searchdaata = $_POST['item_id'];
		 $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where id='$getiddata' && ordercancel='0'"); $rowser=mysqli_fetch_array($queser); 
			$uerid=$rowser['user_rid']; $producid=$rowser['producid'];
  $queClient=mysqli_query($con,"SELECT * FROM `user_ragistration` where  id='$uerid'");  $rowClient=mysqli_fetch_array($queClient);
  
  			$contryid=$rowClient['contryid']; $stateid=$rowClient['stateid']; $cityid=$rowClient['cityid'];
			
   $queClient1=mysqli_query($con,"SELECT * FROM `country` where  id='$contryid'");  $rowClient1=mysqli_fetch_array($queClient1);
    $queClient2=mysqli_query($con,"SELECT * FROM `state` where  id='$stateid'");  $rowClient2=mysqli_fetch_array($queClient2); 
	 $queClient3=mysqli_query($con,"SELECT * FROM `city` where  id='$cityid'");  $rowClient3=mysqli_fetch_array($queClient3);
 ?>
   <?php $quePro=mysqli_query($con,"SELECT * FROM `productadd` where  producid='$producid'");  $rowproduc=mysqli_fetch_array($quePro); ?>
<section class="clientdashh">
<div class="container"> 
<div class="listservisdata">
<h3>Manage Order</h3>

<div class="form_sec-manage">
<form class="form-horizontal">
<div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Date">Date :</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="Date" value="<?php echo $rowser['transectiondate'];?>" placeholder="" readonly>
    </div>
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Payment">Payment Method:</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" value="<?php echo $rowser['paymethod'];?>"  id="Payment" placeholder="PayPal" readonly>
    </div>
  </div>
</div>
</div>
<div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Order">Order # :</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" value="<?php echo $rowser['oderid'];?>"  id="Order" placeholder="" readonly>
    </div>
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Amount">Amount:</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" value="<?php echo $rowser['total'];?>"  id="Amount" placeholder="" readonly>
    </div>
  </div>
</div>
</div> 
<div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Order">Client :</label>
    <div class="col-sm-8">
    <div style="border:solid 1px #ddd; padding:6px 12px; border-radius:4px; background:#eee;">
    <pre><h4><?php echo "User Name : ".$rowClient['fname']." ".$rowClient['lname'];?></h4></pre>
     <pre> <?php echo "Address : ".$rowClient['add']."<br>".$rowClient['pin']."<br> City : ".$rowClient3['city']."<br> State : ".$rowClient2['statename']."<br> Country : ".$rowClient1['country']."<br> Mobile : ".$rowClient['mobile'];?></pre>
 
</div>
    </div>
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Amount">Status :</label>
    <div class="col-sm-8"> 
      <select class="form-control" id="Statusdata" onChange="OnchangeDataAccept();">
      <option><?php if( $rowser['status'] == '0'){ echo "Pending"; } else{ echo "Active"; } ?> </option>
      <option value="1">Active</option>
      <option value="0">Pending</option>
       </select>
    </div>
  </div>
</div>
</div> 
<div class="row">
<div class="col-sm-offset-6 col-sm-6">
<div class="form-group">
    <label class="control-label col-sm-4" for="Amount">IP Address :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>" readonly>
    </div>
  </div>
</div>
</div>
</form>
</div>  
<!-- producid  modulid groupid decrip  pemail  rdomailn  pricetype  price billtype  adddate  status-->

<div class="mngordr_table">
<div class="table-responsive">
<table id="" class="table table-hover" border="1">
				<thead>
					<tr>
                    <th style="width:15%;">Item</th>
                    <th style="width:30%;">Description</th>
                    <th style="width:15%;">Billing Cycle</th>
                    <th style="width:12%;">Amount</th>
                    <th style="width:13%;">Status</th>
                    <th >Payment Status</th>
                    </tr>
				</thead>
				 
				<tbody>
  <tr> 
     <td><h4><?php echo $rowproduc['modulid'];?></h4></td>   
      <td><p>Web Hosting (Spain-EU)-Bronze - Spain-EU</p>
      <p>example.com</p>
      </td>
      <td><?php echo $rowproduc['billtype'];?></td>
      <td>$ <?php echo $rowser['total'];?>.00 USD</td>
       <?php if($rowser['status'] == '0'){?> 
  
<td> Pending </td>  
<?php } else{?>

 <td> Active </td>

 <?php } ?>
  <?php if($rowser['total'] == '0'){?> 
  
<td> Incomplete </td>
<?php } else{?>

 <td> Complete </td>

 <?php } ?>
       
    </tr> 
    <tr style="background: #ecf0f8;color: #000;"> 
    </tr> 
    </tbody>
			</table>
</div>
</div> 
<div class="modulebutn" style="margin:0px;">
<center>
      <button type="button" class="btn btn-success" onClick="orderdataAccept();">Accept Order</button>&nbsp; &nbsp;&nbsp;
      <button type="button" class="btn btn-default" onClick="cancelOrderdata();">Cancel Order</button>&nbsp; &nbsp;&nbsp;
       <a  href="deletedata.php?mano=<?php echo $rowser['id'];  ?>"><button type="button" class="btn btn-danger">Delete Order</button></a>
</center>
</div> 
</div>  
</div> 
</section> 
<input type="hidden" id="Accepid" value="<?php echo $getiddata; ?>">
<input type="hidden" id="Cancelid" value="<?php echo $getiddata; ?>">
<script>
function OnchangeDataAccept() {
  var Accepid = $("#Accepid").val(); 
    var Statusdata = $("#Statusdata").val(); //alert(Accepid);
      $.post("actionwork.php", { Accepid: Accepid, Statusdata: Statusdata},
    function(data) {
	 $('#results').html(data);
	 //alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script>
<script>
function orderdataAccept() {
    var Accepid = $("#Accepid").val(); //alert(Accepid);
      $.post("actionwork.php", { Accepid: Accepid},
    function(data) {
	 $('#results').html(data);
	 //alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script>
 
 
<script>
function cancelOrderdata() {
    var Cancelid = $("#Cancelid").val();
      $.post("actionwork.php", { Cancelid: Cancelid},
    function(data) {
	 $('#results').html(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script>
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>