<?php
   include_once('../fn/connect.php'); 
   /////////////////////////////Delete Tex Rules  Rules/////////////////////////////////////

if (isset($_GET['tid']) && is_numeric($_GET['tid']))
 {
 // get id value
 $id = $_GET['tid'];
 }  
$rec8 = "DELETE FROM `texdataadd` WHERE   tid='$id'";

if(mysqli_query($con,$rec8)){
	 
	header('Refresh:1; url=tax-rules.php');
}
else{
	die("Data failed to delete in the database");
}
 
 ?>