  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script>
    function DataSubmit() { //alert();
	 var depid = $("#depid").val();
    var Dname1 = $("#Dname1").val();
    var descri1 = $("#descri1").val();
    var email1 = $("#email1").val();
    var hostname1 = $("#hostname1").val();
    var popes1 = $("#popes1").val();
    var hostemail1 = $("#hostemail1").val();
     var emailpass1 = $("#emailpass1").val(); 
	 
    $.post("datafuntion.php", { depid: depid,Dname1: Dname1, descri1: descri1, email1: email1, hostname1: hostname1, popes1: popes1, hostemail1: hostemail1, emailpass1: emailpass1 }, 
    function(data) { 
	 $('#results').html(data);
	  //alert(data);
	  window.open('support-ticket-department.php','_self')
	// location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>
    <script>
    function DataSubmit1() { //alert();
	
    var Dname = $("#Dname").val();
    var descri = $("#descri").val();
    var email = $("#email").val();
    var hostname = $("#hostname").val();
    var popes = $("#popes").val();
    var hostemail = $("#hostemail").val();
     var emailpass = $("#emailpass").val(); 
	 
    $.post("datafuntion.php", { Dname: Dname, descri: descri, email: email, hostname: hostname, popes: popes, hostemail: hostemail, emailpass: emailpass }, 
    function(data) { 
	 $('#results').html(data);
	  //alert(data);
	  window.open('support-ticket-department.php','_self')
	// location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>
  </head>
  <body>
  
  <?php include_once("header.php");  ?>
  <!--headerpart-end-->
  <!--`tdpid`, `name`, `emailid`, `description`, `hostname`, `pop`, `hemail`, `hemailpass`, `status`-->
<?php   $dataid= $_GET['edit']; $query = mysqli_query($con,"SELECT * FROM `add_ticket_depart` where tdpid='$dataid'"); $rowdata=mysqli_fetch_array($query); ?>

<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<h3><strong>Department Data</strong></h3>
<div class="formsectinadd">
<input type="hidden" id="depid" value="<?php echo $rowdata['tdpid']; ?>">
<form class="form-horizontal">
    <?php   if($_GET['edit']){?>
    
  <div class="form-group">
    <label class="control-label col-sm-3" for="Department">Department Name:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Dname1" value="<?php echo $rowdata['name']; ?>" placeholder="Department Name">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Description">Description:</label>
    <div class="col-sm-9">
      <textarea  class="form-control" id="descri1"   placeholder="Enter Description"><?php echo $rowdata['description']; ?></textarea>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Address:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" id="email1" value="<?php echo $rowdata['emailid']; ?>"  placeholder="Enter email">
    </div>
  </div>
  
<h4>POP Importing Confiration <small>(Only required if using POP3 Import method )</small></h4><br>
  
  
  
    <div class="form-group">
    <label class="control-label col-sm-3" for="Host">Host Name</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" value="<?php echo $rowdata['hostname']; ?>"  id="hostname1">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Description">POP3 Port:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" value="<?php echo $rowdata['pop']; ?>"  id="popes1">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Address:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" value="<?php echo $rowdata['hemail']; ?>"  id="hostemail1">
    </div>
  </div>
  
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Pass:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" value="<?php echo $rowdata['hemailpass']; ?>"  id="emailpass1">
    </div>
  </div> 

 
     <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-info" onClick="DataSubmit();">Update</button>
      <button type="reset" class="btn btn-success">Cancel </button>
          
    </div>
  </div>
      <?php }else{?>
      
  <div class="form-group">
    <label class="control-label col-sm-3" for="Department">Department Name:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Dname" value="<?php echo $rowdata['name']; ?>" placeholder="Department Name">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Description">Description:</label>
    <div class="col-sm-9">
      <textarea  class="form-control" id="descri"   placeholder="Enter Description"><?php echo $rowdata['description']; ?></textarea>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Address:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" id="email" value="<?php echo $rowdata['emailid']; ?>"  placeholder="Enter email">
    </div>
  </div>
  
<h4>POP Importing Confiration <small>(Only required if using POP3 Import method )</small></h4><br>
  
  
  
    <div class="form-group">
    <label class="control-label col-sm-3" for="Host">Host Name</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" value="<?php echo $rowdata['hostname']; ?>"  id="hostname">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Description">POP3 Port:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" value="<?php echo $rowdata['pop']; ?>"  id="popes">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Address:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" value="<?php echo $rowdata['hemail']; ?>"  id="hostemail">
    </div>
  </div>
  
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="email">Email Pass:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" value="<?php echo $rowdata['hemailpass']; ?>"  id="emailpass">
    </div>
  </div> 


       <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-info" onClick="DataSubmit1();">Add New Ticket Department</button>
      <button type="reset" class="btn btn-success">Cancel </button>
          
    </div>
  </div>
        
        <?php }?>
   
</form>
<div  id="results"></div>


</div>

</div>
</div>


</div>

</section>
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  </body>
</html>