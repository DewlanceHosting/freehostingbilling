<?php
   include_once('../fn/connect.php');   

if (isset($_GET['cl']) && is_numeric($_GET['cl']))
 {
 // get id value
 $id = $_GET['cl'];;
 } 

$rec = "DELETE FROM `user_hostingpay` WHERE  id='$id'";

if(mysqli_query($con,$rec)){
	echo "<center> <img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Please wait while you are redirected in 1 seconds..</h6></center>"."<br />";
	header('Refresh:1; url=listoforder.php');
}
else{
	die("Data failed to delete in the database");
}
?>
