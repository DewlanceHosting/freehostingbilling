  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!---The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags--->
     <?php include_once("tiltlechange.php"); ?>
   
    <!---- Bootstrap ----> 
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init"> 
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
    <script type="text/javascript" language="javascript" class="init"> 
$(document).ready(function() {
	$('#example1').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
       <style> 
#example tr:nth-child(2n) {
  background-color: #F3F3F3;
}

 
#example tr {
  background-color: white;
}
 
</style>   
  </head>
  <body> 
   <?php include_once('header.php');  ?>
  
  <!--headerpart-end-->
  
 <?php 
 		$getiddata2 =base64_decode($_GET['1']);
		$searchdaata = $_POST['item_id'];
 $que=mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$getiddata2' || fname='$searchdaata'"); $rowdata=mysqli_fetch_array($que);  $fsf=$rowdata['contryid'];
 $getiddata=$rowdata['id'];
 ?>
<div class="clientprofile">
<div class="container">

<ul class="navadminn">
  <li class="active"> <a data-toggle="tab" href="#Modify">Cliet Profile</a></li>
  <li> <a data-toggle="tab" href="#EditModify">Edit Modify Profile</a></li>
  <li> <a data-toggle="tab" href="#Invoice">Invoice</a></li>
  <li> <a data-toggle="tab" href="#Transaction">Transaction</a></li>
</ul>

<div class="tab-content">
  <div id="Modify" class="tab-pane fade in active">
<div class="row">

<div class="col-md-4">
<div class="prrfiledata">
<ul>
<h4>Client Details</h4>
<li>
<div class="row">
<div class="col-xs-6"><h5>Full Name :</h5></div>
<div class="col-xs-6"><h5><?php echo $uds= $rowdata['fname']; ?> &nbsp; <?php echo $rowdata['lname']; ?></h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Email :</h5></div>
<div class="col-xs-6"><h5><?php echo $rowdata['email_id']; ?> </h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Phone  :</h5></div>
<div class="col-xs-6"><h5><?php echo $rowdata['mobile']; ?> </h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Pincode :</h5></div>
<div class="col-xs-6"><h5><?php echo $rowdata['pin']; ?> </h5></div>
</div>
</li>
<li>
       <?php $quecontyr=mysqli_query($con,"SELECT * FROM `country` where id ='$fsf'"); $rowcdata=mysqli_fetch_array($quecontyr); ?>

<div class="row">
<div class="col-xs-6"><h5>Country :</h5></div>
<div class="col-xs-6"><h5><?php echo $rowcdata['country']; ?> </h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Account Status : </h5></div>
<div class="col-xs-6"><h5><?php if($rowdata['status'] == '1'){  echo"Active";  } else{ echo"In-Active"; } ?> </h5></div>
</div>
</li>
</ul>
</div>
</div>

<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
<?php 
  $uds=1002; //base64_decode($_GET['1']);
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/listaccts?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query); 
        $result = curl_exec($curl); 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
      //  echo  "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		//echo $json->{'data'}->{'acct'}
		  //print_r($json);
        // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
		if($userdetails->{'uid'} == $uds){
		// echo "\t" . $userdetails->{'user'} . "\n";  
?>
<div class="col-md-4">
<div class="prrfiledata">
<ul>
<h4>Client Activity</h4>
<li>
<div class="row">
<div class="col-xs-6"><h5>Client Since :</h5></div>
<div class="col-xs-6"><h5>4 Month</h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Last Login IP :</h5></div>
<div class="col-xs-6"><h5><?php echo $userdetails->{'ip'}; ?></h5></div>
</div>
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>IP Host Name  :</h5></div>
<div class="col-xs-6"><h5><?php echo $userdetails->{'domain'}; ?></h5></div>
</div>
</li>
</ul>
</div>
<?php  $gtotal=0;   
$queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where   user_rid ='$getiddata'");  $rowcount=mysqli_num_rows($queser); 
  while($rowser=mysqli_fetch_array($queser)){  $gtotal = $gtotal+$rowser['total'];
   }
   
   ?>

<div class="prrfiledata">
<ul>
<h4>Earning Details</h4>
<li>
<!--<div class="row">
<div class="col-xs-6"><h5>Earning :</h5></div>
<div class="col-xs-6"><h5>$XX <small>(earning from client)</small></h5></div>
</div>-->

</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Paid Invoice :</h5></div>
<div class="col-xs-6"><h5>&dollar; <?php echo $gtotal; ?></h5></div>
</div>
</li>
<li>
<!--<div class="row">
<div class="col-xs-6"><h5>Unpaid Invoice :</h5></div>
<div class="col-xs-6"><h5>$30 USD</h5></div>
</div>-->
</li>
<li>
 
<div class="row">
<div class="col-xs-6"><h5>Suspended Service :</h5></div>
<div class="col-xs-6"><h5><?php $i=mysqli_query($con,"SELECT * FROM `user_hostingpay` where id='$getiddata' && status='3'");  echo $j=mysqli_num_rows($i);
    while($r=mysqli_fetch_array($j)){ echo $c++;     } ?></h5></div>
</div>
 
</li>
<li>
<div class="row">
<div class="col-xs-6"><h5>Active Service : </h5></div>
<div class="col-xs-6"><h5> <?php $i=mysqli_query($con,"SELECT * FROM `user_hostingpay` where id='$getiddata' && status='0'");  echo $j=mysqli_num_rows($i);
    while($r=mysqli_fetch_array($j)){ echo $c++;     } ?></h5></div>
</div>
</li>
</ul>
</div>


<?php    } }
    }
 
    curl_close($curl);
	
	?>


</div>
<input type="hidden" id="ueid" value="<?php echo $getiddata; ?>">
 <script>function MailSend() { 
  var massagedata = $("#massagedata").val(); 
   var ueid = $("#ueid").val(); // alert(ueid);
  $.post("mailsend.php", {massagedata: massagedata, ueid: ueid },
   function(data) { 
   $('#MaiRview').html(data); // alert(data);  
    });}</script>
    
<div class="col-md-4">
<div class="prrfiledata">
<ul>
<h4>Action</h4>
<li>
<a href="#"><span id="showmenu3">Send email to client</span></a>
</li> 
<div class="menu3" style="display: none;">
<div class="input-group" style="padding:0 10%"> 
  <textarea cols="40" rows="10" id="massagedata"></textarea> 
  </div>
<button  class="btn btn-success" onClick="MailSend();">Send Request</button> 
 </div><br><div id="MaiRview">
<!--<li>
<a href="support-ticket-department.php">Open a new ticket</a>
</li>-->
<li>
<a href="">Close client A/C</a>
</li>
<li>
<td><a  href="deletedata.php?uid=<?php echo $rowdata['id'];  ?>">Delete client</a>
</li> 
</ul>
</div> 
</div>
  </div>
  <script>
  $(document).ready(function() {
        $('#showmenu3').click(function() {
                $('.menu3').slideToggle("fast");
        });
    });
</script>
  <br>
<div class="listservisdata">
<h3>Product And Services</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
       <th>Plan Name</th>
      <th>Date Created</th>
      <th>Next Due Date</th>
       <th>Edit</th>
       <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
  <?php $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where   user_rid ='$getiddata'");  $rowcount=mysqli_num_rows($queser); 
  while($rowser=mysqli_fetch_array($queser)){ 
    $date1=$rowser['transectiondate'];
 $date=date_create($date1);
date_add($date,date_interval_create_from_date_string("40 days"));
 $tiondate=date_format($date,"d-m-Y"); ?>
    <tr>
       <td> <h4><?php echo $rowser['plan_name']; ?></h4> </td>
      <td><?php echo $rowser['transectiondate']; ?></td>
       <td><?php echo $rowser['nexduedate']; ?></td>
       <td><a href="view-modifyproduct.php?edit=<?php echo $rowser['transactionid']; ?>"><h4>Modify/View</h4></a></td>
       <td><a  href="deletedata.php?voi=<?php echo $rowser['id'];  ?>&uifp=<?php echo $getiddata; ?>"><h4>Delete</h4></a></td>
    </tr>
    <?php }?>
   
  </tbody>
</table>
</div>


<h3>List Of Domain</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Domain Name</th>
      <th>Next Due</th>
      <th>Expiry Date</th>
      <th>Edit</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  
    <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
  <?php $queser=mysqli_query($con,"SELECT * FROM `user_domainpay` where   user_rid ='$getiddata'");  $rowcount=mysqli_num_rows($queser); 
  while($rowser=mysqli_fetch_array($queser)){  
  
    $date1=$rowser['transectiondate'];
 $date=date_create($date1);
date_add($date,date_interval_create_from_date_string("40 days"));
 $tiondate=date_format($date,"d-m-Y"); ?>
    <tr>
      <td> <h4><?php echo $rowser['domain_name']; ?></h4> </td>
      <td><?php echo $rowser['transectiondate']; ?></td>
       <td><?php echo $rowser['nexduedate']; ?></td>
        <td><a href="view-modifyproduct.php?edit=<?php echo $rowser['transactionid']; ?>&domainpro=1"><h4>Modify/View</h4></a></td>
        <td><a  href="deletedata.php?domain=<?php echo $rowser['id'];  ?>&uifp=<?php echo $getiddata; ?>"><h4>Delete</h4></a></td>
    </tr> 
     <?php }?>
    
  </tbody>
</table>
</div>
</div>  
 </div> 
 
 
  
  <div id="EditModify" class="tab-pane fade">
 <div class="row"> 
 <form action="Datafunction.php?1=<?php  echo base64_encode($rowdata['id']);?>" method="post">
<div class="col-md-7"> 

    <div class="loginpart">   
  <div class="form-group"> 	 
                <label for="firstname"><span class="req"> </span> First name: </label>
                    <input class="form-control" type="text" name="First" id="First" onKeyUp="Validate(this)" value="<?php echo $rowdata['fname']; ?>" required /> 
                        <div id="errFirst"></div>    
            </div>

            <div class="form-group">
                <label for="lastname"><span class="req"> </span> Last name: </label> 
                    <input class="form-control" type="text" name="Last" id="Last" onkeyup = "Validate(this)" value="<?php echo $uds= $rowdata['lname']; ?>" required />  
                        <div id="errLast"></div>
            </div>
   
   <div class="form-group">
    <label for="email">Compony Name:</label>
    <input type="text" class="form-control" id="Compony" name="Compony" value="<?php echo $uds= $rowdata['cmpname']; ?>" > 
  </div>
  <div class="form-group">
    <label for="email">Address:</label>
    <input type="text" class="form-control" id="Address" name="Address" value="<?php echo $uds= $rowdata['add']; ?> " > 
  </div>
  <div class="form-group">
                <label for="email"><span class="req"> </span> Email Address: </label> 
            <input class="form-control" required type="text" name="Email" id = "Email"  onchange="email_validate(this.value);" value="<?php echo $uds= $rowdata['email_id']; ?>"  />   
                        <div class="status" id="status"></div>
            </div> 
  
  <div class="form-group">
                <label for="password"><span class="req"></span> Password: </label>
                    <input   name="password" type="password" class="form-control inputpass" minlength="4" maxlength="17"  id="pass1" placeholder="Enter validate"/> </p>

                <label for="password"><span class="req"></span> Password Confirm: </label>
                    <input   name="Password" type="password" class="form-control inputpass" minlength="4" maxlength="17" placeholder="Enter again to validate" id="pass2" onKeyUp="checkPass(); return false;" />
                        <span id="confirmMessage" class="confirmMessage"></span>
            </div>
  <div class="row">
                  <div class="col-md-4">  <label for="example-text-input" class="col-sm-4"><strong>Country</strong><span style="color:#FF0000">*</span></label>
                    <select  class="form-control" id="country"  name="country" onChange="showUser(this.value)">
                      <?php $quecontyr=mysqli_query($con,"SELECT * FROM `country` where id ='$fsf'"); $rowcdata=mysqli_fetch_array($quecontyr); ?>
                      <option value="<?php echo $sta =$rowcdata['id']; ?>"><?php echo $rowcdata['country']; ?></option>
                      <?php  $content = "SELECT * FROM   country  order by id desc "; 
					  $cat_quer = mysqli_query($con,$content) ; 
					while($mycat_row = mysqli_fetch_array($cat_quer)){ 
					$patientid=$mycat_row['id'];?>
                      <option value="<?php  echo $mycat_row['id'];?>">
                      <?php  echo $mycat_row['country'];?>
                      </option>
                      <?php }?>
                    </select>
                    
                  </div>
                  <div class="col-md-4">  <label for="example-text-input" class="col-sm-4"><strong>State</strong><span style="color:#FF0000">*</span></label>
                    <select  class="form-control" id="state"  name="state" onChange="showUser1(this.value)">
                    <?php $questa=mysqli_query($con,"SELECT * FROM `state` where id ='$sta'"); $rowsta=mysqli_fetch_array($questa); ?>
                      <option value="<?php echo $cit =$rowsta['id']; ?>"><?php echo $rowsta['statename']; ?></option>
                    </select>
                  </div>
                  <div class="col-md-4"> <label for="example-text-input" class="col-sm-4"><strong>City</strong><span style="color:#FF0000">*</span></label><?php $quecity=mysqli_query($con,"SELECT * FROM `city` where id ='$cit'"); $rowcity=mysqli_fetch_array($quecity); ?>
                    <select  class="form-control"  name="city" id="city" >
                      <option  value="<?php echo $rowcity['id']; ?>"><?php echo $rowcity['city']; ?></option>
                    </select>
                  </div>
                </div>
  <div class="form-group">
    <label for="pwd">Pin No:</label> 
    <input required type="text" name="Pin" id="Pin" class="form-control phone"  maxlength="17" onKeyUp="validatephone(this);"  value="<?php echo $uds= $rowdata['pin']; ?>"/> 
  </div>
   <div class="form-group">
            <label for="phonenumber"><span class="req"></span> Phone Number: </label>
 <input required type="text" name="Mobile" id="Mobile" class="form-control phone"  maxlength="17" onKeyUp="validatephone(this);" value="<?php echo $uds= $rowdata['mobile']; ?>"/> 
            </div>  
 <button class="btn btn-danger" type="submit" > Save&Update </button> 
     </div>
       
</div> 
 
<div class="col-md-5">
:<div class="form-group"> 	 
                <label for="firstname"><span class="req"> </span> client status </label>
                    <select required class="form-control" name="status" id="status"><option value="">Select Status</option><option value="1">Active</option><option value="0">In-Active</option></select>
 
                             
            </div>
</div>

</form>
</div> 
  </div>
 
  <div id="Invoice" class="tab-pane fade">
<div class="listservisdata">
<h3>Invoice List</h3>
<div class="table-responsive">
 


<table id="example1" class="table table-hover" cellspacing="0" width="100%">
				<thead>
				 <tr>
                 <th>SR</th>
      <th>Date of Registration</th>
      <th>Invoice Amount</th>
      <th>Product</th>
       <th>Payment Method</th>  
         <th>Payment Status</th>
       <th>View</th>
       <th>Action</th>
    </tr>
				</thead> 
				<tbody>
                
   <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
   
 <?php $i=0; $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where   user_rid ='$getiddata'");  $rowcount=mysqli_num_rows($queser); 
  								while($rowser=mysqli_fetch_array($queser)){  $usrid = $rowser['user_rid']; $i++;  ?>
   
    <tr>
    <td><?php echo $i; ?></td>
      <td>
      <h4><?php echo $rowser['transectiondate']; ?></h4>
      </td>
      <td>&dollar;<?php echo $rowser['total']; ?></td>
       <td><?php echo $rowser['plan_name']; ?></td>
        <td><?php echo $rowser['paymethod'];?></td> 
       <?php if($rowser['total'] == '0'){?>
       <td><span style="color:#FF0000">Unpaid</span></td>  
<?php } else{?>
  <td>Paid</td>
 <?php } ?>
       <td><a  href="invoice_detail.php?voi=<?php echo $rowser['id'];  ?>"><h4>View</h4></a></td>
       <td><a  href="deletedata.php?voi=<?php echo $rowser['id'];  ?>&uifp=<?php echo $getiddata; ?>"><h4>Delete</h4></a></td>
    </tr>
      <?php }?>  
  </tbody>
 	</table>
</div>
</div> 
  </div> 
  
  <div id="Transaction" class="tab-pane fade">
<div class="listservisdata">
<h3>Transaction List</h3>
<div class="table-responsive">
 
<table id="example" class="table table-hover" cellspacing="0" width="100%">
				<thead>
					<tr>
                    <th>SR</th>
      <th>Payment Gateway</th>
      <th>Transaction ID</th>
      <th>Amount</th>
       <th>Date</th>
      <!-- <th>Modify</th>-->
       <th>Delete</th>
    </tr> </thead> 
				<tbody>
  <!-- `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
 <?php $i=0; $getid=$_GET['edit']; $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where   user_rid ='$getiddata'");  $rowcount=mysqli_num_rows($queser); 
  								while($rowser=mysqli_fetch_array($queser)){  $usrid = $rowser['user_rid']; $i++; ?>
   
    <tr>
     <td><?php echo $i; ?></td>
      <td>
      <h4><?php echo $rowser['paymethod']; ?></h4>
      </td>
      <td><?php echo $rowser['transactionid']; ?></td>
       <td>&dollar;<?php echo $rowser['total']; ?></td>
        <td><?php echo $rowser['transectiondate']; ?></td>
       <!--<td><a href="#"><h4>Edit</h4></a></td>-->
       <td><a  href="deletedata.php?voi=<?php echo $rowser['id'];  ?>&uifp=<?php echo $getiddata; ?>"><h4>Delete</h4></a></td>
    </tr>
    <?php }?> 
  </tbody>
			</table>
</div>
</div>
  </div> 
</div> 
</div>
</div>



<div class="clearfix"></div> 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 
  <script>function checkPass()
{
    //Store the password field objects into variables ...
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
    //Store the Confimation Message Object ...
    var message = document.getElementById('confirmMessage');
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
    if(pass1.value == pass2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Passwords Match"
    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Passwords Do Not Match!"
    }
} 
function validatephone(phone) 
{
    var maintainplus = '';
    var numval = phone.value
    if ( numval.charAt(0)=='+' )
    {
        var maintainplus = '';
    }
    curphonevar = numval.replace(/[\\A-Za-z!"£$%^&\,*+_={};:'@#~,.Š\/<>?|`¬\]\[]/g,'');
    phone.value = maintainplus + curphonevar;
    var maintainplus = '';
    phone.focus;
}
// validates text only
function Validate(txt) {
    txt.value = txt.value.replace(/[^a-zA-Z-'\n\r.]+/g, '');
}
// validate email
function email_validate(email)
{
var regMail = /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

    if(regMail.test(email) == false)
    {
    document.getElementById("status").innerHTML    = "<span class='warning'>Email address is not valid yet.</span>";
    }
    else
    {
    document.getElementById("status").innerHTML	= "<span class='valid'>Thanks, you have entered a valid Email address!</span>";	
    }
}
// validate date of birth
function dob_validate(dob)
{
var regDOB = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/;

    if(regDOB.test(dob) == false)
    {
    document.getElementById("statusDOB").innerHTML	= "<span class='warning'>DOB is only used to verify your age.</span>";
    }
    else
    {
    document.getElementById("statusDOB").innerHTML	= "<span class='valid'>Thanks, you have entered a valid DOB!</span>";	
    }
}
// validate address
function add_validate(address)
{
var regAdd = /^(?=.*\d)[a-zA-Z\s\d\/]+$/;
  
    if(regAdd.test(address) == false)
    {
    document.getElementById("statusAdd").innerHTML	= "<span class='warning'>Address is not valid yet.</span>";
    }
    else
    {
    document.getElementById("statusAdd").innerHTML	= "<span class='valid'>Thanks, Address looks valid!</span>";	
    }
}
</script>
    <script src="function.js" type="text/javascript">></script>
  <script> 
function showUser(str) { 
    if (str == "") { 
        document.getElementById("state").innerHTML = ""; 
        return;
 
    } else { 
 
        if (window.XMLHttpRequest) { 
            // code for IE7+, Firefox, Chrome, Opera, Safari 
            xmlhttp = new XMLHttpRequest(); 
        } else {
 
            // code for IE6, IE5 
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
        }
 
        xmlhttp.onreadystatechange = function() { 
            if (this.readyState == 4 && this.status == 200) { 
                document.getElementById("state").innerHTML = this.responseText; 
            } 
        };
 
        xmlhttp.open("GET","../getstate.php?q="+str,true); 
        xmlhttp.send(); 
    } 
} 
</script>

<script> 
function showUser1(str) { 
    if (str == "") {
 
        document.getElementById("city").innerHTML = ""; 
        return; 

    } else {  
        if (window.XMLHttpRequest) { 
            // code for IE7+, Firefox, Chrome, Opera, Safari
 
            xmlhttp = new XMLHttpRequest(); 
        } else { 
            // code for IE6, IE5 
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
        }
 
        xmlhttp.onreadystatechange = function() { 
            if (this.readyState == 4 && this.status == 200) { 
                document.getElementById("city").innerHTML = this.responseText;             }

  };
 xmlhttp.open("GET","../getcity.php?q="+str,true); 
        xmlhttp.send(); 
    } 
}  
</script> 

  </body>
</html>