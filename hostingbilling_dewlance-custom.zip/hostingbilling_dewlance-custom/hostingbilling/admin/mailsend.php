<?php  session_start();
include_once('../fn/connect.php');?>
<?php //$rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu); ?>
<?php
if(isset($_POST['massagedata'])){

 $userR = $_POST['ueid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata  
  $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
$dfs= $rowdata['urlink'];
 
$to = $Tomail;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>From : &nbsp; Admin</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Massage For Inform: &nbsp;'.$_POST['massagedata'].'</strong></p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);

echo 'Your mail has been sent successfully.';
 }
?>

<?php  ///Domain: Domain, cpuser: cpuser, password: password, newmailid: newmailid, uSerid: uSerid
if(isset($_POST['newmailid'])){
$Domain = $_POST['Domain'];
$cpuser = $_POST['cpuser'];
$password = $_POST['password'];
$newmailid = $_POST['newmailid'];

 $userR = $_POST['uSerid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
    $Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata 
 $rqeu = mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata=mysqli_fetch_array($rqeu);
 
$to = $Tomail;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>User Name: &nbsp;'. $cpuser.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Password: &nbsp;'. $password.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>This Your domain : &nbsp;'. $Domain.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $newmailid.'</strong></p>  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);

 }
 
 
?> 