<?php //idup: idup, opticket: opticket
include_once('../fn/connect.php');  
if(isset($_POST['ticketsub'])){
  $ticketsub = $_POST['ticketsub']; 
$Massage = $_POST['content'];
  $idupdate = $_GET['stival'];
 $post_image =  $_FILES['file']['name'];
		  $image_tmp =  $_FILES['file']['tmp_name'];
  move_uploaded_file($image_tmp,"images/$post_image");
 
 
 $insert_query = "UPDATE `suporttickte_maildata` SET `subject`='$ticketsub',`massagedata`='$Massage', attechfile='$post_image' WHERE  `id`='$idupdate'"; 
		$run = mysqli_query($con,$insert_query);
		if($run) { echo "Update sucsessfully"; 
		 header('Refresh:1; url=support-ticket.php');
		}
		} 
		 
 ?>