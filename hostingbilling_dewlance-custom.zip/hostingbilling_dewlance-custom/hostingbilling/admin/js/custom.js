$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');       
        }
    );
});




//  $(document).ready(function(){
//    $('.checkbox1').change(function(){
//        if(this.checked)
//            $('.checkkedtoggle').slideDown('slow');
//        else
//            $('.checkkedtoggle').slideUp('slow');
//
//    });
//});



function ShowHidebtn(id) {
  if ($(id).html() == "Activate") {
    $(id).html("Deactivate");
  } else {
    $(id).html("Activate");
  }

}




$(document).ready(function(){
    $(".forsrch a").click(function(){
        $(".serchfld").slideToggle();
    });
	
	 $("#checkAll").click(function () {
     $('input:checkbox').not(this).prop('checked', this.checked);
 });


	
});



















   $(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="col-sm-8"><label for="Attechment">Attechment</label><input class="form-control" type="file" name="mytext[]"><a href="#" class="remove_field pull-right">Remove</a></div>'); //add input box
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});





