<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script> 
  </head>
  <body>
  
  <?php include_once("header.php");  ?>
  
  <!--headerpart-end--> 

<div class="clientprofile">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">

<div class="proftabb">
<ul class="navadminn">
  <li class="active"> <a data-toggle="tab" href="#Company">Company Details</a></li>
  <li> <a data-toggle="tab" href="#Template">Template</a></li>
  <li> <a data-toggle="tab" href="#Language">System Language</a></li>
  <li> <a data-toggle="tab" href="#Mail">Mail</a></li>
</ul>
<?php 

//query =mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowdata =mysqli_fetch_array(query); ?>

<div class="tab-content">
  <div id="Company" class="tab-pane fade in active">
  <form action="datafuntion.php" method="post" enctype="multipart/form-data">
<div class="form-group">
    <label for="Company">Company Name :</label>
    <input type="text" class="form-control" id="cmpname" name="cmpname1" value="<?php echo $rowdata['cmpname']; ?>" >
  </div>

  <div class="form-group">
    <label for="email">Company Email :</label>
    <input type="email" class="form-control" id="email" name="email1" value="<?php echo $rowdata['cmpemail']; ?>">
  </div> 
  <div class="form-group">
    <label for="Phone">Company Domain :</label>
    <input type="text" class="form-control" id="Domain" name="Domain1" value="<?php echo $rowdata['domain']; ?>">
  </div>
  
  <div class="form-group">
    <label for="Code">Logo URL :</label>
    <input type="file" class="form-control" id="URLCode" name="URLCode1">
     <img src="../images/<?php echo $rowdata['urlink']; ?>"  style=" width:40px; height:20px;"> 
  </div>
  
  <div class="form-group">
    <label for="City">Pay To :</label>
    <textarea class="form-control" id="Payto" name="Payto1"><?php echo $rowdata['payto']; ?> </textarea>
  </div>
   
    <button type="submit" class="btn btn-danger">Update & Save</button>
</form>
  </div>
  <div id="Companyresults"></div>
  
    <script>
    function CompanyDataSubmit() { //alert();
    var cmpname = $("#cmpname").val(); //alert(cmpname);
    var email = $("#email").val();
    var Domain = $("#Domain").val();
    var URLCode = $("#URLCode").val();
    var Payto = $("#Payto").val(); 
	
    $.post("datafuntion.php", { cmpname: cmpname, email: email, Domain: Domain, URLCode: URLCode, Payto: Payto }, 
    function(data) { 
	 $('#Companyresults').html(data);
	  alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>
  
  
  <div id="Template" class="tab-pane fade">
<h3>Allow to change template of client area</h3> 
  </div>  
  <div id="Language" class="tab-pane fade">
<form>
  <div class="form-group">
    <label for="Charset">System Charset :</label>
    <input type="text" class="form-control" id="Charset">
  </div>

   <div class="form-group">
    <label for="Charset">Default Client Area Language :</label>
    <select class="form-control" id="langval">
  <?php $que=mysqli_query($con,"select *from langs"); while($rows=mysqli_fetch_array($que)){ ?>
     <option><?php echo $rows['name']; ?></option>
     <?php }?>
    </select>
  </div>
    <button type="button" class="btn btn-danger" onClick="lagDataSubmited();">Update & Save</button>
</form> <span id="SMSlangs"></span>
  </div> 
  
   <script>
    function lagDataSubmited() { //alert();
    var Charset = $("#Charset").val(); //alert(Charset);
    var langval = $("#langval").val(); 
    $.post("datafuntion.php", { Charset: Charset, langval: langval }, 
    function(data) { 
	 $('#SMSlangs').html(data);
	  alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>
    
    <?php 
//  // `mailtype`, `smtp`, `smpuser`, `etc`, `simg`,
$queryMail = mysqli_query($con,"SELECT * FROM `gernalemailidadd`"); $rowdataMail =mysqli_fetch_array($queryMail); ?>

  <div id="Mail" class="tab-pane fade">
 
  <div class="form-group">
    <label for="Mail">Mail Type :</label>
    <select class="form-control" id="Mailtype" name="Mailtype">
    <option><?php echo $rowdataMail['mailtype']; ?></option>
    <option>SMTP</option>
    <option>PHP mail</option>
    </select>
  </div>

   <div class="form-group">
    <label for="SMTP">SMTP Port :</label>
    <input type="text" class="form-control" id="SMTP" name="SMTP" value="<?php echo $rowdataMail['smtp']; ?>">
  </div>
  
  <div class="form-group">
    <label for="SMTPUser">SMTP User :</label>
    <input type="text" class="form-control" id="SMTPUser" name="SMTPUser" value="<?php echo $rowdataMail['smpuser']; ?>">
  </div>
  
  <div class="form-group">
    <label for="Etc">Etc :</label>
    <input type="text" class="form-control" id="Etc" name="etc" value="<?php echo $rowdataMail['etc']; ?>">
  </div>
  
  <div class="form-group">
    <label for="Signature">Email Signature :</label>
    <textarea class="form-control" id="ESign" name="ESign"><?php echo $rowdataMail['simg']; ?></textarea>
     
  </div> 
         
  
    <button type="button" class="btn btn-danger" onClick="MailDataSubmit();">Update & Save</button>
 

  </div> 
   <div id="Msults"></div> 
    <script>
    function MailDataSubmit() { //alert();
    var Mailtype = $("#Mailtype").val(); //alert(cmpname);
    var SMTP = $("#SMTP").val();
    var SMTPUser = $("#SMTPUser").val();
    var Etc = $("#Etc").val();
    var ESign = $("#ESign").val(); 
    $.post("datafuntion.php", { Mailtype: Mailtype, SMTP: SMTP, SMTPUser: SMTPUser, Etc: Etc, ESign: ESign }, 
    function(data) { 
	 $('#Msults').html(data);
	  alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>
</div> 
</div>
 
</div>
</div>  
</div>
</div>  

<div class="clearfix"></div>
 
 
  <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 
  

  </body>
</html>