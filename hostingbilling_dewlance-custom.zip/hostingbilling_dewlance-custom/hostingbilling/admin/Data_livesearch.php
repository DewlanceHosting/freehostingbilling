<?php include_once('../fn/connect.php');   ?>


<!------------------------------------- Pharmacy Details  ----------Pharmacy Details  -------------------------------->
 <?php
  
 
 
// Escape user inputs for security
$term = mysqli_real_escape_string($con, $_REQUEST['q']);
 
if(isset($term)){
    // Attempt select query execution
    $sql = "SELECT * FROM user_ragistration WHERE fname LIKE '" . $term ."%'";
    if($result = mysqli_query($con, $sql)){
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                echo "<option value='".$row['fname']."'>".$row['fname']." ".$row['lname']."</option>";
				 
            }
            // Close result set
            mysqli_free_result($result);
        } else{
            echo " No matches found ";
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
    }
}
  
   /* $key=$_GET['key'];
    $array = array();
     
    $query=mysqli_query("select * from phm_item_information_add where item_name LIKE '%{$key}%'");
    while($row=mysqli_fetch_assoc($con,$query))
    {
      $array[] = $row['item_name'];
    }
    echo json_encode($array);
 
// close connection*/
mysqli_close($con);
?>
 