<?php         include_once('../fn/connect.php'); 
    $data = $_POST['updatename'];

$qurr=mysqli_query($con,"SELECT * FROM `productadd` where producid='$data'"); $rowdata=mysqli_fetch_array($qurr);

?>
<input type="hidden" id="idData" value="<?php echo $data; ?>" />
<div class="row">
  <div class="col-md-6">
  <div class="prodform">
<div class="form-horizontal">
  <?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Module">Module:</label>
    <div class="col-sm-9">
          <select class="form-control" id="UModule"><option value="<?php echo $rowdata['modulid']; ?>"><?php echo $rowdata['modulid']; ?></option>
          <?
    $user = "root";
    $token = $rowc['apikdy'];
    $query = "https://$stval/json-api/listpkgs?api.version=1"; 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query); 
      $result = curl_exec($curl); 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            echo "<option value=". $userdetails->{'name'} .">" . $userdetails->{'name'} ." Supercheap ". "</option>";
        }
    } 
    curl_close($curl); ?>   
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Group:</label>
    <div class="col-sm-9">  <?php  $nameid= $rowdata['groupid']; ?>
     <?php $quername = mysqli_query($con,"SELECT * FROM `productgroupadd` where pgroupid='$nameid'"); $Prodidn = mysqli_fetch_array($quername); ?>
      <select class="form-control" id="UpnameGroup"><option value="<?php echo $Prodidn['pgroupid']; ?>"><?php echo $Prodidn['producname']; ?></option>
      <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productgroupadd`"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?>
      <option value="<?php echo $ProducName['pgroupid']; ?>"><?php echo $ProducName['producname']; ?></option>
      <?php }?>
      </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Group">Product Description:</label>
    <div class="col-sm-9"> 
      <textarea class="form-control" rows="4"  placeholder="Enter Description" id="Udescrip"><?php echo $rowdata['decrip']; ?></textarea>
    </div>
  </div>
  
  
  <!--<div class="form-group">
    <label class="control-label col-sm-3" for="Email">Product Email:</label>
    <div class="col-sm-9">
      <input type="email" class="form-control" id="UEmail" placeholder="Enter Email" value="<?php// echo $rowdata['pemail']; ?>">
    </div>
  </div>-->
  
  
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <div class="checkbox">
        <label><input type="checkbox" class="checkbox1"> Allow domain registration with with this product</label>
      </div>
    </div>
  </div>
  <div class="upresultfunc">
  <?php // $queprodu=mysqli_query($con,"SELECT * FROM `productadd` where  producid='$usrp'");  $rowqueprodu=mysqli_fetch_array($queprodu); 
    $pricetype=$rowdata['pricetype']; ?>
    <?php if($pricetype  == 'Free'){  ?> 
	
	
	<div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType"  onChange="BillingCycle();">
       <option >Free</option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select>
     
  </div> 
  </div>
   
	<?php }elseif($pricetype == 'One Time'){ // echo"One Time"; ?>
	
<div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType"  onChange="BillingCycle();">
       <option >One Time</option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select>
   </div> 
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="UPrice" placeholder="Enter Price" value="<?php echo $rowdata['price']; ?>">
    </div>
  </div> 
  
   
	<?php }elseif($pricetype == 'Requiring'){ //echo"Requiring"; ?>
	
	
	<div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType" onChange="BillingCycle();">
       <option >Requiring </option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="UPrice" placeholder="Enter Price" value="<?php echo $rowdata['price']; ?>">
    </div>
  </div> 
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price : Billing Cycle</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="UBillingType"><option value="<?php echo $rowdata['billtype']; ?>"><?php echo $rowdata['billtype']; ?></option>
     <option>Monthly</option>
     <option>Quarterly</option>
     <option>Annualy</option>
     </select>
    </div>
  </div> 
   
	<?php }?>
    </div>
    <input type="hidden" value="<?php echo $data; ?>" id="Proidmodfy" />
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-danger" id="Update">Update</button>
    </div>
  </div>
 
</div>
</div> 
</div>
</div>
 <script>
function BillingCycle() {
  var Proidmodfy = $("#Proidmodfy").val();  //alert(Proidmodfy);
    var PriceType = $("#PriceType").val();  //alert(Statusdata);
      $.post("actionwork.php", { Proidmodfy: Proidmodfy, PriceType: PriceType},
    function(data) {
	 $('#upresultfunc').html(data);
	   alert(data);
	// location.reload();
	 $('#myForm')[0].reset();
    });
}
</script>  
<script>//////////////////////////////////////////////UPDATE/////////////////////////////////////////////////////////////////////
$(document).ready(function(){
$("#Update").click(function(){
							//alert();
 var idData = $("#idData").val(); //alert(idData);
var UModule = $("#UModule").val();
var UpnameGroup = $("#UpnameGroup").val();
var Udescrip = $("#Udescrip").val();
var UEmail = $("#UEmail").val();
var  domain = $("input[type=checkbox]:checked").val();
var PriceType = $("#PriceType").val();
var UPrice = $("#UPrice").val();
var UBillingType = $("#UBillingType").val();
// Returns successful data submission message when the entered information is stored in database.
var dataString =  '&idData='+ idData + '&UModule='+ UModule + '&UpnameGroup='+ UpnameGroup + '&Udescrip='+ Udescrip + '&UEmail='+ UEmail + '&domain='+ domain + '&PriceType='+ PriceType + '&UPrice='+ UPrice + '&UBillingType='+ UBillingType;
//alert(dataString);
if(idData==''||UModule==''||UpnameGroup==''||Udescrip==''||UEmail==''|| domain==''||PriceType==''||UPrice==''|| UBillingType=='')
{
alert("Please Fill All Fields");
}
else
{
	//alert(dataString);
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "Datafunction.php",
data: dataString,
cache: false,
success: function(result){
alert(result);
location.reload();
}
});
}
return false;
});
});</script>