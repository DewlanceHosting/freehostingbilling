<? session_start();
include_once('../fn/connect.php');  //Product: Product, Domain: Domain, cpuser: cpuser, Billing: Billing ?>
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc);   $stval=$rowc['ipnumber']; 

     $username = $_POST['cpuser'];
    $domain = $_POST['Domain'];
    $pack  = $_POST['Product'];
    $password = $_POST['password'];
//$ip = $_POST['ip'];
  $contactemail = $_POST['peremailid'];
//$username = $_POST[''];  

    $user = "root";
     $token = $rowc['apikdy'];
 
     $query =      	"https://$stval/json-api/createacct?api.version=1&username=$username&domain=$domain&plan=$pack&featurelist=default&quota=0&password=12345luggage&ip=n&cgi=1&hasshell=1&contactemail=$contactemail&cpmod=paper_lantern&maxftp=5&maxsql=5&maxpop=10&maxlst=5&maxsub=1&maxpark=1&maxaddon=1&bwlimit=500&language=en&useregns=1&hasuseregns=1&reseller=0&forcedns=1&mailbox_format=mdbox&mxcheck=local&max_email_per_hour=500&max_defer_fail_percentage=80&owner=root";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
       $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
		$upd=$_SESSION['sts'];
       $dataup=mysqli_query($con,"UPDATE `user_ragistration` SET `viewcpanelstatus`='1' WHERE `user_ragistration`.`id` ='$upd'"); 
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "you accour created" . $userdetails->{'output'}->$userdetails->{'raw'}. "\n";
			
        }
    }
 
    curl_close($curl); 
 //$Tomail =$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
    $fromid=$rowg['useremail'];
//massagedata: massagedata 

//$to = $contactemail; //can't receive notification!

//$subject = 'Massage By Admin';
///$message = 
//$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
//$headers = 'From: '.$fromid.'"\r\n"'.$fromid.'"\r\n"'.'Request By Admin ' . phpversion();
 
//mail($to, $subject, $message, $headers);

////////////////////////////////////////////////////////////



$to = $contactemail;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="image/logo.png" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>User Name: &nbsp;'. $username.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Password: &nbsp;'. $password.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $contactemail.'</strong></p>
  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);
?>



