  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
         <style> 
#example tr:nth-child(2n) {
  background-color: #F3F3F3;
}

 
#example tr {
  background-color: white;
}
 
</style>   
  </head>
  <body>
  
   <?php include_once('header.php'); ?>
  
  <!--headerpart-end-searchclientData.php---->
 <section class="searchsec">
 <div class="container">
 <div class="row">
 
 <div class="col-md-offset-3 col-md-6 col-md-offset-3">
 <div class="sarchh">
 <h3>Search Client</h3>
 
 <div class="input-group">
      <input type="text" class="form-control" id="clientEmailId" placeholder="eg. example.com">
      <span class="input-group-addon"><button type="button" onClick="SearchData();" >Search</button></span>
    </div>
 
 
 
 </div>
 
 </div>
 <script>function SearchData() {
    var name = $("#clientEmailId").val(); 
    $.post("searchclientData.php", { name: name },
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
    });
}</script>
 
 
 
 
 </div>
 </div>
 </section> 

<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Client List</h3>
<div id="results">
<div class="table-responsive"> 
<table id="example" class="table table-hover" cellspacing="0" width="100%">
				 <thead>
    <tr>
      
      <th>Client Id</th>
      <th>Client Name</th> 
      <th>Country</th>
      <th>Date Created</th>
       <th>Status</th>
        <th>Active Services</th>
        <!--<th>Action</th>-->
    </tr>
  </thead>
  <tbody>
  <?php $que=mysqli_query($con,"SELECT * FROM `user_ragistration`"); while($rowdata=mysqli_fetch_array($que)){ $dataView=$rowdata['id']; $fsf=$rowdata['contryid'];?>
			<tr>
       <td><h4><a href="clientprofile.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['id']; ?></a></h4></td>
      <td><h4><a href="clientprofile.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['fname']; ?></a></h4></td> 
       <?php $quecontyr=mysqli_query($con,"SELECT * FROM `country` where id ='$fsf'"); $rowcdata=mysqli_fetch_array($quecontyr); ?>
      <td><?php echo $rowcdata['country']; ?></td>
      <td><h4><?php echo $rowdata['ragdate']; ?> </h4> </td>
       <?php if($rowdata['status'] == '1'){?>

  <td>Active</td>

<?php } else{?>

  <td>In-Active</td>

 <?php } ?>
  <?php $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where  status='0' && user_rid ='$dataView'");  $rowcount=mysqli_num_rows($queser); //$rowser=mysqli_fetch_array($queser); ?>
       <td><?php echo $rowcount; ?></td>
      <!-- <td><a  href="deletedata.php?cl=<?php// echo $rowdata['id'];  ?>"><button class="btn btn-danger">Delete</button></a></td> -->
    </tr>
     <?php  
	
}
?> 

  </tbody>
			</table>
</div>
</div>
</div>





</div>

</section>

 <?
/*if(isset($_GET['1'])){}
  $uds= base64_decode($_GET['1']);
    $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
    $query = "https://167.160.174.209:2087/json-api/listaccts?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
        $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
// echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		  //print_r($json);
         // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
		//if($userdetails->{'uid'} == $uds){
		 //echo  "\t" . $userdetails->{'user'} . "\n";
		 
          //  } 
		   }
    }
 
    curl_close($curl);*/
?>
 

 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

 

  

  </body>
</html>