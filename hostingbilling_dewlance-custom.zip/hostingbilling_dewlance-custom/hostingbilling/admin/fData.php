<?php  include_once('../fn/connect.php'); ?> 

<?php  if(isset($_POST['email'])){
$email = $_POST['email'];
$optradio = $_POST['optradio'];
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Signature = $_POST['Signature'];
$idEnable = $_POST['idEnable'];
//$newdata = $_POST[''];
 
//email: email, optradio: optradio, Username: Username, Password: Password, Signature: Signature, idEnable: idEnable
$rundata = mysqli_query($con,"UPDATE `paygetwaydata` SET `paymentaccount` = '$email', `paymentOption` = '$optradio', `apiusername` = '$Username', `apipass` = '$Password', `apising` = '$Signature', `ticketenmode` = '$optradio' WHERE id=4");
//$rundata = mysqli_query($con,"INSERT INTO `paygetwaydata` (`paymentaccount`, `paymentOption`, `apiusername`, `apipass`, `apising`, `ticketenmode`, `status`)
												 //VALUES ('$email', '$optradio', '$Username', '$Password', '$Signature', '$idEnable', '0')");
		if($rundata){
		echo "<h2 style='color:#FF0000;'>Data Update sucessfully</h2>";
		}else{ echo "No Data Add";}

} ?>  