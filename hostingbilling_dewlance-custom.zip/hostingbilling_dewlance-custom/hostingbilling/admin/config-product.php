  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script src="function.js"></script>
    <script>
$(document).ready(function() {
$(".ndx").click(function(){
  // alert(); 
var element = $(this);
var updatename = element.attr("pid");
  
 var data = 'r=getmyvitaldetails1' + '&updatename=' + escape(updatename);

 // alert(data); 
 $.ajax({
   type: "POST",
    url:'editpackage.php',
   data: data,
   success: function(data){   
  // alert(data); 
$("#pricelisupdate").html(data);
 }
 
}); 
return false; 
});
});

function SubmitFormData() {
 
 $("#imgLoading").show();
   $("#imgLoading").hide(1500);
					 
//alert();
    var inputModule = $("#inputModule").val(); //alert(inputModule); 
    //var gender = $("input[type=radio]:checked").val();
    $.post("productsData.php", { inputModule: inputModule},
    function(data) {
	 $('#results').html(data);
	 $('#myForm')[0].reset();
	 //alert(data); 
    });
}
</script> 
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!--headerpart-end-->

<div class="clientprofile">
<div class="container">
<div class="listservisdata">
<h3><strong>Product Services</strong></h3>
<div class="proftabb">
<ul class="navadminn">
  <li class="active"> <a data-toggle="tab" href="#Modify">Create Group</a></li>
  <li> <a data-toggle="tab" href="#Invoice">Create product</a></li>
</ul>

<div class="tab-content">
  <div id="Modify" class="tab-pane fade in active">
  <h3>List of group list</h3>
  <div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Group Name</th>
      <th>product Assigned</th>
    </tr>
  </thead>
  <tbody>
  <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productgroupadd`"); while($ProducName = mysqli_fetch_array($queryProduc)){ $matchdata=$ProducName['pgroupid'];?>
    <tr>
      <td><?php   $update=base64_decode($_GET['1']); 
	  if($update == $matchdata){ 
	  ?>
     <form action="Datafunction.php?D=<?php  echo base64_encode($ProducName['pgroupid']);  ?>" method="post">
       <input type="text" class="form-control" name="textval" value="<?php echo $ProducName['producname']; ?>">
      <?php } else{?>
     
      <h4><?php echo $ProducName['producname']; ?></h4>
      <?php }?>
      </td>
        <?php if($ProducName['status'] == '1'){?> 
<td> 
       <a href="deletegroup.php?Assign=<?php  echo $ProducName['pgroupid'];?>&Val=0"><button class="btn btn-info">Not Assign</button></a> 

<?php } else{?>

 <td>
       <a href="deletegroup.php?Assign=<?php  echo $ProducName['pgroupid'];?>&Val=1"><button class="btn btn-info">Assigned</button></a> 

 <?php } ?> 
 <?php if($update == $matchdata){ 	  ?>
       <button type="submit" class="btn btn-warning">Update</button> </form>
      <?php } else{?> 
     <a href="config-product.php?1=<?php  echo base64_encode($ProducName['pgroupid']);  ?>"><button class="btn btn-danger">Edit</button></a>
      <?php }?>
        
      <a href="deletegroup.php?Groupid=<?php  echo $ProducName['pgroupid'];  ?>"><button class="btn btn-danger">Delele</button></a>
       </td>
       
    </tr>
    <?php }?>
    <!--<tr>
      <td>
      <h4>XXXXXXX XXXXXXX</h4>
      </td>
       <td>
       <button class="btn btn-info">Assign</button>
       <button class="btn btn-danger">Delele</button>
       </td>
       
    </tr>-->
  </tbody>
</table>
</div>
  </div>
  
  
  <div id="Invoice" class="tab-pane fade">
  <h3>Create Product</h3>
  <div class="row">
  <div class="col-md-6">
  <div class="prodform">
<div class="form-horizontal">
 
   <div class="form-group">
    <label class="control-label col-sm-3" for="Email">Module Name:</label>
    <div class="col-sm-7">
      <select name="servertype" id="inputModule" class="form-control select-inline" onChange="SubmitFormData();">
      <option class="active" value="">None</option>
      <option value="cpanel">cPanel</option>
      <option value="plesk">ABC</option></select>
    </div>
     <div class="col-sm-2">
      <div id='imgLoading' style='display:none; height:35px;'><img src="loading.gif"  width="10" alt="Uploading...."/></div>
     </div>
  </div>
 
  <div id="results">
  </div>
  
  </div> 
  
  <!--<div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-danger" id="submit">Submit</button>
    </div>
  </div>-->
</div> 
</div>  
</div>
</div>   
    
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>General</th>
      <th>Module</th>
      <th>Automation</th>
       <th>Upgrade</th>
        <th>Order Link</th>
    </tr>
  </thead>
  <tbody>
  <?php $queryProduc = mysqli_query($con,"SELECT * FROM `productadd`"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?> 
    <tr> 
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td><h4><?php echo $ProducName['modulid']; ?></h4></td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>    
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>
      <?php } ?>

   <!-- <tr>
      
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td>{module}</td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>
        <tr>
      
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td>{module}</td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>
        <tr>
      
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td>{module}</td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>
    <tr>
      
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td>{module}</td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>
        <tr>
      
      <td><h4><a href="#">XXXXXXX</a></h4></td>
       <td>{module}</td>
       <td>Plan Name</td>
        <td> <select id="done" class="selectpicker" multiple data-done-button="true">
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
    <option>Wordpress Managed Hosting (UK)- WP Bronze UK</option>
  </select>
 </td>
       <td>
      <h4><a href="#">XXXXXXX</a></h4>
      </td>
    </tr>-->
    
  </tbody>
</table>
</div> 
  </div>  
</div> 
</div> 
</div>
</div>
</div> 

<div class="clearfix"></div> 
 
 <!--home--contant----end--->  
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>