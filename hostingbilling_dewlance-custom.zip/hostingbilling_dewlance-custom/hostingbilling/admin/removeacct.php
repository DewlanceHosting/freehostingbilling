<? session_start();
include_once('../fn/connect.php');  //Product: Product, Domain: Domain, cpuser: cpuser, Billing: Billing ?>
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; 

////<!-----------------------1--------Creat User in cPenal process-------------------------------------->

 if(isset ($_POST['unsusname'])){ 
 $unsusname = $_POST['unsusname'];
   $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/unsuspendacct?api.version=1&user=$unsusname";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
		$upd=$_SESSION['sts'];
       $dataup=mysqli_query($con,"UPDATE `user_ragistration` SET `viewcpanelstatus`='1' WHERE `user_ragistration`.`id` ='$upd'");
        echo "User Unsuspend";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
}
///<!----------------------2--------suspendacct User in cPenal process-------------------------------------->
 if(isset ($_POST['susname'])){ 
 echo $susname = $_POST['susname'];
   $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/suspendacct?api.version=1&user=$susname&reason=Nonpayment";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
   echo  $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
		$upd=$_SESSION['sts'];
		 echo $grn="UPDATE `user_ragistration` SET `viewcpanelstatus`='2' WHERE `user_ragistration`.`id` ='$upd'";
       $dataup=mysqli_query($con,$grn);
        echo "User Suspend";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
}

///<!----------------------3--------removeacct User in cPenal process-------------------------------------->
 if(isset ($_POST['name'])){ 
 $username = $_POST['name'];
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/removeacct?user=$username";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		$upd=$_SESSION['sts'];
       $dataup=mysqli_query($con,"UPDATE `user_ragistration` SET `viewcpanelstatus`='3' WHERE `user_ragistration`.`id` ='$upd'");
		//print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
	
}
///<!-----------------------4--------passwd User in cPenal process-------------------------------------->

 if(isset ($_POST['passunsusname'])){ 
 $passunsusname = $_POST['passunsusname'];
  $password = $_POST['password'];
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/passwd?api.version=1&user=$passunsusname&password=$password&enabledigest=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
      $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
	
}
 
///<!-----------------------5--------changepackage User in cPenal process-------------------------------------->

if(isset ($_POST['PackageName'])){ 
  $Packuser = $_POST['Packuser'];
   $PackageName = $_POST['PackageName'];
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/changepackage?api.version=1&user=$Packuser&pkg=$PackageName";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    echo $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
	
}
?>