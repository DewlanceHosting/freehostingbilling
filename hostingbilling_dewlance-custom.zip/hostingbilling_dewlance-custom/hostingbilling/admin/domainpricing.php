  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
   <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script>function SubmitFormData() {
    var name = $("#dname").val(); //alert(name);
    var email = $("#priceses").val(); //alert(email);
    var phone = $("#enmail").val(); //alert(phone);

   // var gender = $("input[type=radio]:checked").val();
	var checkValues = $('input[name=checkboxlist]:checked').map(function()
            {
                return $(this).val();
            }).get();
//alert(checkValues);
    $.post("domainpriceData.php", { name: name, email: email, phone: phone, checkValues: checkValues },
    function(data) {
	 $('#resulprice').html(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}</script> 
<script>function UpdateData() {
    var Updatename = $("#Updatename").val();  //alert(Updatename);
    var Updateprice = $("#Updateprice").val(); // alert(Updateprice);
    var updatephone = $("#updatephone").val();  //alert(updatephone);
	var upid = $("#upid").val();  //alert(updatephone);
   // var gender = $("input[type=radio]:checked").val();
	var checkValues = $('input[name=checkboxlist]:checked').map(function()
            {
                return $(this).val();
            }).get();
// alert(checkValues);
    $.post("domainpriceData.php", { Updatename: Updatename, Updateprice: Updateprice, updatephone: updatephone, checkValues: checkValues, upid: upid },
    function(data) {
	 $('#resulprice').html(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}</script> 
<script>
$(document).ready(function() {
$(".btn-info").click(function(){
  //alert(); 
var element = $(this);
var updatename = element.attr("pid");
 // alert(updatename);
//var example1 = $("#example1").val(); 
 //alert(example1);
 var data = 'r=getmyvitaldetails1' + '&updatename=' + escape(updatename);

// alert(data); 
 $.ajax({
   type: "POST",
    url:'domainpricUpdate.php',
   data: data,
   success: function(data){   
  // alert(data); 
$("#pricelisupdate").html(data);
 }
 
}); 
return false; 
});
});
</script>
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!-------------headerpart-end--domainpriceData.php----------->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Domain Pricing</h3>
<div class="table-responsive">
<div id="pricelisupdate">
<table class="table table-hover">
  <thead>
    <tr>
      <th>TLD</th>
      <th>Pricing</th>
      <th>DNS Management</th>
       <th>Email Forwarding</th>
        <th>Id Protection</th>
         <th>EPP Code</th>
          <!--<th>Auto Registration</th>-->
          <th>Action</th>
    </tr>
  </thead>
  <tbody> 
  
  <?php $queryPrice = mysqli_query($con,"SELECT * FROM `priceadd`"); while($rowprice = mysqli_fetch_array($queryPrice)){ ?>
    <tr  id="resulprice">
      <td>
      <input class="form-control" type="text" value="<?php echo $rowprice['domainname']; ?>" style="width:100px;" disabled>
      </td>
      <td>
      <input class="form-control" value="<?php echo $rowprice['domainprice']; ?> &dollar;" style="width:100px;" disabled> 
       </td>
       <td>
       <p><?php echo $rowprice['dsnmanagement']; ?></p>
       </td>
       <td>
       <p><?php echo $rowprice['emailforwarding']; ?></p>
       </td>
       <td>
       <p><?php echo $rowprice['idprotection']; ?></p>
       </td>
       <td>
       <p><?php echo $rowprice['eppcode']; ?></p>
       </td>
      <!-- <td>
       <p><?php// echo $rowprice['autoregistration']; ?></p>
        </td>--> 
       <td><button class="btn-info"pid="<?php echo $rowprice['priceid'];  ?>">Edit</button></td>
    </tr> 
    <?php }?>
    
    <!--<tr>
      <td>
      <input class="form-control" type="text" value="<?php echo $rowprice['domainname']; ?>">
      </td>
      <td>
      <input class="form-control" value="<?php echo $rowprice['domainprice']; ?>"> 
       </td>
       <td>
       <input type="checkbox" name="" id="" value="<?php echo $rowprice['dsnmanagement']; ?>">
       </td>
       <td>
       <input type="checkbox" name="" id="" value="<?php echo $rowprice['emailforwarding']; ?>">
       </td>
       <td>
       <input type="checkbox" name="" id="" value="<?php echo $rowprice['idprotection']; ?>">
       </td>
       <td>
       <input type="checkbox" name="" id="" value="<?php echo $rowprice['eppcode']; ?>">
       </td>
       <td>
       <input type="text" name="" id="" value="<?php echo $rowprice['autoregistration']; ?>">
        </td> 
       
    </tr>-->
     <tr>
      <td>
      <input class="form-control" type="text" id="dname" placeholder=".ABC" style="width:100px;">
      </td>
      <td>
      <input class="form-control" id="priceses" placeholder="10 &dollar;" style="width:100px;" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
       
       </td>
       <td>
       <input type="checkbox" name="checkboxlist"  value="Y"id="">
       </td>
       <td>
       <input type="checkbox" name="checkboxlist"  value="Y"id="" >
       </td>
       <td>
       <input type="checkbox" name="checkboxlist" value="Y" id="">
       </td>
       <td>
       <input type="checkbox" name="checkboxlist" value="Y" id="">
       </td>
      <!-- <td>
       <select id="enmail" class="form-control">
       <option>None</option>
        <option>Email</option>
        </select>
        </td>-->
       <td> <button class="btn btn-danger" type="button" onClick="SubmitFormData();">Save</button> </td>
       
       
    </tr> 
     
  </tbody>
</table>
</div>
</div> 
 
</div> 
</div>

</section> 

 <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>