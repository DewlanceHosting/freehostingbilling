<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
   <?php include_once('header.php'); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<div class="row">
<div class="col-md-8">
<h3>Domain Registrar</h3>
</div>
<div class="col-md-4">
  
</div>
</div>



<div id="Rdata">

<div class="moduule_listsec">
<ul class="moduule_list">
<li>
<div class="row">
<div class="col-sm-1">
<div class="listlogo"><img style="width:60px;" src="images/mailicon.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>Email Notification</h5>
<p>&nbsp;&nbsp;Enter Your "emailaddress" then it function working ....</p>
</div>
<div class="col-sm-5">
<span id="action">
<button class="btn btn-default" disabled>Activate</button>
<button class="btn btn-danger" disabled>Deactivate</button> 
<button class="btn btn-primary" id="confbtn2">Configure</button> </span>
 <!--<button class="btn btn-default" disabled>Activate</button>
<button class="btn btn-danger">Deactivate</button> 
<button class="btn btn-primary" id="confbtn2">Configure</button>-->
</div>
</div>
</li>

</ul> 


<form class="form-horizontal">
<div class="input-group">
  <span class="input-group-addon" id="basic-addon1">Email Address</span>
  <input type="text" class="form-control" placeholder="youremail@example.com" id="fdata" aria-describedby="basic-addon1" onChange="emailData();">
</div>
</form>



</div> 

</div>

</div> 
</div>
 
</section>
<script>function emailData() {
    var name = $("#fdata").val(); 
    $.post("domainDataManage.php", { name: name },
    function(data) {
	 $('#Rdata').html(data);
	 $('#fdata')[0].reset();
    });
}</script>
<script>function ActiveData() {
    var acsId = $("#acsId").val(); 
    $.post("domainDataManage.php", { acsId: acsId },
    function(data) {
	 $('#action').html(data);
	 $('#fdata')[0].reset();
    });
}</script>
<script>function DeActiveData() {
    var dacsId = $("#dacsId").val(); 
    $.post("domainDataManage.php", { dacsId: dacsId },
    function(data) {
	 $('#action').html(data);
	 $('#fdata')[0].reset();
    });
}</script>

 <style>
.modullistt {
    width: 100%;
    background: #f8f8f8;
    margin: 0px;
    padding: 15px;
    display: none;
}

.modullistt p {
    margin: 0;
}


</style>
<!--------configure------section---Start----->
<div class="modullistt" id="confadd2">
<div class="row">
<div class="col-sm-offset-2 col-sm-8 col-sm-offset-2">
<form class="form-horizontal">
  <div class="form-group">
    <label class="control-label col-sm-3" for="Username">Your Email Address:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="Username" placeholder="Enter Username">
    </div>
  </div>
  
  <!--<div class="form-group">
    <label class="control-label col-sm-3" for="SMS">Wanted SMS Field :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="SMS" placeholder="Enter SMS">
    </div>
  </div>--> 
      
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-default">Submit</button>
    </div>
  </div>
</form>
</div>
</div>
</div>
<!--------configure------section---End----->
<script>
$(document).ready(function(){
    $("#confbtn1").click(function(){
        $("#confadd1").slideToggle();
    });
	    $("#confbtn2").click(function(){
        $("#confadd2").slideToggle();
    });
});
</script>
 
 <!--home--contant----end--->
  

 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>