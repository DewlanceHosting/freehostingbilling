<?php
   include_once('../fn/connect.php'); 
   
   /////////////////////////////////////////////////////////////////////////

if (isset($_GET['cl']) && is_numeric($_GET['cl']))
 {
 // get id value
 $id = $_GET['cl'];
 } 
  

$rec2 = "DELETE FROM `user_ragistration` WHERE   id='$id'";

if(mysqli_query($con,$rec2)){
	 
	header('Refresh:1; url=viewclient.php');
}
else{
	die("Data failed to delete in the database");
}

?>