  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
  <?php include_once('header.php'); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<div class="row">
<div class="col-md-8">
<h3>Module List</h3>
</div>
<div class="col-md-4">
  
</div>
</div>

<div class="moduule_listsec">
<ul class="moduule_list">
<li>
<!--<div class="row">
<div class="col-sm-2">
<div class="listlogo"><img src="images/cpnellogo.png" alt="llogo"></div>
</div>
<div class="col-sm-7">
<h5>Cpanel <small>(version: 1)</small></h5>
<h5>Author : <span>Cpanel module</span></h5>
</div>
<div class="col-sm-3">
<button   class="btn btn-danger">Action</button>
</div>
</div>-->
</li>
<?
   /* $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
    $query = "https://167.160.174.209:2087/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
         $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {*/
            
?>  
<!--<li>
<div class="row">
<div class="col-sm-2">
<div class="listlogo"><img src="images/logo.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>#module Name <small>(version: 1)</small></h5>
<h5>Author : <span><?php // echo  $userdetails->{'name'} ;?></span></h5>
</div>
<div class="col-sm-4">
<div class="pull-right">
<button onClick="ShowHidebtn(this);" class="btn btn-danger">Activate</button>
<button class="btn btn-danger">Configure</button>
</div>
</div>
</div>

</li>-->
<?php //}  }curl_close($curl); 
?> 
<script>function DpenalControl() { var dname = $("#dname").val();  
$.post("moduleControl.php", { dname: dname}, function(data) { $('#Controlc').html(data); location.reload(); }); }</script>

<script>function CpenalControl() { var name = $("#dname").val();  
$.post("moduleControl.php", { name: name}, function(data) { $('#Controlc').html(data); location.reload(); }); }</script>
<!--<!----moduleControl.php---alert(name);--> 
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control`"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['status']; ?>
<input type="hidden" id="dname" value="<?php echo $rowc['id']; ?>">
<li>
<div class="row">
<div class="col-sm-2">
<div class="listlogo"><img src="images/cpnellogo.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>#module Name <small>(version: 1)</small></h5>
<h4><strong>Control IP For All API Module : </strong><span> 1</span></h4>
</div>
<div class="col-sm-4">
<div class="pull-right"><span id="Controlc"> 
<?php if($stval ==0){ ?>
<center><button onClick="DpenalControl();" class="btn btn-danger">Activate</button></center></span>
<?php }else{?>
<center><button onClick="CpenalControl();" class="btn btn-danger">Deactivate</button>
<button class="btn btn-danger" id="confbtn1">Configure</button></center></span>
<?php } ?> 

</div>
</div>
</div>

<!--------configure------section---Start- 167.160.174.209 ---->
<div class="modullistt" id="confadd1">
<div class="row">
<div class="col-sm-offset-2 col-sm-8 col-sm-offset-2">
<script>function Updateip() { var ipname = $("#ipname").val();  var idd = $("#idd").val();  var apikey = $("#apikey").val(); confirm("Do you want to chage IP address!");  
$.post("moduleControl.php", { ipname: ipname, idd: idd , apikey: apikey}, function(data)  { $('#newip').html(data); location.reload();  }); }</script>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Username">Change API IP address:</label>
    <div class="col-sm-9">
    <input type="hidden" id="idd" value="<?php echo $rowc['id']; ?>">
      <input type="text" class="form-control" id="ipname" placeholder="Enter New Ip..." value="<?php echo $rowc['ipnumber']; ?>">
    </div> 
  </div> 
<p></p>
  <div class="form-group">
    <label class="control-label col-sm-3" for="SMS">Change API KEY :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="apikey" value="<?php echo $rowc['apikdy']; ?>">
    </div>
  </div>
   
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-default" onClick="Updateip();">Submit Chage</button>
      <samp id="newip"></samp>
    </div>
  </div>
 
</div>
</div>
</div>

<!--------configure------section---End----->
</li>
<?php $querc=mysqli_query($con,"SELECT * FROM `modulecontrol`"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['status']; ?>
<input type="hidden" id="username" value="<?php echo $rowc['id']; ?>">
<input type="hidden" id="dusername" value="<?php echo $rowc['id']; ?>">
<script>function UserControl() { var username = $("#username").val();  
$.post("moduleControl.php", { username: username}, function(data) { $('#userData').html(data); location.reload(); }); }</script>
<script>function SUserControl() { var dusername = $("#dusername").val();  
$.post("moduleControl.php", { dusername: dusername}, function(data) { $('#userData').html(data); location.reload(); }); }</script>
<!--<li>
<div class="row">
<div class="col-sm-2">
<div class="listlogo"><img src="images/logo.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>#module Name <small>(version: XX)</small></h5>
<h4><strong>Manage Client Controlation For Access  : </strong><span> 1</span></h4>
</div>
<div class="col-sm-4">
<div class="pull-right"><samp id="userData">
<?php //if($stval ==0){ ?>
<center><button onClick="UserControl();" class="btn btn-danger">Activate</button></center></span>
<?php //}else{?>
<center><button onClick="SUserControl();" class="btn btn-danger">Deactivate</button>
<button class="btn btn-danger" id="confbtn2">Configure</button></center></span>
<?php //} ?> 
 
</div>
</div>
</div>-->
<script>function UserDataSubmited() { 
var APIUsername = $("#APIUsername").val(); 
var WSMS = $("#WSMS").val(); 
var SMS = $("#SMS").val(); 
var Accesss  = $("input[type=checkbox]:checked").val(); 
 
$.post("moduleControl.php", { APIUsername: APIUsername, WSMS: WSMS, SMS: SMS, Accesss: Accesss }, 
function(data) { $('#result').html(data);  }); }</script>
<!--<li>
------configure------section---Start----->
<div class="modullistt" id="confadd2">
<div class="row">
<div class="col-sm-offset-2 col-sm-8 col-sm-offset-2">
<form class="form-horizontal">
  <div class="form-group">
    <label class="control-label col-sm-3" for="Username">API Username:</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="APIUsername" placeholder="Enter Username">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-3" for="SMS">Wanted SMS Field :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="WSMS" placeholder="Enter SMS">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="SMS">GSM Number Field :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="SMS" placeholder="Enter SMS">
    </div>
  </div>
  
    <div class="form-group">
    <label class="control-label col-sm-3" for="SMS">Access Control :</label>
    <div class="col-sm-9"> 
      <p>Choose the admin role groups to permit access to this module :</p>
      
      <label class="checkbox-inline">
      <input type="checkbox" value="1"> Full Administrator
      </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="2"> Sales Operator
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="3"> Support Operator
    </label>
      
      
      
      
    </div>
  </div>
  
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="button" class="btn btn-default" onClick="UserDataSubmited();">Submit</button>
    </div>
  </div>
</form>
<samp id="result"></samp>
</div>
</div>
</div>
<!--------configure------section---End----->

</li> 



<script>
$(document).ready(function(){
    $("#confbtn1").click(function(){
        $("#confadd1").slideToggle();
    });
	    $("#confbtn2").click(function(){
        $("#confadd2").slideToggle();
    });
});
</script>

<style>
.modullistt {
    width: 100%;
    background: #f8f8f8;
    margin: 0px;
    padding: 15px;
    display: none;
}

.modullistt p {
    margin: 0;
}


</style>

   
 
</ul>

</div> 

</div> 
</div>

</section> 
 
 <!--home--contant----end---> 
 
 
 
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>