<?php  session_start();  include_once('../fn/connect.php'); 

 if(isset($_POST['Old'])){
 echo $uName = $_SESSION['adminid'];
 $passworkd = $_POST['Old'];
$pWord = md5($_POST['Old']);
//`username`, `userpass`, `useremail`, `mobile`, `status`
 $qry = "SELECT * FROM admin WHERE id='".$uName."' AND userpass='".$pWord."' AND status='0'";
$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);
if( $num_row == 1 ) { ?>
 <label for="Password">Old Password :</label>
	 <input type="password" class="form-control" id="Old" value="<?php echo $passworkd; ?>" onChange="OldPassData();">
 <span style="color:#9F9800;">Password Match</span>
 <div class="form-group">
    <label for="Password">New Password :</label>
    <input class="form-control" name="password" id="password" type="password">
  </div>

<div class="form-group">
    <label for="Password">Confirm Password :</label>
    <input class="form-control" type="password" name="confirm_password" id="confirm_password">
  </div>
	<?php }
else { ?>
<label for="Password">Old Password :</label>
	<input type="password" class="form-control" id="Old"  onChange="OldPassData();">
<span style="color:#F03228;">Pass Not Match</span>
<?php } }?>



<?php    
   if(isset($_POST['name'])){
 $iddata = $_SESSION['adminid'];
  $pWord = md5($_POST['name']);
  $res = mysqli_query($con,"UPDATE `admin` SET `userpass` ='$pWord' WHERE id='$iddata'"); 
//$num_row = mysqli_num_rows($res);
//$row=mysqli_fetch_assoc($res);
if($res) {

echo "Update Password Data Succesfully";  
 
 }  } ?>
 
  
  <script>$('#password, #confirm_password').on('keyup', function () {
  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('Matching').css('color', 'green');
  } else 
    $('#message').html('Not Matching').css('color', 'red');
});</script>
 

<?php    
   if(isset($_GET['submit'])){
   $Admindata=$_GET['Admindata'];
 $adname = $_POST['adname']; 
 $ademail = $_POST['ademail']; 
 $admobile = $_POST['admobile']; 
 $adStatus = $_POST['adStatus'];
 
    $res = mysqli_query($con,"UPDATE `admin` SET `username`='$adname',`useremail`='$ademail',`mobile`='$admobile',`status`='$adStatus' WHERE id='$Admindata'"); 
 
if($res) { 
 echo "<center> <img src='images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Update Admin Detail Succesfully..</h6></center>"."<br />";
	header('Refresh:1; url=user-control.php');
 }  } ?>
 
 
 
 
 
 
 
 <?php    
   if(isset($_POST['tempname'])){
   $tempname=$_POST['tempname'];
 $type = $_POST['type']; 
 $fromname = $_POST['fromname'];
 $frommail = $_POST['frommail'];
 $subject = $_POST['subject'];
 $content = $_POST['content']; 
 $status = $_POST['Enabled'];
 
    $res = mysqli_query($con,"INSERT INTO `cat_template` (`type`, `tempname`, `fromname`, `frommail`, `subject`, `description`, `status`)
						 VALUES ('$type', '$tempname', '$fromname', '$frommail', '$subject', '$content', '$status')"); 
 
if($res) { 
 echo "<center> <img src='images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Create Template Succesfully..</h6></center>"."<br />";
	header('Refresh:1; url=email-template.php');
 }  } ?>
 
 
 
 
 
 <?php    
   if(isset($_POST['updateid'])){
   //$tempname=$_POST['tempname'];
  $Admindata = $_POST['updateid']; 
 $fromname = $_POST['fromname'];
 $frommail = $_POST['frommail'];
 $subject = $_POST['subject'];
 $content = $_POST['content']; 
 $status = $_POST['Enabled']; 
  
 $res = mysqli_query($con,"UPDATE cat_template SET fromname='$fromname', frommail='$frommail', subject='$subject', description='$content', status='$status' WHERE id='$Admindata'"); 
if($res) { 
 echo "<center> <img src='images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Update Template Succesfully..</h6></center>"."<br />";
	header('Refresh:1; url=email-template.php');
 }  } ?>