<?php         include_once('../fn/connect.php'); 
 
 ////////////////////////////////Price//////////////////////////////////////////////////////////////////
 // name: name, email: email, phone: phone, checkValues: checkValues
 if(isset($_POST['name']))
{				$emaildata =$_POST['name'];
			  $result = mysqli_query($con,"SELECT * FROM `domainRagistar` where demailid='$emaildata'"); $row = mysqli_fetch_array($result);
			    $chek=$row['demailid'];
				$id=$row['id'];
			  if(isset($row['demailid'])){
			  echo ' <input type="hidden" value="'.$id.'" id="acsId" />';
			   echo ' <input type="hidden" value="'.$id.'" id="dacsId" />';
			    echo '<div class="moduule_listsec">
<ul class="moduule_list">
<li>
<div class="row">
<div class="col-sm-1">
<div class="listlogo"><img style="width:60px;" src="images/mailicon.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>Email Notification</h5>
<p>&nbsp;&nbsp;Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
</div>
<div class="col-sm-5"> <span id="action">';
   if($row['status'] == '0'){ 
echo ' <button class="btn btn-default" onClick="ActiveData();">Activate</button>
<button class="btn btn-danger" disabled>Deactivate</button> 
<button class="btn btn-primary" disabled>Configure</button>  </span>';

}else{ echo '<button class="btn btn-default" disabled>Activate</button>
<button class="btn btn-danger" onClick="DeActiveData();">Deactivate</button> 
<button class="btn btn-primary" id="confbtn2">Configure</button>';}
echo '</div>
</div>
</li>

</ul> 


<form class="form-horizontal">
<div class="input-group">
  <span class="input-group-addon" id="basic-addon1">Email Address</span>
  <input type="text" class="form-control" value="'.$chek.'" placeholder="support@gmail.com" aria-describedby="basic-addon1" onChange="emailData();">
</div>
</form>



</div>';
			  }else{echo "<strong style='color:#FFAAAA;'>NO Data Found, Try Again.</strong>";
			  echo '<div class="moduule_listsec">
<ul class="moduule_list">
<li>
<div class="row">
<div class="col-sm-1">
<div class="listlogo"><img style="width:60px;" src="images/mailicon.png" alt="llogo"></div>
</div>
<div class="col-sm-6">
<h5>Email Notification</h5>
<p>&nbsp;&nbsp;Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
</div>
<div class="col-sm-5">
<button class="btn btn-default">Activate</button>
<button class="btn btn-danger">Deactivate</button> 
<button class="btn btn-primary">Configure</button>
 <!--<button class="btn btn-default">Activate</button>
<button class="btn btn-danger" disabled>Deactivate</button> 
<button class="btn btn-primary" id="confbtn2" disabled>Configure</button>-->
</div>
</div>
</li>

</ul> 


<form class="form-horizontal">
<div class="input-group">
  <span class="input-group-addon" id="basic-addon1">Email Address</span>
  <input type="text" class="form-control" placeholder="support@gmail.com" id="fdata" aria-describedby="basic-addon1" onChange="emailData();">
</div>
</form>



</div>';
			  }
 }
 
 
 
 
 
 
 
  
 
 
 ////////////////////////////////Price//////////////////////////////////////////////////////////////////
 // name: name, email: email, phone: phone, checkValues: checkValues
 if(isset($_POST['acsId']))
{			$acsId =$_POST['acsId'];	 
			  $result = mysqli_query($con,"UPDATE domainRagistar SET status='1' where id='$acsId'");
			  if($result) {
			   $emaild = mysqli_query($con,"SELECT * FROM `domainRagistar` where id='$acsId'"); $emaildrow = mysqli_fetch_array($emaild);
			    $Email=$emaildrow['demailid'];
				$to = $Email;
$subject = "Your Domain";
//$txt = "Hello - " .$First." ".$Last." Thanks For creating ragistration";
$headers = "Your Domain is active ."; 
mail($to,$subject,$headers);
			 echo '<button class="btn btn-default" disabled>Activate</button>
<button class="btn btn-danger" onClick="DeActiveData();">Deactivate</button> 
<button class="btn btn-primary" id="confbtn2">Configure</button>';

}
 }
 
 
 
 
 
 
 
 
 
 ////////////////////////////////Deactive//////////////////////////////////////////////////////////////////
 // name: name, email: email, phone: phone, checkValues: checkValues
 if(isset($_POST['dacsId']))
{			$dacsId =$_POST['dacsId'];	 
			  $result = mysqli_query($con,"UPDATE domainRagistar SET status='0' where id='$dacsId'");
			  if($result) {
			   $emaild = mysqli_query($con,"SELECT * FROM `domainRagistar` where id='$acsId'"); $emaildrow = mysqli_fetch_array($emaild);
			    $Email=$emaildrow['demailid'];
				$to = $Email;
$subject = "Your Domain";
//$txt = "Hello - " .$First." ".$Last." Thanks For creating ragistration";
$headers = "Your Domain is Deactive ."; 
mail($to,$subject,$headers);
			 echo '<button class="btn btn-default" >Activate</button>
<button class="btn btn-danger" disabled >Deactivate</button> 
<button class="btn btn-primary" id="confbtn2" disabled>Configure</button>';

}
 }
 ?>  
 
 
 
 
  