<?php         include_once('../fn/connect.php'); 
    $txtid = $_GET['txtid']; 
	$val = $_GET['val'];
	$quer=mysqli_query($con,"UPDATE `texdataadd` SET `tex_enable` = '$val' WHERE  `tid` ='$txtid'");
 if($quer){
 echo "<script>  window.open('tax-rules.php','_self');</script>";
 }
	
	
	?>