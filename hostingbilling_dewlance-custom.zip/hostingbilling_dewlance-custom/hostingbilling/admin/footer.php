<div class="footer">
 <div class="container">
 <div class="powered">
 <!--<h4>Powered by : <span>Dewlance</span></h4>-->
 </div>
 </div>
 
 <div class="copyright">
 <div class="container">
 <p>© <?php echo date('Y'); ?> Dewlance Web Hosting All Rights Reserved. | Developed by <a href="http://dewlance.com/">dewlance</a></p>
 </div>
 </div>
 
 </div>