<?php
   include_once('../fn/connect.php'); 
   
if (isset($_GET['Groupid']) && is_numeric($_GET['Groupid']))
 {
 // get id value
 $id = $_GET['Groupid'];;
 } 

$rec = "DELETE FROM `productgroupadd` WHERE  pgroupid='$id'";

if(mysqli_query($con,$rec)){
	echo "<center> <img src='../images/ajax-loader.gif' alt='loader_image' id='LOderImgId'  style='border: 0; padding: 1px 5px 6px 2px;' >
 </center>";
	echo "<center></h6>Please wait while you are redirected in 1 seconds..</h6></center>"."<br />";
	header('Refresh:1; url=hostingproduct.php');
}
else{
	die("Data failed to delete in the database");
}
//////////////////////////////////////////////////
if (isset($_GET['Assign']) && is_numeric($_GET['Assign']))
 {
 // get id value
 $id = $_GET['Assign'];
 $Val = $_GET['Val'];
 } 

$rec = "UPDATE productgroupadd SET status='$Val' WHERE pgroupid='$id'";

if(mysqli_query($con,$rec)){
	 
	header('Refresh:1; url=hostingproduct.php');
}
else{
	die("Data failed to delete in the database");
}


?>
