  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">	</script> 
	<script type="text/javascript" language="javascript" class="init"> 
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} ); 
	</script>
     <style> 
#example tr:nth-child(2n) {  background-color: #F3F3F3;}

#example tr {  background-color: white;} 
</style> 
  </head>
  <body>
  
    <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata");  ?>
  
  <!--headerpart-end-->
  

<div class="clientprofile">
<div class="container">
<div class="listservisdata">
<h3><strong>Support</strong></h3>

  <div class="row">
  <div class="col-md-6">
  <div class="prodform">
<form class="form-horizontal">
<h4 class="forsrch"><a href="#">Filter Search</a></h4>
<div class="serchfld">
<div class="input-group">
  <input type="text" class="form-control" placeholder="Search..." >
  <span class="input-group-addon" id="">Search</span>
</div>
</div>
<br>

  <div class="form-group">
    <label class="control-label col-sm-3" for="Client">Search by Client:</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Client">Search by Ticket Subject:</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Client">Search by Email:</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Client">Search by Ticket ID:</label>
    <div class="col-sm-9">
     <input type="text" class="form-control" id="">
    </div>
  </div> 
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-danger">Submit</button>
    </div>
  </div>
</form>
</div>
</div>
</div>


    
<div class="table-responsive">
<table id="example" class="table table-hover" cellspacing="0" width="100%">
  <thead>
    <tr>
      <th>SR<!--<input type="checkbox" id="checkAll">--></th>
      <th>Department</th>
      <th>Ticket Subject</th>
       <th>Submiter Name</th>
        <th>Ticket Status</th>
         <th>Last Reply time</th>
         <th> </th>
         <th> </th>
    </tr>
  </thead>
  <tbody>
    <?php $i=0; $querydata=mysqli_query($con,"SELECT * FROM `ticket_sale` where closeticket='0'"); while($rowquery=mysqli_fetch_array($querydata)){ $i++;
  
  $dbdatetime =  $rowquery['cdatetime']; 
 
  //$curdatetime = date($dbdatetime);  
$date1 = new DateTime("$dbdatetime");
  $date2 = new DateTime("now");
$diff = $date1->diff($date2);
// 38 minutes to go [number is variable]
  $minutes=( ($diff->days * 24 ) *60 )/60 + ( $diff->i) . ' minutes';
// passed means if its negative and to go means if its positive
 // ($diff->invert == 1 ) ? ' passed ' : ' to go ';
  
  ?>
       
    <tr>
      <td><?php echo  $i; ?><!--<input type="checkbox" id="checkItem">--></td>
       <td><?php echo $rowquery['depname']; ?></td>
       <td><p class="tablelip"><a href="support-ticket.php?stival=<?php echo $rowquery['id']; ?>"><?php echo $rowquery['subjec']; ?> </a></p></td>
        <td> John Smith</td>
        <?php if($rowquery['openstatus'] ==0){ ?>
       <td> Open </td>
       <?php }else{?>
       <td>NotOpen </td>
       <?php }?>
       <td><?php echo $hours = floor($minutes / 24).' Day : '.floor($minutes / 60).' hours : '.($minutes -   floor($minutes / 60) * 60) . ' minutes'; echo ($diff->invert == 1 ) ? ' passed ' : ' to go ';?></td>
        <td><a href="actionwork1.php?opticket=<?php echo $rowquery['id']; ?>"> <button class="btn btn-info">Close</button></a></td>
        
         <td><a href="deletetick.php?tdpid=<?php echo $rowquery['id']; ?>"><button class="btn btn-danger">Delete</button></a></td>
    </tr>
    <?php }?>
    
  </tbody>
</table>
</div> 

 
 
 </div> 

<br>
 
<br> 

</div>
</div>
</div>



<div class="clearfix"></div>
 
  <!--home--contant----end--->
 <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 
 

  

  </body>
</html>