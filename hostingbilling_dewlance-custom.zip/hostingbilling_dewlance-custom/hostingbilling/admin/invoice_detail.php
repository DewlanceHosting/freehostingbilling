 <?php  session_start();   error_reporting(0); //if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../css/style.css" rel="stylesheet" type="text/css">
    
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php");   ?>
  
  <!--headerpart-end--> 

<div class="container">

<div class="listservisdata">
<h3 class="headdoman">My Domain Detail</h3>

<div class="domnpager">
<ul class="breadcrumb">
<?php if($_GET['voi']){ ?>
  <li><a href="clientprofile.php">MyProfile</a></li>
  <?php }else{?>
  <li><a href="view-modifyproduct.php">View/Modify Product</a></li>
   <?php }?>
  <li class="active">Domain Details</li> 
</ul> 

</div> 
<?php if($_GET['voi']){ ?>
<?php    $iddata= $_GET['voi']; 
$queryrdata = mysqli_query($con,"SELECT * FROM `user_hostingpay` where id='$iddata'"); $rowdata=mysqli_fetch_array($queryrdata);
?>
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Update Detail</h3> 
<div class="categry">
<ul>
 <li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; plan name</h4>
<br />
 <input type="text" class="form-control" id="PlanName"  value="<?php echo $rowdata['plan_name']; ?>">
</a>
</li>
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp;  Price</h4>
<br />
 <input type="text" class="form-control" id="PriceTotal"  value="<?php echo $rowdata['total']; ?>">
</li> 
</ul>
<center><button type="button" onClick="ChangeData();">Update</button></center>
<input type="hidden" id="uidda" value="<?php echo $_GET['voi'] ?>">
</div> 
</div>
</div>
</div>
 <script>
    function ChangeData() { //alert();
    var PriceTotal = $("#PriceTotal").val(); //alert(cmpname);
    var PlanName = $("#PlanName").val();
    var uidda = $("#uidda").val();
   
    $.post("datafuntion.php", { PriceTotal: PriceTotal, PlanName: PlanName, uidda: uidda }, 
    function(data) { 
	 $('#Usults').html(data);
	  alert(data);
	// location.reload();
	 $('#myForm')[0].reset();
    });
}
    </script>

 <div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Produc Detail</h3> 
<div class="categry">
<ul>
 <li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; plan name Date</h4>
<br />
<p><strong><?php echo $rowdata['plan_name']; ?></strong></p>
</a>
</li>
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Registration Date</h4>
<br />
<p><strong><?php echo $rowdata['transectiondate']; ?></strong></p>
</a>
</li>
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Domain Name</h4>
<br />
<p><strong><?php echo $rowdata['domain_name']; ?></strong></p>
</a>
</li>
 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Payment Amount</h4>
<br />
<p><strong>$<?php echo $rowdata['total']; ?></strong></p>
</a>
</li> 

<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Payment Method</h4>
<br />
<p><strong><?php echo $rowdata['paymethod']; ?></strong></p>
</a>
</li> 


</ul>
</div> 
</div>
</div>
</div> 
  <?php }else{?>
  <?php  $iddata= $_GET['voi']; 
$queryrdata = mysqli_query($con,"SELECT * FROM `user_hostingpay`"); $rowdata=mysqli_fetch_array($queryrdata);
?>
 <div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Produc Detail</h3> 
<div class="categry">
<ul>
 <li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; plan name Date</h4>
<br />
<p><strong><?php echo $rowdata['plan_name']; ?></strong></p>
</a>
</li>
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Registration Date</h4>
<br />
<p><strong><?php echo $rowdata['transectiondate']; ?></strong></p>
</a>
</li>
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Domain Name</h4>
<br />
<p><strong><?php echo $rowdata['domain_name']; ?></strong></p>
</a>
</li>
 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Payment Amount</h4>
<br />
<p><strong>$<?php echo $rowdata['total']; ?></strong></p>
</a>
</li> 

<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Payment Method</h4>
<br />
<p><strong><?php echo $rowdata['paymethod']; ?></strong></p>
</a>
</li> 


</ul>
</div> 
</div>
</div>
</div>
   <?php }?>
 

</div> 
</div>




 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>