<?php
session_start();
 echo $_SESSION['adminemailSession'];
if(!empty($_GET["edit"])) {
	$_SESSION["adminemailSession"] = "";
	$_SESSION["adminpassSession"] = "";
	session_destroy();
	header("Location: index.php");
}
 
/*if(session_destroy())
{
header("Location: index.php");
}*/
?>