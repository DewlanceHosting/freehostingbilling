<?php         include_once('../fn/connect.php');  ?>
 
<?php  if(isset($_POST['updatename'])) {?>

		<table class="table table-hover">
  <thead>
    <tr>
      <th>TLD</th>
      <th>Pricing</th>
      <th>DNS Management</th>
       <th>Email Forwarding</th>
        <th>Id Protection</th>
         <th>EPP Code</th>
          <th>Auto Registration</th>
          <th>Action</th>
    </tr>
  </thead>
  <tbody> 
  
  <?php $edit=$_POST['updatename']; $queryPrice = mysqli_query($con,"SELECT * FROM `priceadd` where priceid='$edit'");  $rowprice = mysqli_fetch_array($queryPrice); ?>
    <tr  id="resulprice">
      <td>
      <input class="form-control" id="Updatename" type="text" value="<?php echo $rowprice['domainname']; ?>" style="width:100px;">
      <input type="hidden" id="upid" value="<?php echo $_POST['updatename']; ?>" />
      </td>
      <td>
        <input class="form-control" id="Updateprice" placeholder="10 &dollar;" style="width:100px;" value="<?php echo $rowprice['domainprice']; ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">  
       </td>
       <td>
       <input type="checkbox" name="checkboxlist"  value="Y"id="">
       </td>
       <td>
       <input type="checkbox" name="checkboxlist"  value="Y"id="" >
       </td>
       <td>
       <input type="checkbox" name="checkboxlist" value="Y" id="">
       </td>
       <td>
       <input type="checkbox" name="checkboxlist" value="Y" id="">
       </td>
       <!--<td>
       <select id="updatephone" class="form-control">
       <option>None</option>
        <option>Email</option>
        </select>
        </td>-->
       <td> <button class="btn btn-danger" type="button" onClick="UpdateData();">Update</button></td>
    </tr> 
     
  </tbody>
</table>	    
 <?php  } ?>