  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
   <?php include_once('header.php'); ?>
  
  <!--headerpart-end--> 

<section class="clientdashh">
<div class="container">
<div class="listservisdata">
<div class="row">
  <div class="col-md-offset-2 col-md-8 col-md-offset-2">
  <h3>Email Template </h3>
  <div class="prodform">
  <form action="edit_email-template.php" method="post" enctype="">
<div class="form-horizontal">
<h4>Create New Email Template</h4><br>
  <div class="form-group">
    <label class="control-label col-sm-3" for="Type">Type :</label>
    <div class="col-sm-9"> 
      <select class="form-control" id="" name="EmailType">
      <option value="">select</option>
      <option value="General Messages">General</option>
      <option value="Product Messages">Product</option>
      <option value="Service Messages">Service</option>
      <option value="Domain Messages">Domain</option>
      <option value="Support Messages">Support </option>
      </select>
    </div>
  </div> 
  <div class="form-group">
    <label class="control-label col-sm-3" for="Service">Template Name :</label>
    <div class="col-sm-9"> 
      <input type="text" class="form-control" id="" name="templatname">
    </div>
  </div> 
  
  <div class="form-group"> 
    <div class="col-sm-offset-3 col-sm-9">
       <button type="submit" class="btn btn-danger" name="">Create</button> 
    </div>
  </div>
</div>
</form>
</div> 
 
<?php $queryProduc = mysqli_query($con,"SELECT * FROM `cat_template`"); while($ProducName =mysqli_fetch_array($queryProduc)){  ?>
<h3><?php echo $ProducName['type']; ?> </h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>	
      <th>Status</th>
      <th>Template Name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4><?php echo $ProducName['tempname']; ?></h4></td>
      <td><a href="edit_email-template.php?edit=<?php echo $ProducName['id']; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
  <!--  <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>-->
  </tbody>
</table>
</div>
<?php }?>

<!--


<h3>Invoice Messages </h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Status</th>
      <th>Template Name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
  </tbody>
</table>
</div>




<h3>Support Messages </h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Status</th>
      <th>Template Name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
  </tbody>
</table>
</div>



<h3>Product/Service Messages </h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Status</th>
      <th>Template Name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
  </tbody>
</table>
</div>


<h3>Domain Messages </h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Status</th>
      <th>Template Name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
    <tr>
      <td>
      <h4><i class="fa fa-check"></i></h4>
      </td>
      <td><h4>xxxxxxxxxxxxxxxxxxxxxx</h4></td>
      <td><a href="edit_email-template.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></td>
    </tr>
  </tbody>
</table>
</div>
-->


</div> 
</div> 

</div>
</div>
</section> 
 
 <!--home--contant----end--->
<?php include_once('footer.php'); ?>
 <!----------footer---end-------> 

  </body>
</html>