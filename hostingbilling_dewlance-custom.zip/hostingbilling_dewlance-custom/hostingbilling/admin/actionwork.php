<?php //actionwork.php Product: Product
include_once('../fn/connect.php');  
if(isset($_POST['Accepid']))
{     
		   $Accepid =  $_POST['Accepid']; //exit();
		   $Statusdata =  $_POST['Statusdata'];
		   $Product =  $_POST['Product'];
		   $queprodu=mysqli_query($con,"SELECT * FROM `productadd` where  modulid='$Product'");  $rowqueprodu=mysqli_fetch_array($queprodu); 
   $pid=$rowqueprodu['producid'];
   
		   if(isset($_POST['Statusdata']))
			{ $insert_query = "UPDATE `user_hostingpay` SET producid='$pid', `status`='$Statusdata' WHERE id= '$Accepid'";	
			}else{  $insert_query = "UPDATE `user_hostingpay` SET producid='$pid',`status`='1' WHERE id= '$Accepid'";}
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		echo "<center></h6>Update Row Successfully..</h6></center>"."<br />";
		
	//header('Refresh:1; url=config-product.php'); 
		}else {echo"No Data Found";} 
 }
 
 ///////////////////////////////////domain update///////////domainId: domainId, Domain: Domain
 if(isset($_POST['domainId']))
{     
		   $domainId =  $_POST['domainId']; //exit();
		   $Domain =  $_POST['Domain']; 
		     $insert_query = "UPDATE `user_domainpay` SET producid='$pid', `domain_name`='$Domain' WHERE id= '$domainId'"; 
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		echo '<div class="col-sm-9" id="domainRs"> 
      <input type="text" class="form-control" id="Domain" value="'.$Domain.'" onChange="domailnname();" placeholder="Example.com">
    </div>';
	//header('Refresh:1; url=config-product.php'); 
		}else {echo '<div class="col-sm-9" id="domainRs"> 
      <input type="text" class="form-control" id="Domain" value="nodata" placeholder="Example.com">
    </div>';}
	 
 }
 ////////////////////////////////

if(isset($_POST['Cancelid']))
{  
		   $Cancelid =  $_POST['Cancelid']; //exit();
		  $insert_query = "UPDATE `user_hostingpay` SET `ordercancel`='1' WHERE id= '$Cancelid'";
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		echo "<center></h6>Update Row Successfully..</h6></center>"."<br />";
	//header('Refresh:1; url=config-product.php'); 
		}else {echo"No Data Found";}
	 
 }
 // producid: producid, Billing: Billing 
if(isset($_POST['producid']))
{     
		    $producid =  $_POST['producid']; 
		    $Billing =  $_POST['Billing']; 
		   
			  $insert_query = "UPDATE `productadd` SET `billtype`='$Billing' WHERE producid= '$producid'";	
			 
	    $run = mysqli_query($con,$insert_query); 
		if($run) { 
		echo "<center></h6>Update Row Successfully..</h6></center>"."<br />";
	  
		}else {echo"No Data Found";}
	 
 }
 
  // Amount: Amount, Requiring: Requiring, NextDue: NextDue, OrderPlacedOn: OrderPlacedOn, UserIddata: UserIddata 
 if(isset($_POST['NextDue']))
{   	 
		   $Amount =  $_POST['Amount']; 
		   $Requiring =  $_POST['Requiring'];
		   $OrderPlacedOn =  $_POST['OrderPlacedOn']; 
		   $NextDue =  $_POST['NextDue'];
		   $UserIddata =  $_POST['UserIddata'];  
		   
	    $insert_query = "UPDATE `user_hostingpay` SET `transectiondate`='$OrderPlacedOn', `total`='$Amount', `nexduedate`='$NextDue' WHERE `id`='$UserIddata'";	
			 
	    $run = mysqli_query($con,$insert_query); 
		if($run) { echo" Data Added";?>
		<div id="RightView">
  <div class="form-group">
    <label class="control-label col-sm-4" for="Amount">Amount :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="Amount" value="<?php echo $_POST['Amount']; ?>"  onChange="rightDataonchage();">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Requiring">Requiring Amount :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" id="Requiring" value="<?php echo $_POST['Requiring']; ?>" onChange="rightDataonchage();">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Orderplaced">Order Placed On :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control" name="dateofbirth" id="OrderPlacedOn"  value="<?php echo $_POST['OrderPlacedOn']; ?>" onChange="rightDataonchage();" >
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-4" for="Orderplaced">Next Due Date :</label>
    <div class="col-sm-8"> 
      <input type="text" class="form-control"  name="dateofbirth" id="NextDue"  value="<?php echo $_POST['NextDue']; ?>" onChange="rightDataonchage();"  >
    </div>
  </div> 
  
  </div>  
  
	<?php 	}else {echo"No Data Found";} 
 }
 ?>
 
  
 
    <?php //Proidmodfy: Proidmodfy, PriceType: PriceType
	if(isset($_POST['PriceType']))
	
{  		$Proidmodfy =  $_POST['Proidmodfy']; //exit();
		   $pricetype =  $_POST['PriceType'];
		    
	   $queprodu=mysqli_query($con,"SELECT * FROM `productadd` where  producid='$Proidmodfy'");  $rowqueprodu=mysqli_fetch_array($queprodu); 
    // $pricetype=$rowdata['pricetype'];
	
	if($pricetype  == 'Free'){  
	 
	echo '<div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType"  onChange="BillingCycle();">
       <option >Free</option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select> 
  </div> 
  </div>';
   
	  }elseif($pricetype == 'One Time'){ // echo"One Time";  
	
 echo ' <div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType"  onChange="BillingCycle();">
       <option >One Time</option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select>
   </div> 
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="UPrice" placeholder="Enter Price" value="'.$rowqueprodu['price'].'">
    </div>
  </div> 
  ';
   
	  }elseif($pricetype == 'Requiring'){ //echo"Requiring";  
	
	
	echo '<div class="form-group">
    <label class="control-label col-sm-3" for="PriceType">Price Type:</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="PriceType" name="PriceType" onChange="BillingCycle();">
       <option >Requiring </option>
       <option>Free</option> 
       <option>One Time</option>
       <option>Requiring</option>
       </select>
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price ($):</label>
    <div class="col-sm-9"> 
     <input type="text" class="form-control" id="UPrice" placeholder="Enter Price" value="value="'.$rowqueprodu['price'].'"">
    </div>
  </div> 
  
  <div class="form-group">
    <label class="control-label col-sm-3" for="Price">Price : Billing Cycle</label>
    <div class="col-sm-9"> 
    <select class="form-control" id="UBillingType"><option value="'. $rowqueprodu['billtype'].'">'.$rowqueprodu['billtype'].'</option>
     <option>Monthly</option>
     <option>Quarterly</option>
     <option>Annualy</option>
     </select>
    </div>
  </div> ';
   
	  }


}?>

 