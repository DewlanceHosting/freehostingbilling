  <?php include_once('../fn/connect.php');  ?><?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
   <?php include_once('header.php');  ?>
  
  <!-------------headerpart-end--domainpriceData.php----------->
  <?php $edit_id = base64_decode($_GET['1']); if(!empty($edit_id)){?>
  <?php   $content = mysqli_query($con,"SELECT * FROM `admin` where id='$edit_id'");  $Erowdata=mysqli_fetch_array($content);   ?>
  
<div class="container">
<div class="row">
<div class="col-md-offset-3 col-md-6 col-md-offset-3">
<div class="edtfrm">
<h3>Update Admin Details</h3>
<form class="" action="passcheck.php?Admindata=<?php echo $edit_id; ?>" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="email">Username :</label>
    <input type="text" class="form-control" id="adname" name="adname" oninput="this.value = this.value.replace(/[^a-z.]/g, '').replace(/(\..*)\./g, '$1');"value="<?php echo $Erowdata['username'];?>">
  </div>
  <div class="form-group">
    <label for="email">Useremail :</label>
    <input type="email" class="form-control" id="ademail" name="ademail" value="<?php echo $Erowdata['useremail'];?>">
  </div>
  
  <div class="form-group">
    <label for="Mobile">Mobile :</label>
    <input type="text" class="form-control" id="admobile" name="admobile" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" value="<?php echo $Erowdata['mobile'];?>">
  </div>
  
    <div class="form-group">
    <label for="Status">Status :</label>
    <select required class="form-control" name="adStatus" id="comment"><option value="1">In-Active</option><option value="0">Active</option></select>

  </div> 
  <div class="form-group"> 
      <button type="submit" class="btn btn-default">Submit</button>
  </div>
</form>
</div>
</div>
</div>
</div>


<?php }?>
  
<style>
.edtfrm{ margin-top:20px; padding:15px; border:solid 1px #ddd;}

.edtfrm h3{ margin-bottom:20px; border-bottom:solid 1px #ddd; padding-bottom:10px; font-weight: bold;}
tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
 
<section class="clientdashh">
<div class="container"> 
 
<div class="listservisdata">
<h3>User Control</h3>
<div class="table-responsive">
<table class="table table-hover" border="1">
  <thead>
    <tr>
      <th>SN</th>
      <th>User Name</th> 
      <th>User Password</th> 
       <th>User Email</th>
        <th>Mobile</th>
         <th>Status</th>
          <th>Action</th>
          <th></th>
    </tr>
  </thead>
  <tbody>  

  <?php $i=0; $quer=mysqli_query($con,"SELECT * FROM `admin`"); while($rowdata=mysqli_fetch_array($quer)){ $i++; $editid= $rowdata['id']; ?>
      <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $rowdata['username'];?></td> 
      <td><?php echo $rowdata['userpass'];?> </td>
        <td><?php echo $rowdata['useremail'];?> </td>
          <td> <?php echo $rowdata['mobile'];?></td>
        <?php if($rowdata['status'] == '0'){?>

  <td><strong style="color:#339900;">Active</strong></td>

<?php } else{?>

  <td><strong style="color:#FF0000;">In-Active</strong></td>

 <?php } ?>
       <td><a href="user-control.php?1=<?php echo base64_encode($editid) ?>"><button class="btn-info">Edit</button></a></td>
       <td><a  href="deletedata.php?1ad=<?php echo $rowdata['id'];  ?>"><h4 class="fa fa-trash"></h4></a></td>
    </tr> 
    <?php  }?>
    
    
  </tbody>
</table>
</div> 
 
</div> 
</div>

</section> 
 
 <!--home--contant----end---> 
    <?php include_once('footer.php');  ?>
 <!----------footer---end------->
 



  <!-- Modal -->
  <!--<div class="modal fade" id="usercontrol-edit" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="font-size: 18px; font-weight: bold;">Edit User</h4>
        </div>
        <div class="modal-body">
    <form>
    <div class="form-group">
    <label for="email">Username :</label>
    <input type="email" class="form-control" id="email">
  </div>
    
  
  <!--<div class="form-group">
    <label for="pwd">Userpass :</label>
    <input type="password" class="form-control" id="pwd">
  </div> 
  
  <div class="form-group">
    <label for="email">Useremail :</label>
    <input type="email" class="form-control" id="email">
  </div>
  
    <div class="form-group">
    <label for="Mobile">Mobile :</label>
    <input type="text" class="form-control" id="Mobile" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
  </div>
  
      <div class="form-group">
    <label for="Status">Status :</label>
    <select required class="form-control" name="status" id="comment"><option value="0">Active</option><option value="1">In-Active</option></select>

  </div>
  
  <button type="submit" class="btn btn-info">Submit</button>
</form>
        </div>
        
      </div>
    </div>
  </div>-->


  

  </body>
</html>