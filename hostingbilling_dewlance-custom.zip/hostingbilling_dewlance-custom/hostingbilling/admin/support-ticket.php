  <?php include_once('../fn/connect.php');  ?>
  <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['adminemailSession'])) && ( empty($_SESSION['adminpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link href="css/admin.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
     <script src="js/bootstrap-select.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
   <?php include_once("header.php"); ?>
  
  <!--headerpart-end--> 

<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Support Ticket</h3>

<div class="editrform">
 <?php if(isset($_GET['1r'])){?>  
	<form  action="actionwork2.php?stival=<?php echo  $_GET['1r'];?>" method="post" enctype="multipart/form-data">
	 <?php }else{ ?>
   <form  action="actionwork1.php?stival=<?php echo  $_GET['stival'];?>" method="post" enctype="multipart/form-data">
      <?php } ?>
 
    <div class="row">
    <div class="form-group">
     <?php if(isset($_GET['1r'])){$idg=$_GET['1r']; $qsupt=mysqli_query($con,"SELECT * FROM `suporttickte_maildata` where id='$idg'"); 
	 } 
	
	 else{$idg=$_GET['stival']; $qsupt=mysqli_query($con,"SELECT * FROM `ticket_sale` where id='$idg'");
	 }  $rowtick=mysqli_fetch_array($qsupt);
	  
	 ?>
      <label class="control-label col-sm-5" for="Subject">Subject : <?php if(isset($_GET['1r'])){echo $rowtick['subject']; }else{  echo $rowtick['subjec']; } ?>  </label>
      <div class="col-sm-5"> <input type="hidden" name="ticketsub" id="ticketsub" value="<?php  echo $rowtick['subjec']; ?>" >
      <input type="hidden" name="Mailid" id="Mailid" value="<?php  echo $rowtick['simg']; ?>" >
      <input type="hidden" name="fds" id="dfvalue">
      <select class="form-control" id="opticketn" name="opticket" onChange="OnchangeDataAccept();"> 
      <option value="<?php echo $rowtick['openstatus'];?>"><?php if($rowtick['openstatus'] ==0){ echo "Open"; }else{echo "NotOpen"; }?></option>
       <option value="0">Open</option> 
       <option value="1">Closed</option>
      </select>
      </div>
      
      <div class="col-sm-2">
      <button class="btn btn-info">Close</button>
      </div>
    </div>
    
    
    </div>
    <div class="form-group">
      <label for="Message">Message</label>
       <?php if(isset($_GET['1r'])){?> 
	<textarea name="content" data-provide="markdown" rows="18" class="md-input" style="resize: none;"><?php  echo $rowtick['massagedata']; ?></textarea>
	 <?php }else{ ?>
     <textarea name="content" data-provide="markdown" rows="18" class="md-input" style="resize: none;"></textarea>
      <?php } ?>
   
    </div>
    <div class="input_fields_wrap row">
    <div class="col-sm-8">
    <label for="Attechment">Attechment</label>
    <input class="form-control" type="file" name="file"></div>
    <div class="col-sm-4">
     <button style="margin-top:24px;" type="button" class="add_field_button btn btn-primary">Add More Fields</button>
     </div>
</div> 
    <div class="form-group">
    <br><br>
<center>
  <?php if(isset($_GET['1r'])){?> 
	<button type="submit" name="Update" class="btn btn-danger">Update Response</button>
	 <?php }else{ ?>
   <button type="submit" name="submit" class="btn btn-danger">Add Response</button>
      <?php } ?>

</center>
    </div> 
  </form>
  
  
  <div class="clearfix"></div>
  
<ul class="supportcomment">
<?php
//id`, `subject`, `mailto`, `mailfrom`, `massagedata`, `attechfile`, `senddate`, `userip`

 $ticketData = mysqli_query($con,'SELECT * FROM `suporttickte_maildata`'); while($roewdata = mysqli_fetch_array($ticketData)){ ?> 
<li>
<div class="row">
<div class="col-sm-3">
<div class="usersdes">
<h5>Admin</h5>
<!--<h5><span>Client</span></h5><br>
--><div>
<a href="support-ticket.php?1r=<?php echo $roewdata['id']; ?>"><button class="btn btn-default btn-xs">Edit</button></a>
<a href="deletedatamail.php?1r=<?php echo $roewdata['id']; ?>"><button class="btn btn-danger btn-xs">Delete</button></a>
</div>
</div>
</div>
<div class="col-sm-9">
<div class="userscmnt">
<p><small><?php echo $roewdata['senddate']; ?></small></p>
<h4>Hello</h4>
<p><?php echo $roewdata['massagedata']; ?>  </p>
 <p><a href="<?php echo $roewdata['attechfile']; ?>">attechfile</a>&nbsp;&nbsp;&nbsp;<?php echo $roewdata['attechfile']; ?>&nbsp;&nbsp;&nbsp;<img src="images/<?php echo $roewdata['attechfile']; ?>" style="width:20px; height:10px;"></p>
<h4 class="botomh4">IP Address : (<?php echo $roewdata['userip']; ?>)</h4>

</div>
</div>
</div>

</li>
<?php }?>
<!--<li>
<div class="row">
<div class="col-sm-3">
<div class="usersdes">
<h5>John John John</h5>
<h5><span>Staff</span></h5><br>
<div>
<button class="btn btn-default btn-xs">Edit</button>
<button class="btn btn-danger btn-xs">Delete</button>
</div>
</div>
</div>
<div class="col-sm-9">
<div class="userscmnt">
<p><small>Posted on Thursday 20th May at 10:18</small></p>
<h4>Hello</h4>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when </p>

<h4>CPU : </h4>
<h4><span>RAM</span></h4>

<h4 class="botomh4">IP Address : (Client IP Address)</h4>

</div>
</div>
</div>

</li>--> 
</ul> 
</div> 
</div>
</div>
</div> 
</div>

</section>
 <input type="hidden" name="idup" id="idup" value="<?php  echo $rowtick['id']; ?>" >

 <script>    
        $('.delete_class').click(function(){
            // tr = $(this).closest('tr'),
              var  del_id = $(this).attr('id');  alert(del_id);

            $.ajax({
                url: "delete_page.php?delete_id="+ del_id,
                cache: false,
                success:function(result){
                    tr.fadeOut(1000, function(){
                        $(this).remove();
                    });
                }
            });
        });
</script>
<script>
function OnchangeDataAccept() {
  var idup = $("#idup").val(); //alert(idup);
    var opticketn = $("#opticketn").val();  //alert(opticket);
      $.post("actionwork1.php", { idup: idup, opticketn: opticketn},
    function(data) {
	 $('#results').html(data);
	  alert(data);
	 location.reload();
	 $('#myForm')[0].reset();
    });
}
</script> 
<div class="clearfix"></div>
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->

  

  </body>
</html>