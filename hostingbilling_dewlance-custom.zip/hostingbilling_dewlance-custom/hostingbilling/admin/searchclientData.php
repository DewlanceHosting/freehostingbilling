 <?php include_once('../fn/connect.php');  ?>
 <div class="table-responsive">
 
 

     
 

  <div class="table-responsive"> 
<table id="example" class="table table-hover" cellspacing="0" width="100%">
				 <thead>
    <tr>
      
      <th>Client Id</th>
      <th>Client Name</th> 
      <th>Country</th>
      <th>Date Created</th>
       <th>Status</th>
        <th>Active Services</th>
        <!--<th>Action</th>-->
    </tr>
  </thead>
  <tbody>
  <?php if(isset($_POST['name'])){ 
     $uds=  $_POST['name']; 
    $que=mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$uds' || fname='$uds' || email_id='$uds'"); 
	while($rowdata=mysqli_fetch_array($que)){ 
	  $dataView=$rowdata['id'];    $fsf=$rowdata['contryid'];?>
			<tr>
       <td><h4><a href="clientprofile.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['id']; ?></a></h4></td>
      <td><h4><a href="clientprofile.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['fname']; ?></a></h4></td> 
       <?php $quecontyr=mysqli_query($con,"SELECT * FROM `country` where id ='$fsf'"); $rowcdata=mysqli_fetch_array($quecontyr); ?>
      <td><?php echo $rowcdata['country']; ?></td>
      <td><h4><?php echo $rowdata['ragdate']; ?> </h4>      </td>
       <?php if($rowdata['status'] == '1'){?>

  <td>Active</td>

<?php } else{?>

  <td>In-Active</td>

 <?php } ?>
  <?php $queser=mysqli_query($con,"SELECT * FROM `user_hostingpay` where  status='0' && user_rid ='$dataView'");  $rowcount=mysqli_num_rows($queser); //$rowser=mysqli_fetch_array($queser); ?>
       <td><?php echo $rowcount; ?></td>
       <!--<td><a  href="deletedata.php?cl=<?php// echo $rowdata['id'];  ?>"><button class="btn btn-danger">Delete</button></a></td></td>-->
    </tr>
     <?php  }?> 
<?php  }?> 
  </tbody>
			</table>
</div>  