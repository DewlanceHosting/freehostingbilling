<?php  session_start();
include_once('../fn/connect.php');  
date_default_timezone_set("asia/kolkata");
  
?> 

 <?php  // Dname: Dname, descri: descri, email: email, hostname: hostname, popes: popes, hostemail: hostemail  
 if(isset($_POST['Dname'])){
$Dname = $_POST['Dname'];
$descri = $_POST['descri'];
$email = $_POST['email'];
$hostname = $_POST['hostname'];
$popes = $_POST['popes']; 
$hostemail = $_POST['hostemail'];
$emailpass = $_POST['emailpass'];
 
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"INSERT INTO `add_ticket_depart` (`name`, `emailid`, `description`, `hostname`, `pop`, `hemail`, `hemailpass`, `status`) 
											VALUES ('$Dname', '$email', '$descri', '$hostname', '$popes', '$hostemail', '$emailpass', '0')");
/*$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);*/
if( $run == 1 ) {
	echo 'sucsessfully Add';
 
	}
else {
	echo 'false';
}}
   ?>  
   <?php  // Dname: Dname, descri: descri, email: email, hostname: hostname, popes: popes, hostemail: hostemail  
 if(isset($_POST['depid'])){
 $depid = $_POST['depid'];
$Dname = $_POST['Dname1'];
$descri = $_POST['descri1'];
$email = $_POST['email1'];
$hostname = $_POST['hostname1'];
$popes = $_POST['popes1']; 
$hostemail = $_POST['hostemail1'];
$emailpass = $_POST['emailpass1'];
 
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"UPDATE `add_ticket_depart` SET `name` = '$Dname', `emailid` = '$email', `description` = '$descri', `hostname` = '$hostname', `pop` = '$popes', `hemail` = '$hostemail', `hemailpass` = '$emailpass' WHERE `tdpid` ='$depid'"); 
 
if( $run == 1 ) {
	echo 'sucsessfully UPDATE';
 
	}
else {
	echo 'false';
}}
   ?> 
   
    <?php  // Company: Company, email: email, Domain: Domain, URLCode: URLCode, Payto: Payto  
 if(isset($_POST['cmpname'])){
$email = $_POST['email'];
$Domain = $_POST['Domain'];
$URLCode = $_POST['URLCode'];
$Payto = $_POST['Payto'];
   $cmpname = $_POST['cmpname'];
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"INSERT INTO `company_detailadd`(`cmpname`, `cmpemail`,`domain`, `urlink`, `payto`, `status`) 
											VALUES ('$cmpname', '$email', '$Domain', '$URLCode', '$Payto','0')");
/*$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);*/
if( $run == 1 ) {
	echo 'sucsessfully Add company detail ';
 
	}
else {
	echo 'false';
}}
   ?>  
   
    <?php  // Company: Company, email: email, Domain: Domain, URLCode: URLCode, Payto: Payto  
 if(isset($_POST['cmpname1'])){
$email = $_POST['email1'];
$Domain = $_POST['Domain1'];
//$URLCode = $_POST['URLCode'];
$Payto = $_POST['Payto1'];
   $cmpname = $_POST['cmpname1'];
   
  $post_image =  $_FILES['URLCode1']['name'];
$image_tmp =  $_FILES['URLCode1']['tmp_name'];
 move_uploaded_file($image_tmp,"../images/$post_image");
 
$datime=date('d-m-Y h:i:s a');
if(empty($post_image)){
     $queryc="UPDATE `company_detailadd` SET `cmpname` = '$cmpname', `cmpemail` = '$email', `domain` = '$Domain', `payto` = '$Payto' ";
   
}else{
   $queryc="UPDATE `company_detailadd` SET `cmpname` = '$cmpname', `cmpemail` = '$email', `domain` = '$Domain', `urlink` = '$post_image', `payto` = '$Payto' ";   
}

$run = mysqli_query($con,$queryc);
if( $run == 1 ) {
	echo 'sucsessfully UPDATE company detail ';
 header('Refresh:1; url=configmenu.php');
	}
else {
	echo 'false'; header('Refresh:1; url=configmenu.php');
}}
   ?>  
    
   
   
     <?php  // Charset: Charset, langval: langval  
 if(isset($_POST['langval'])){
$langval = $_POST['langval'];
$Charset = $_POST['Charset'];
  $result = mysqli_query($con,"SELECT * FROM `languagesadd`"); while($row = mysqli_fetch_array($result))
      {  
	   $val=$row['local_langname']; $val1=$row['s_charset'];}
	   if(($val != $langval) &&($val1 != $Charset)){ 
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"INSERT INTO `languagesadd`(`local_langname`, `s_charset`, `status`) 
											VALUES ('$langval', '$Charset','0')"); 
if( $run == 1 ) {
	echo 'sucsessfully Add Languages ';
 
	}
else {
	echo 'false';
	
}
}
}
   ?> 
   
    <?php  // `mailtype`, `smtp`, `smpuser`, `etc`, `simg`, // Mailtype: Mailtype, SMTP: SMTP, SMTPUser: SMTPUser, Etc: Etc, ESign: ESign
 if(isset($_POST['Mailtype'])){
$mailtype = $_POST['Mailtype'];
$smtp = $_POST['SMTP'];
$etc = $_POST['Etc'];
$smpuser = $_POST['SMTPUser']; 
$simg = $_POST['ESign'];   
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"UPDATE `gernalemailidadd` SET mailtype='$mailtype',smtp='$smtp',smpuser='$smpuser',etc='$etc',simg='$simg' ");
 
if( $run == 1 ) {
 
echo "Data sucsessfully Add ";
	//header('Refresh:1; url=configmenu.php'); 
	}
else {
	echo 'false';
}}
   ?>  
   
   
    <?php  // `mailtype`, `smtp`, `smpuser`, `etc`, `simg`, // PriceTotal: PriceTotal, PlanName: PlanName, uidda: uidda
 if(isset($_POST['PriceTotal'])){
$PriceTotal = $_POST['PriceTotal'];
$PlanName = $_POST['PlanName'];
$uidda = $_POST['uidda'];  
 
$datime=date('d-m-Y h:i:s a');
$run = mysqli_query($con,"UPDATE `user_hostingpay` SET plan_name='$PlanName', total='$PriceTotal' where id='$uidda'");
 
if( $run == 1 ) {
 
echo "Data sucsessfully Add ";
	//header('Refresh:1; url=configmenu.php'); 
	}
else {
	echo 'false';
}}
   ?>  