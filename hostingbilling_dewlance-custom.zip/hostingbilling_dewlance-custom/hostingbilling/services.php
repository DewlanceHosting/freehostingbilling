  <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:hosting-category.php');}?>
  <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
     <?php include_once("tiltlechange.php"); ?>
 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} );

	</script>    
  </head>
  <body>
  <?php include_once("header.php"); ?> 
  <!--headerpart-end-->  
<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>List of Services</h3>
<div class="table-responsive">

<table id="example" class="display" cellspacing="0" width="100%">
				<thead>
					<tr>
      <th>Product Id</th>
      <th>Date of Registration</th>
      <th>Next Due Date</th>
      <th>Pricing</th>
       <th>Status</th>
        <th width="10">Payment Method</th>
    </tr>
				</thead>
				 
				<tbody>
<!--  `id`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
  <?php   $usid=$_SESSION['userid']; $query = mysqli_query($con,"SELECT * FROM `user_hostingpay` where user_rid='$usid'"); while($rowdata=mysqli_fetch_array($query)){
   $date1=$rowdata['transectiondate'];
 $date=date_create($date1);
date_add($date,date_interval_create_from_date_string("180 days"));
 $tiondate=date_format($date,"d-m-Y"); ?>
    <tr>
      <td>
      <h4><a href="viewproduct.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['plan_name']; ?></a></h4>
      <p><a href="viewproduct.php?1=<?php echo base64_encode($rowdata['id']) ?>"><?php echo $rowdata['domain_name']; ?></a></p>
      </td>
      <td><?php echo $rowdata['transectiondate']; ?></td>
      <td><?php echo $rowdata['nexduedate']; ?></td>
      <td><h4>USD &dollar; <span><?php echo $rowdata['total']; ?></span></h4></td>
       <?php if($rowdata['status'] == '1'){?>

 <td><a href="success.php?1=<?php echo base64_encode($rowdata['id']); ?>"><button class="btn btn-default fixbtnn form-control">Active</button></a></td>

<?php } elseif($rowdata['status'] == '0'){?>

 <td><button class="btn btn-warning form-control fixbtnn">Pending</button></td>

 <?php } elseif($rowdata['status'] == '2'){?>

<td><button class="btn btn-danger form-control fixbtnn">In-Active</button></td>

<?php } elseif($rowdata['status'] == '3'){?>

 
 <td><button class="btn btn-default form-control fixbtnn" style="background:#000; color:#fff;">Cancelled</button></td>
 <?php } ?>
       
       <td><?php echo $rowdata['paymethod']; ?></td>
    </tr>
    <?php } ?>
   
    
  </tbody> </table>  
</div>

</div> 
</div>

</section> 
 
 <!--home--contant----end--->
 
  
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>