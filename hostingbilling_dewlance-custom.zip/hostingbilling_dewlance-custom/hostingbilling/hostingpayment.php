 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
     
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php");  ?>
  
  <!--headerpart-end-->
  
<?php $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata); ?>
 <?php
        if (!empty($_REQUEST)) {
            $product_no = $_REQUEST['item_number']; // Product ID
            $product_transaction = $_REQUEST['tx']; // Paypal transaction ID
            $product_price = $_REQUEST['amt']; // Paypal received amount value
            $product_currency = $_REQUEST['cc']; // Paypal received currency type
            $product_status = $_REQUEST['st']; // Paypal product status  
			
 $palanname=$_SESSION["palanname"];
  $palan_amt=$_SESSION["palan_amt"];
  $domainname=$_SESSION["domainname"];
  $domain_amt=$_SESSION["domain_amt"];
  $proId=$_SESSION["proId"];
  $bill=$_SESSION["bill"];
  $total=$_SESSION["total"]; 
  $userid=$_SESSION["userid"];
  
        }
        ?>
<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-1 col-md-10 col-md-offset-1">
 
<div id="content">



<div style="border:solid 1px #ddd; padding:10px;">

<table style="width:100%">
  <tr>
    <th>
    <img src="images/<?php echo $rowdata['urlink']; ?>" alt="logo" style="width:200px;">
    </th>
    <th style="float:right;">
   <!-- <h4>Paid</h4>
    <p>Due Date : <?php// echo date('d-m-Y'); ?></p>
    <button type="button" style="background: none;border: none; margin-bottom: 6px;"><img src="images/paypalbutton.png" /></button>-->
    </th> 
  </tr>
  <?php $userR = $_SESSION['userid']; $Paytoo= mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowDet = mysqli_fetch_array($Paytoo); ?>
  
  <tr style="background: #f5f9f9;line-height: 44px; font-size: 20px; color: #444;">
    <th style=""> &nbsp; Invoice To : </th>
    <th style="text-align:right"> Pay To : &nbsp; &nbsp;&nbsp;</th> 
  </tr>
  
  
  <tr>
    <td colspan="2">
 <table style="width:100%">
  <tr style="line-height: 30px;">
    <th style="">Client Name</th>
      <th style="text-align:right">Company Name</th>
    </tr>
    <tr>
    <td style=""> <h4><?php echo $rowDetai['fname']." ".$rowDetai['lname'];?></h4></td>
      <td style="text-align:right"><?php echo $rowDet['cmpname']; ?></td>
  </tr>
  
    <tr style="line-height: 35px;">
    <th style="">Client Address</th>
    <th style="text-align:right">Company Address</th>
    </tr>
  
      
   
<tr>
    <td style=""><p> <?php echo $rowDetai['add']." ".$rowDetai['pin']." ".$rowDetai['city']." ".$rowDetai['statename']." ".$rowDetai['country'];?></p></td>
      <td style="text-align:right"><?php echo $rowDet['payto']; ?></td>
  </tr>
  
 
  
</table>
    </td>
  </tr>
 
  
 <tr style="line-height: 44px; font-size: 18px;background: #f8f8f8; border: solid 1px #ddd;">
    <th colspan="2">&nbsp;&nbsp;&nbsp;  Invoice Item : </th> 
  </tr> 
  
  <tr style="">
    <td colspan="2">
    
    <table style="width:100%">
  <tr style="line-height: 40px;">
    <th>Description</th>
    <th>Amount</th> 
  </tr>
  <tr style="line-height: 40px;">
    <td>Plane Name : <?php echo $palanname;?> </td>
    <td><?php echo $palan_amt.' '.$product_currency;?></td> 
  </tr>
   
  <tr style="line-height: 40px;">
    <td>Domain Name : <?php echo $domainname;?></td>
    <td><?php echo $domain_amt.' '.$product_currency;?></td> 
  </tr>
   <tr>
  <td style="border-bottom:solid 1px #ddd;">&nbsp;</td>
  </tr> 
  <tr style="line-height: 40px;">
    <td>Subtotal : </td>
    <td><?php echo $total.' '.$product_currency;?></td> 
  </tr>
  <?php $qdata = mysqli_query($con,"SELECT * FROM `texdataadd`"); while($rowda=mysqli_fetch_array($qdata)){?>
  <tr style="line-height: 40px;">
    <td>Text : <?php echo $rowda['texname'];?></td>
    <td><?php  echo $rowda['texrate'].' %';?></td> 
  </tr>
  <?php $ttotal =$ttotal + $rowda['texrate']; }  $ttotal1 = ($ttotal / 100) * $total;?>
     <tr>
  <td style="border-bottom:solid 1px #ddd;">&nbsp;</td>
  </tr>
    <tr style="line-height: 40px;">
    <td>Total : </td>
    <td><?php echo $total + $ttotal1.' '.$product_currency;?></td>
  </tr>
</table> 
    </td> 
  </tr>
  
  <tr>
  <td style="border-bottom:solid 1px #ddd;">&nbsp;</td>
  </tr>
  
         <?php 
		$oderid =$_SESSION["oderid"];
		   $pricedataadd = $total + $ttotal1;
                //Rechecking the product price and currency details
				 $resultz = mysqli_query($con,"SELECT * FROM user_hostingpay"); while($rowz = mysqli_fetch_array($resultz))
      {
	   $val=$rowz['oderid'];}
	   if($val != $oderid){  
	   
                
                   // echo "<P>Transaction Status - " . $product_status . "</P>";
                   // echo "<P>Transaction Id - " . $product_transaction . "</P>";
                  //  echo "<div class='back_btn'><a href='index.php' id= 'btn'><< Back</a></div>"; 
///////////////////////////////////////////////////////////////////data insert//////////////////////////////////////////////////////////////////				  
      if(isset($_SESSION["proId"]) && ($_SESSION["palanname"])){
    $First = $_SESSION["proId"]; 
    $did = $_SESSION["proId"]; 
    $prs = $_SESSION["proId"]; 
    $don = $_SESSION["domainname"]; 
    $plan_name = $_SESSION["palanname"]; 
	$transectiondate = date('d-m-Y');
	$oderid =$_SESSION["oderid"];
	
	
	 $date1=$rowdata['transectiondate'];
 $date=date_create($date1);

 
     if ($bill == 'Quarterly') { 
       date_add($date,date_interval_create_from_date_string("90 days"));
    } else if ($bill == 'Monthly') { 
        date_add($date,date_interval_create_from_date_string("30 days")); 
    } else if ($bill == 'Yearly') { 
      date_add($date,date_interval_create_from_date_string("352 days"));
    } 
 	 $tiondate=date_format($date,"d-m-Y");

   $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);  
     $Paytoo= mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowDet = mysqli_fetch_array($Paytoo);
//$oderid=uniqid(); 
//$Password = $md5($_POST['Password']);  
 $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
 
 
		 	$insert_query = "INSERT INTO `user_hostingpay`(`producid`,`user_rid`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '$plan_name','$transectiondate', '$oderid', '$product_transaction', 'Paypal', '0')";
	  
		$run = mysqli_query($con,$insert_query);
		if($run) {
	   "Invoice Create sucsessfully created"; 
		 $insert_query1 = "INSERT INTO `user_domainpay`(`producid`,`user_rid`, `domain_name`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '".$_SESSION["domainname"]."', '$plan_name','$transectiondate', '$oderid', '$product_transaction', 'Paypal', '0')";
	 mysqli_query($con,$insert_query1);
	 
		 $Tomail =$rowDetai['email_id'];
//`id`, `type`, `tempname`, `fromname`, `frommail`, `subject`, `description`, `status`
 $emaildata= mysqli_query($con,"SELECT * FROM `cat_template` where id='11'"); $subjdata=mysqli_fetch_array($emaildata);
    $fromid=$subjdata['frommail'];
//massagedata: massagedata 

$to = $Tomail;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="image/logo.png" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; '.$subjdata['fromname'].'</strong></p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Massage : '.$subjdata['description'].'</strong></p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $Tomail.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Package Name: &nbsp;'. $palanname.'</strong></p>
 <p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Domain Name: &nbsp;'. $domainname.'</strong></p>

  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong></strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);

/*echo "<script>alert('Invoice Create')</script>";
		echo "<script>window.open('hostingpayment.php','_self')</script>";*/
		}
		 } else{ 
  
//$oderid=uniqid(); 
//$Password = $md5($_POST['Password']);  
 $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
 
 $First = $_SESSION["proId"]; 
      $did = $_SESSION["proId"]; 
   $prs = $_SESSION["proId"]; 
   $don = $_SESSION["domainname"]; 
   $plan_name = $_SESSION["palanname"]; 
$transectiondate = date('d-m-Y');
$oderid = mt_rand(100000, 999999);

			 $insert_query = "INSERT INTO `user_domainpay`(`producid`,`user_rid`, `domain_name`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '".$_SESSION["domainname"]."', '0','$transectiondate', '$oderid', '$product_transaction', 'Paypal', '0')";
		$run = mysqli_query($con,$insert_query);
		if($run) {
		 //echo "Invoice Create sucsessfully created";  
		 $Tomail =$rowDetai['email_id'];
//`id`, `type`, `tempname`, `fromname`, `frommail`, `subject`, `description`, `status`
 $emaildata= mysqli_query($con,"SELECT * FROM `cat_template` where id='11'"); $subjdata=mysqli_fetch_array($emaildata);
    $fromid=$subjdata['frommail'];
//massagedata: massagedata 

$to = $Tomail;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="image/logo.png" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; '.$subjdata['fromname'].'</strong></p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Massage : '.$subjdata['description'].'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>User Name: &nbsp;'. $username.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Password: &nbsp;'. $password.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $contactemail.'</strong></p>
   <p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Domain Name: &nbsp;'. $domainname.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);


/*echo "<script>alert('Invoice Create')</script>";
		echo "<script>window.open('hostingpayment.php','_self')</script>";*/
		} 
		 
		 }
	 
?>
<?php  	  //echo "<h3 id='fail'>Payment Failed</h3>";
                    echo "<P>Transaction Status - InCompleted</P>";
                   // echo "<P>Transaction Id - " . $product_transaction . "</P>";
                   // echo "<div class='back_btn'><a  href='index.php' id= 'btn'><< Back</a></div>";
                
				}
				?>
 
                
  <tr style="">
    <td colspan="2">
    
    <table style="width: 100%; padding: 10px; margin: 20px 0px; text-align: center;">
  <tr style="line-height: 40px;">
    <th style="text-align:center">Transaction Date</th>
    <th style="text-align:center">Gateway</th> 
    
      <th style="text-align:center">Amount</th>
      <th style="text-align:center">Transaction Status</th>
  </tr>
  
  <tr style="line-height: 40px; background:#f9f9f9;">
    <td><?php echo date('d-m-Y');?></td>
    <td>Paypal</td>  
    <td><?php echo $total + $ttotal1.' '.$product_currency;?></td>
     <td><?php echo 'InCompleted';?></td>
  </tr>
   
</table>
    
    
    </td> 
  </tr>
  
  
</table>


<div class="row">
<div class="col-md-12">
<div class="button-secprint" style="float:right;">
<button class="btn btn-primary" onClick="myFunction()"> <i class="fa fa-print" aria-hidden="true"></i> Print</button>
<!--<button class="btn btn-default" id="cmd"><i class="fa fa-download" aria-hidden="true"></i> Download</button>-->
</div>
</div>
</div>
</div>
</div>
 
<script>
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
</script>

<style>
td, th {
    padding: 0;
    font-size: 17px;
}
</style>

<script>
function myFunction() {
    window.print();
}  
</script> 

</div>
</div> 
</div>

</section> 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end-------> 

  </body>
</html> 