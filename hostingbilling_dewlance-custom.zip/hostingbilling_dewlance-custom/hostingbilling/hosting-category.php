  <?php  session_start();  // error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
 <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>
  <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script>
$(document).ready(function() {
$(".Grouid").click(function(){
//   alert(); 
var element = $(this);
var updatename = element.attr("Gid");
 // alert(updatename);
 var don = $("#don").val(); 
 var prs = $("#prs").val(); 
 //alert(example1);
 var data = 'r=getmyvitaldetails1' + '&updatename=' + escape(updatename) + '&don=' + escape(don)+ '&prs=' + escape(prs);

  //alert(data); 
 $.ajax({
   type: "POST",
    url:'Webhotindata.php',
   data: data,
   success: function(data){   
  // alert(data); 
$("#WebhostingId").html(data);
 }
 
}); 
return false; 
});
});
</script>
<style>
.content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}
</style>
<script>
$(function() {
    $(".preload").fadeOut(2000, function() {
        $(".clientdashh").fadeIn(1000);        
    });
});
</script>
  </head>
  <body>
  <?php include_once('fn/connect.php'); include_once("header.php"); ?>
   
  
  <!--headerpart-end-->
  
<?
  /*  $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
    $query = "https://184.171.243.42:2087/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
     echo $result = curl_exec($curl);*/ 
?> 

<input type="hidden" id="don" value="<?php echo $_GET['don']; ?>">
<input type="hidden" id="prs" value="<?php echo $_GET['prs']; ?>">
<section class="clientdashh">
<div class="container">


<div class="row">

<div class="col-md-3">
<div class="hostcategr-sec">
<h4><i class="fa fa-cart-plus"></i>&nbsp; Categories</h4>
<ul class="hostgmenu">
<?php $queryProductG1 = mysqli_query($con,"SELECT * FROM `productgroupadd` ORDER BY `pgroupid` ASC LIMIT 1"); $ProducNameG1 = mysqli_fetch_array($queryProductG1); $pdata1=$ProducNameG1['pgroupid']; ?>
<li><a data-toggle="tab" href="#"><samp class="Grouid"Gid="<?php echo $ProducNameG1['pgroupid']; ?>"><?php  echo $ProducNameG1['producname']; ?></samp></a></li>

<!--<li><a data-toggle="tab" href="#webhost2">Web Hosting (UK)</a></li>--> 
<?php $queryProductG = mysqli_query($con,"SELECT * FROM `productgroupadd` ORDER BY `pgroupid` ASC LIMIT 1,10"); while($ProducNameG = mysqli_fetch_array($queryProductG)){ $pdata=$ProducNameG['pgroupid'];?>

<li><a data-toggle="tab" href="#"><samp class="Grouid"Gid="<?php echo $ProducNameG['pgroupid']; ?>"><?php  echo $ProducNameG['producname']; ?></samp></a></li>
 
 <?php } ?>
</ul>


</div>
</div>

<div class="col-md-9">

<div class="tab-content">
<div id="WebhostingId">
<div id="webhost1" class="tab-pane fade in active">
<div class="hosting_detailss">

<h3><?php  echo $ProducNameG1['producname']; ?></h3>

<?php $querc11=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc11=mysqli_fetch_array($querc11); $stval1=$rowc11['ipnumber']; ?>

<ul class="hostdom_list">
<?php
//`producid`, `modulid`, `groupid`, `decrip`, `pemail`, `rdomailn`, `pricetype`, `price`, `billtype`, `adddate`, `status`
$getpro=$_GET['1p'];
if(isset($_GET['1p'])){
 $queryProduc = mysqli_query($con,"SELECT * FROM `productadd` where groupid='$pdata1' && modulid='$getpro'"); 
 }else{
 $queryProduc = mysqli_query($con,"SELECT * FROM `productadd` where groupid='$pdata1'");  
 }
 while($ProducName = mysqli_fetch_array($queryProduc)){ 
 ?>

<li>
<h4><?php echo $uds= $ProducName['modulid']; ?> - Supercheap</h4>
<div class="about-domain">
<div class="row">
<div class="col-sm-8">
 <?
    $user = "root";
    $token = $rowc11['apikdy'];
 
    $query = "https://$stval1/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
       $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            if($userdetails->{'name'} == $uds){
?>  
<h5><?php echo  $userdetails->{'name'} ;?></h5>
<h5>Disk Space- <span><?php echo  $userdetails->{'QUOTA'} ;?> MB</span></h5>

<h5>Bandwidth- <span><?php echo  $userdetails->{'BWLIMIT'} ;?> MB per month</span></h5>

<h5>Cpanel & Softaculous</h5> 
<h5>Setup - <span><?php echo  $ProducName['billtype']; ?></span></h5>

<h5><?php echo  $ProducName['decrip']; ?></h5>
<!--<h5>100% FTP Email and Mysql accounts</h5>-->

<!--<h5><strong><?php echo  $ProducName['decrip']; $_SESSION["num"]='1'; ?></strong></h5>
--><!--<h5>Server Location</h5>
--> 
</div>
 
<div class="col-sm-4">
<div class="ordersect">
<h3>&dollar; <?php echo $ProducName['price']; ?>.00 USD</h3>
<h6><?php echo $ProducName['billtype']; ?></h6>
<a href="orderreviews.php?1=<?php echo base64_encode($userdetails->{'name'}) ?>&did=<?php echo base64_encode( $ProducName['producid']) ?>&prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>&bill=<?php echo  $ProducName['billtype']; ?>"><button class="btn btn-success btn-xs"><i class="fa fa-cart-plus"></i> Order Now</button></a>
</div> 
</div>
</div>

</div>

</li>
  <?php }         }
    }
 }
    curl_close($curl); 
?> 
 
</ul>

</div>
</div>
</div>
 

</div>
 
</div>
 
</div>

 
</div>

</section> 
 <!--home--contant----end---> 
  
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>