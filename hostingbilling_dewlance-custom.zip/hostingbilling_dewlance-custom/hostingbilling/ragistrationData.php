<?php  session_start();
include_once('fn/connect.php'); date_default_timezone_set("asia/kolkata");
 
//'First='+ First + '&Last='+ Last + '&Compony='+ Compony + '&Email='+ Email + '&Password='+ Password + '&country='+ country + '&state='+ state + '&city='+ city + '&Mobile='+ Mobile + '&Pin='+ Pin + '&Address='+ Address

if(isset($_POST['First'])){
$First = $_POST['First']; 
$Last = $_POST['Last']; 
$Compony = $_POST['Compony']; 
$Email = $_POST['Email'];
 $str=$_POST['Password'];
$Password = md5($str);
$country = $_POST['country']; 
$state = $_POST['state']; 
$city = $_POST['city']; 
$Mobile = $_POST['Mobile']; 
$Pin = $_POST['Pin']; 
$Address = $_POST['Address'];  
 $ragdate = date('d-m-Y');
			$insert_query = "INSERT INTO `user_ragistration` (`fname`, `lname`, `cmpname`, `email_id`, `userpass`, `add`, `contryid`, `stateid`, `cityid`, `pin`, `mobile`, `status`, `ragdate`) VALUES ('$First', '$Last', '$Compony','$Email', '$Password', '$Address', '$country', '$state', '$city', '$Pin', '$Mobile', '0','$ragdate')";
	 //VALUES ('$First', '$Last', '$Compony','$Email', '$Password', '$Address', '$country', '$state', '$city', '$Pin', '$Mobile', '0','$ragdate')";
		$run = mysqli_query($con,$insert_query);
		if($run) {
		echo "Ragistration sucsessfully created"; 
	  $_SESSION['EmailIdSession'] = $Email;
	$_SESSION['userpassSession'] = $Password;
	 $_SESSION['fnamess'] = $First;
	 $dsjfl= mysqli_query($con,"SELECT * FROM `user_ragistration` ORDER BY `user_ragistration`.`id` DESC LIMIT 1"); $fslj = mysqli_fetch_array($dsjfl); 
	  $_SESSION['userid'] = $fslj['id'];  
  $ip = $_SERVER['REMOTE_ADDR'];
$run = mysqli_query($con,"INSERT INTO `audit_loginuser` (`subscriber_name`, `action_performed`,`ip`, `date_added`) VALUES ('$First','Ragistration', '$ip', '$ragdate')");
 
 
//`id`, `type`, `tempname`, `fromname`, `frommail`, `subject`, `description`, `status`
 $emaildata= mysqli_query($con,"SELECT * FROM `cat_template` where id='10'"); $subjdata=mysqli_fetch_array($emaildata);
    $fromid=$subjdata['frommail'];
 
$to = $Email;
$subject = subjdata['subject'];
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="images/'.$rowdata['urlink'].'" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "><strong>From : &nbsp; '.$subjdata['fromname'].'</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear : '.$First.' '.$Last.'</p> 
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Massage : '.$subjdata['description'].'</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Email Id is : '.$Email.'</p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Mobile No is : '.$Mobile.'</p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Password : '.$Password.'</p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Address : '.$Address.'</p>
 
 </div>

</body>
</html>
'; 

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From:'.$fromid."\r\n";
$headers .= 'Cc:'.$fromid."\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers); 
		}} 
 ?>
 
 
 
 <?php   
 if(isset($_POST['loginemail'])){
$uName = $_POST['loginemail'];
$pWord = md5($_POST['loginpwd']);
$datime=date('d-m-Y h:i:s a');
$qry = "SELECT * FROM user_ragistration WHERE email_id='".$uName."' AND userpass='".$pWord."' AND status='0'"; 
$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);
if( $num_row == 1 ) {
//INSERT INTO `audit_loginuser`(`id`, `subscriber_name`, `action_performed`, `date_added`)
$nad=$row['fname'];
  $ip = $_SERVER['REMOTE_ADDR'];
$run = mysqli_query($con,"INSERT INTO `audit_loginuser` (`subscriber_name`, `action_performed`,`ip`, `date_added`) VALUES ('$nad','Login', '$ip', '$datime')");
	echo 'sucsessfully Login';
	$_SESSION['EmailIdSession'] = $uName;
	$_SESSION['userpassSession'] = $pWord;
	$_SESSION['fnamess'] = $row['fname'];
	$_SESSION['userid'] = $row['id'];
	}
else {
	echo 'false';
}}
   ?>