  <?php   session_start();   error_reporting(0); //if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script> 
     <script>function SubmitDomain() {
    var name = $("#Domainnamed").val(); 
	var domains = $("#domains").val();
    $.post("domaintest.php", { name: name,domains: domains  },
    function(data) {
	 $('#resultsdd').html(data);
	 $('#myFormdd')[0].reset();
    });
}</script>
  </head>
  <body>
  
  <?php include_once('header.php'); ?>
  
  <!--headerpart-end-->
  
 <section class="searchsec">
 <div class="container">
 <div class="row">
 
 <div class="col-md-offset-3 col-md-6 col-md-offset-3">
 
 <h3 style="margin-bottom:10px;">Search Domain Name</h3>
 <div class="input_group1">
  <form action="" method="post">
<table class="table">
<tr>
<!--<td class="domntext"> Enter Domain Name : &nbsp;</td>-->
<td><input type="text" class="form-control srchflddd" name="Domainnamed" id="Domainnamed" placeholder="eg. example.com"></td>
<td>
<select class="form-control srchflddd" id="domains" name="domains"><option value="">.Domain</option> 
<?php $queryPrice = mysqli_query($con,"SELECT * FROM `priceadd`"); while($rowprice = mysqli_fetch_array($queryPrice)){ ?>
<option  value="<?php echo $rowprice['domainname']; ?>"><?php echo $rowprice['domainname']; ?></option> 
 <?php }?>
</select>
 
</td>
<td align="right"> <span class="input-group-addon srchflbtn"><button type="button" onClick="SubmitDomain();"> Search </button></span></td>  
</tr>
</table><br>
 <h1 id="resultsdd"></h1> 
  
</form> 
</div>
 
 </div> 
 </div>
 </div>
 </section> 
 
 <!---search----section-----end--
 
 <script>setTimeout(function() {
    $('#mydiv').fadeOut('fast');
}, 25000); </script>---> <br>
  <?php session_start(); if( (isset($_SESSION['EmailIdSession'])) && (isset($_SESSION['userpassSession']))){  ?>
 
 <section class="hostingmenu">
 <div class="container">
 <div class="hostingitem">
 <ul>
 <li>
 <h4>Client Area</h4> 
 <div class="iconhead">
 <i class="fa fa-home"></i>
 <p>View & update your account details</p>
 </div>
 
<a href="#"> <button class="hbtn">GO TO CLIENT AREA</button></a> 
 </li>
 <li>
 <h4>Submit Ticket</h4> 
 <div class="iconhead">
 <i class="fa fa-ticket"></i>
 <p>Submit a trouble ticket</p>
 </div>
 
<a href="#"> <button class="hbtn">SUBMIT TICKET</button></a>
 
 </li>
 <li>
 <h4>Check Existing Ticket</h4>
 
 <div class="iconhead">
 <i class="fa fa-thumb-tack"></i>
 <p>View & respond to existing ticket</p>
 </div>
 
<a href="#"> <button class="hbtn">EXISTING TICKET</button></a>
 
 </li>
 <li>
 <h4>Knowledgebase</h4>
 
 <div class="iconhead">
 <i class="fa fa-search"></i>
 <p>Browse our KB for answer to FAQs</p>
 </div>
 
<a href="#"> <button class="hbtn">KNOWLEDGEBASE</button></a>
 
 </li>
  <li>
 <h4>Domain Checker</h4>
 
 <div class="iconhead">
 <i class="fa fa-flag-checkered"></i>
 <p>Check or Register Domain</p>
 </div> 
<a href="#"> <button class="hbtn">DOMAIN</button></a> 
 </li>
 <li>
 <h4>Order</h4> 
 <div class="iconhead">
 <i class="fa fa-first-order"></i>
 <p>Place a new order with us</p>
 </div> 
<a href="#"> <button class="hbtn">PLACE AN ORDER</button></a> 
 </li>
 <li>
 <h4>Buy Hosting</h4>
 
 <div class="iconhead">
<i class="fa fa-cart-arrow-down"></i>
 <p>View & update your account details</p>
 </div> 
<a href="#"> <button class="hbtn">BUY HOSTING</button></a> 
 </li>
 <li>
 <h4>Pre - Sale Contact</h4>
 
 <div class="iconhead">
<i class="fa fa-comments-o"></i>
 <p>View & update your account details</p>
 </div> 
<a href="#"> <button class="hbtn">CONTACT</button></a> 
 </li>
 </ul> 
 </div> 
 <div class="latestannounce">
 <h3>Latest Announcements</h3>
 <h5>23/03/2017 <span>We no longer accept skill</span></h5>
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
 
  <h5>23/03/2017 <span>We no longer accept skill</span></h5>
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
  </div> 
 </div>
 </section>
 
 <?php  } else{?>
 <section class="hostingmenu">
 <div class="container">
 <div class="hostingitem">
 <ul>
 <li>
 <h4>Client Area </h4> 
 <div class="iconhead">
 <i class="fa fa-home"></i>
 <p>View & update your account details</p>
 </div>
 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">GO TO CLIENT AREA</button></a> 
 </li>
 <li>
 <h4>Submit Ticket</h4> 
 <div class="iconhead">
 <i class="fa fa-ticket"></i>
 <p>Submit a trouble ticket</p>
 </div>
 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">SUBMIT TICKET</button></a>
 
 </li>
 <li>
 <h4>Check Existing Ticket</h4>
 
 <div class="iconhead">
 <i class="fa fa-thumb-tack"></i>
 <p>View & respond to existing ticket</p>
 </div>
 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">EXISTING TICKET</button></a>
 
 </li>
 <li>
 <h4>Knowledgebase</h4>
 
 <div class="iconhead">
 <i class="fa fa-search"></i>
 <p>Browse our KB for answer to FAQs</p>
 </div>
 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">KNOWLEDGEBASE</button></a>
 
 </li>
  <li>
 <h4>Domain Checker</h4>
 
 <div class="iconhead">
 <i class="fa fa-flag-checkered"></i>
 <p>Check or Register Domain</p>
 </div> 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">DOMAIN</button></a> 
 </li>
 <li>
 <h4>Order</h4> 
 <div class="iconhead">
 <i class="fa fa-first-order"></i>
 <p>Place a new order with us</p>
 </div> 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">PLACE AN ORDER</button></a> 
 </li>
 <li>
 <h4>Buy Hosting</h4>
 
 <div class="iconhead">
<i class="fa fa-cart-arrow-down"></i>
 <p>View & update your account details</p>
 </div> 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">BUY HOSTING</button></a> 
 </li>
 <li>
 <h4>Pre - Sale Contact</h4>
 
 <div class="iconhead">
<i class="fa fa-comments-o"></i>
 <p>View & update your account details</p>
 </div> 
<a href="#" data-toggle="modal" data-target="#loginmodel"> <button class="hbtn">CONTACT</button></a> 
 </li>
 </ul> 
 </div> 
 <div class="latestannounce">
 <h3>Latest Announcements</h3>
 <h5>23/03/2017 <span>We no longer accept skill</span></h5>
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
 
  <h5>23/03/2017 <span>We no longer accept skill</span></h5>
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
  </div> 
 </div>
 </section>
  <?php  }?>
 <!--home--contant----end--->
 <?php include_once('footer.php'); ?> 
 
 <!----------footer---end------->
 
  
 
  </body>
</html>