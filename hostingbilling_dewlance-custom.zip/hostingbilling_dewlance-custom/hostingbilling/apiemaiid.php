<?php include_once('fn/connect.php');  //Product: Product, Domain: Domain, cpuser: cpuser, Billing: Billing ?>
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; 

////<!-----------------------1--------Creat User in cPenal process-------------------------------------->

 if(isset ($_POST['unsusname'])){ 
 $unsusname = $_POST['unsusname'];
 $oldpass = $_POST['oldpass'];
 $newpass = $_POST['newpass'];
   $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/cpanel?cpanel_jsonapi_user=user&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=Passwd&cpanel_jsonapi_func=change_password&oldpass=$oldpass&newpass=$newpass&user=$unsusname";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
        echo "User Unsuspend";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
} ?>



<?php   //emailName: emailName, domainname: domainname, validepass: validepass , cpaneluserName
  if(isset($_POST['emailName'])){ 
       $emailid = $_POST['emailName'];
    $domainname = $_POST['domainname'];
    $validepass = $_POST['validepass'];
	$cpaneluserName = $_POST['cpaneluserName'];
   $user = "root";
     $token = $rowc['apikdy']; 
  $query ="https://$stval/json-api/cpanel?cpanel_jsonapi_user=$cpaneluserName&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=Email&cpanel_jsonapi_func=addpop&domain=$domainname&email=$emailid&password=$validepass&quota=500";
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
          $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		 // print_r($json);
        echo "Your Email id Succussfully created"; 
	
	}  
 }
  curl_close($curl);  
?>
<?
   /* $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
     $query = "https://167.160.174.209:2087/json-api/cpanel?cpanel_jsonapi_user=superadmin&cpanel_jsonapi_apiversion=1&cpanel_jsonapi_module=admin&cpanel_jsonapi_func=admin&oldpass=admin&newpass=admin&user=superadmin@123.com";
  
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query); 
        $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		  print_r($json);
        echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'acct'} as $userdetails) { ?> 
  <tr>
    <td><?php echo $userdetails->{'uid'}; ?></td>
    <td><?php echo $userdetails->{'user'}; ?></td>
    <td><?php echo $userdetails->{'domain'}; ?></td>
    <td><?php echo $userdetails->{'email'}; ?></td>
  </tr> 
	<?php	if($userdetails->{'uid'} == 1002){
		echo "\t" . $userdetails->{'user'} . "\n";
		}
            
			
        }
    }
 
    curl_close($curl); */
?>