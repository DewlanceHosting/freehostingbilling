 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata");  ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Existing Ticket</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Ticket Department</th>
      <th>Ticket Number</th>
      <th>Subject</th>
       <th>Last Reply</th>
       <th>Status</th>
    </tr>
  </thead>
  <tbody>
  <?php $querydata=mysqli_query($con,"SELECT * FROM `ticket_sale`"); while($rowquery=mysqli_fetch_array($querydata)){ 
  
  $dbdatetime =  $rowquery['cdatetime']; 
 
  //$curdatetime = date($dbdatetime);  
$date1 = new DateTime("$dbdatetime");
$date2 = new DateTime("now");
$diff = $date1->diff($date2);
// 38 minutes to go [number is variable]
   $minutes=( ($diff->days * 24 ) *60 )/60 + ( $diff->i) . ' minutes';
// passed means if its negative and to go means if its positive
 // ($diff->invert == 1 ) ? ' passed ' : ' to go ';
  ?>
    <tr>
      <td><?php echo $rowquery['depname']; ?></td>
      <td><h4><?php echo $rowquery['ticketnumber']; ?></h4></td>
      <td><h4><?php echo $rowquery['subjec']; ?></h4></td>
       <td><?php echo $hours = floor($minutes / 24).' Day : '.floor($minutes / 60).' hours : '.($minutes -   floor($minutes / 60) * 60) . ' minutes'; echo ($diff->invert == 1 ) ? ' passed ' : ' to go ';?></td>
       <?php if($rowquery['closeticket'] == '0'){  ?>
       <td>Open</td>
       <?php }else{?>
       <td>Not Open</td>
       <?php }?>
    </tr>
<?php }?>

<?php
 ?>
<!--    <tr>
      <td>$ support.department</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>10 Minute Ago</td>
       <td>Answered</td>
    </tr>
    <tr>
      <td>General</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>2 Day Ago</td>
       <td>Closed</td>
    </tr>
        <tr>
      <td>Sales</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>1 Minute Ago</td>
       <td>Open</td>
    </tr>
    <tr>
      <td>$ support.department</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>10 Minute Ago</td>
       <td>Answered</td>
    </tr>
    <tr>
      <td>General</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>2 Day Ago</td>
       <td>Closed</td>
    </tr>
        <tr>
      <td>General</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>2 Day Ago</td>
       <td>Closed</td>
    </tr>
        <tr>
      <td>Sales</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>1 Minute Ago</td>
       <td>Open</td>
    </tr>
    <tr>
      <td>$ support.department</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>10 Minute Ago</td>
       <td>Answered</td>
    </tr>
    <tr>
      <td>General</td>
      <td><h4>AX-XXXX</h4></td>
      <td><h4>Ticket Title</h4></td>
       <td>2 Day Ago</td>
       <td>Closed</td>
    </tr>-->
    
    
  </tbody>
</table>
</div>

</div>





</div>

</section>


 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>