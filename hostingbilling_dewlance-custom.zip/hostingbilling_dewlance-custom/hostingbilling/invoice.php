 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
	 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.3.min.js">	</script> 
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
	</script>
	 
	<script type="text/javascript" language="javascript" class="init">
	
$(document).ready(function() {
	$('#example').DataTable( {
		"order": [[ 0, "desc" ]]
	} );
} );

	</script>    
  </head>
  <body>
  
    <?php include_once("header.php"); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>Invoice</h3>
<div class="table-responsive"> 

<table id="example" class="display" cellspacing="0" width="100%">
				<thead>
					<tr>
      <th>Invoice Number</th>
      <th>Invoice Date</th>
      <th>Due Date</th>
       <th>Invoice Amount</th>
       <th>Invoice Status</th>
       <th>View Invoice</th>
    </tr>
				</thead>
				 
				<tbody>
   <!--  `id`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`-->
  <?php   $usid=$_SESSION['userid']; $query = mysqli_query($con,"SELECT * FROM `user_hostingpay` where user_rid='$usid'"); while($rowdata=mysqli_fetch_array($query)){
   $date1=$rowdata['transectiondate'];  
   $date=date_create($date1); date_add($date,date_interval_create_from_date_string("180 days"));
 $tiondate=date_format($date,"d-m-Y"); ?>
    <tr>
      <td> <h4><?php echo $rowdata['oderid']; ?></h4></td>
      
      <td><?php echo $rowdata['transectiondate']; ?></td> 
 
     <td><?php if($rowdata['nexduedate'] == '0'){?> 
  
 <strong> Pending </strong>   
<?php } else{?>

<p><strong><?php echo $rowdata['nexduedate']; ?></strong></p> 

 <?php } ?></td> 
       
       <?php if($rowdata['total'] == '0'){?>
   <td>&dollar; <?php echo $rowdata['total']; ?></td>
<?php } else{?>
<td><?php echo "0:00"; ?></td> 
 <?php } ?>
 
        <?php if($rowdata['status'] == '0'){?>
  <td>Unpaid</td>
<?php } else{?>
<td><span style="color:#FF0000">Paid</span></td> 
 <?php } ?>
 
       <td><a href="#"><h4>View</h4></a></td>
    </tr>
     
     <?php } ?>
     
         
     
   <!-- <tr>
      <td> <h4>AX-XXXXX</h4></td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td>$XXX</td>
       <td><span style="color:#FF0000">Unpaid</span></td>
       <td><a href="#"><h4>View</h4></a></td>
    </tr>
    <tr>
      <td> <h4>AX-XXXXX</h4></td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
       <td>$XXX</td>
       <td>Paid</td>
       <td><a href="#"><h4>View</h4></a></td>
    </tr>-->
    
  </tbody>
			</table>



</div>

</div>





</div>

</section>


 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>