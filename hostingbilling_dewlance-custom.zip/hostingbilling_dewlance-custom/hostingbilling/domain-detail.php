 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css"> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php");  ?>
  
  <!--headerpart-end--> 

<div class="container">

<div class="listservisdata">
<h3 class="headdoman">My Domain Detail</h3>

<div class="domnpager">
<ul class="breadcrumb">
  <li><a href="mydomain.php">My Domains</a></li>
  <li class="active">Domain Details</li> 
</ul>

</div> 
<?php   $domaidata=base64_decode($_GET['1']);
//`id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`, `domainstatus`, `ordercancel`
 $queryrdata = mysqli_query($con,"SELECT * FROM `user_domainpay` where domain_name='$domaidata'"); $rowdata=mysqli_fetch_array($queryrdata);
?>
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Overview</h3>
<p>This domain is not currently active. Domain cannot be managed unless active.</p>

<div class="categry">
<ul>
 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Domain</h4>
<br />
<p><strong><?php echo $rowdata['domain_name']; ?></strong></p>
</a>
</li> 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; First Payment Amount</h4>
<br />
<p><strong>$ <?php echo $rowdata['total']; ?></strong></p>
</a>
</li>
 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Registration Date</h4>
<br />
<p><strong><?php echo $rowdata['transectiondate']; ?></strong></p>
</a>
</li> 
<!--<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Recurring Amount</h4>
<br />
<p><strong>$ 9.49 <?php echo $rowdata['domain_name']; ?> 1 year/s</strong></p>
</a>
</li>--> 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Next Due Date</h4>
<br />
<p><strong> <?php if($rowdata['status'] == '0'){?> 
  
 <strong> Pending </strong>   
<?php } else{?>

<p><strong><?php echo $rowdata['transectiondate']; ?></strong></p> 

 <?php } ?></strong></p>
</a>
</li> 

<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Payment Method</h4>
<br />
<p><strong><?php echo $rowdata['paymethod']; ?></strong></p>
</a>
</li> 
<li>
<a href="javascript:void(0)">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; Status </h4>
<br />
 <?php if($rowdata['status'] == '0'){?>  
 <strong> Pending </strong>   
<?php } else{?>

<strong>  Active</strong>  

 <?php } ?>
</a>
</li> 
</ul>
</div> 
</div>
</div>
</div> 
</div> 
</div> 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>