$(document).ready(function() {

	//alert("gg");
var URLHD = location.protocol + "//" + document.domain + "/" + location.pathname.split('/')[1] + "/";
	//alert(URLHD);
	var URL_PHT = URLHD+ 'admin' + '/';
	var URLs = URLHD + 'admin' + '/' + 'data.php';
	//alert(URLs);
//alert(URL_PHT);




$('#Lsubmit').click(function () {
//alert();
      var username = $('#txtloginName').val();
      var password = $('#txtpassword').val();

if( username == ''){

	 $('.error_msg').html('Please Enter The Username').show().delay(2800).fadeOut();

	 $('#txtloginName').focus();

	  return false;

	}

	   if( password == ''){

	  $('.error_msg').html('Please Enter The Password').show().delay(2800).fadeOut();

	   $('#txtpassword').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=logins' + '&username=' + escape(username) + '&password=' + escape(password); // this where i add multiple data using  ' & '

		//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs, 

        data:data,    // multiple data sent using ajax

        success: function(html) {
//alert(html);
		if(html != '111'){

		$('.error_msg').html(html).show().delay(2000).fadeOut();
			//alert();
		}

		if(html == '111'){

		$('.successmsg').html('Login Success').show().delay(2000).fadeOut();

		  window.location = 'home.php';

	   $('#txtloginName').val('');

	   $('#txtpassword').val('');

		}

        }

      });

      return false;

    });


	

	// for change city to Zone

	

	$('#CitySelec').on('change', function() {

      var ProductCatId = $('#CitySelec').val();

	//alert(ProductCatId);    

	   if( ProductCatId == '0' || ProductCatId == ''){

	  $('#dataShowcat').slideUp().hide();
				//alert();
			$('#LocSelec').slideUp().hide();
$('#AreaProNew').slideUp().hide();
	   	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=ChangeCatTo' + '&ProductCatId=' + escape(ProductCatId); // this where i add multiple data using  ' & '

	 	//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function (html) {

		//alert(html);

	

		$('#dataShowcat').html(html).slideDown().show();

			$('#LocSelec').hide();
        $('#AreaProNew').hide();
		

		if(html == 'failed'){

		$('#dataShowcat').hide();

		//	$('#LocSelec').show();

		}


        }

      });

      return false;

    });


	

	$('#catproNamed').on('change', function() {

      var ProductCatIds = $('#catproNamed').val();

	  // alert(ProductCatIds);

	   if( ProductCatIds == '0'){

	 $('.contantFcaR').hide();

	 $('.contantFcaRDTTl').show();

	   	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=HideSpecialFCH' + '&ProductCatIds=' + escape(ProductCatIds); // this where i add multiple data using  ' & '

	 	//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function (html) {

		//alert(html);

	

		if(html == '1111'){

		//$('#dataShowcat').hide();

			$('.contantFcaR').show();

			$('.contantFcaRDTTl').hide();

		}

		

		 if(html != '1111'){

		//$('#dataShowcat').hide();

			$('.contantFcaR').hide();

			$('.contantFcaRDTTl').show();

		}

         

         

        }

      });

      return false;

    });

 

	

	 $("#AreaPin").keypress(function (e) {

     //if the letter is not digit then display error and don't type anything

	var tempVal = $('#AreaPin').val();

	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {

        //display error message

       // $("#errmsgZip").html("Digits Only").show().delay(1800).fadeOut("slow");

               return false;

    }

	

   });	

	 

	  $("#PriceBusin").keypress(function (e) {

     //if the letter is not digit then display error and don't type anything

	var tempVal = $('#txtMonthly').val();

	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {

        //display error message

       // $("#errmsgZip").html("Digits Only").show().delay(1800).fadeOut("slow");

               return false;

    }

	

   });	



   $( document ).on( 'focus', ':input', function(){

        $( this ).attr( 'autocomplete', 'off' );

    });


/*delete Business in Prixcom*/
 $(".DelBusiness").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteBusinessDevd' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 
 
 /*delete Business in Prixcom*/
 $(".DelOfferImg").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=DeleteOfferImg' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 
 
/*delete Business in Prixcom*/
 $(".DelGiftImage").click(function(){
var element = $(this);
var del_id = element.attr("id");
// alert(del_id);
 var data = 'r=deletegiftImage' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(html){
	  // alert(html);
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 /*delete Business in Prixcom*/
 $(".DelBusinessimg").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteBusinessimgh' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
	  window.location = 'view_banerimg.php';
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});

/*delete city in Prixcom*/
 $(".delbutton").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deletecat' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 /*delete blogpost*/
 $(".delBlPost").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteBLP' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
  /*delete locality in city*/
 $(".delLocality").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteInsGp' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 
/*delete area in locality*/
 $(".delArea").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteSubcat' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 /*delete Blog-category*/
 $(".DelCategory").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteBlogCat' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 /*delete category*/
 $(".delCategory").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteSubcatdf' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});

 /*delete Testimonial here*/
 $(".deltestimonial").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=testimonialdlt' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#subdel-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});

//for changing the status of testimonial
    $('.TestimonialChange').click(function () {
//alert();
       var GameId = $(this).data('relq');
   var data = 'r=testimonialstatus' + '&GameId=' + escape(GameId);
  // alert(data);
       $.ajax({
       type:"post",
       cache:false,
       url:URLs,
       data:data,    // multiple data sent using ajax
   statusCode: {
              404: function() {
                  alert("page not found");
              }
       },
       success: function(html) {
// alert(html);
$("#myDiv"+GameId).show().html(html).hide().fadeIn(600);
//
   //  alert(UrlPaths);
}
     });
     return false;
});
  
 
    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });
	

// city on change function


  
 
    $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });
	
 

 // for  insert zone in city

	 $('#LocaSubmit').click(function () {  

	 // alert('vsae');						 

     // var HDNSubcatID = $('#HDNSubcatID').val();
		var CitySelec = $('#CitySelec').val();  // onchange city id from data
	  	var localityName = $('#localityName').val();
	 
//alert(txtCTYnaPHT);

if( CitySelec == ''){

  $('#CitySelec').focus();

	  return false;

	}

	 if( localityName == ''){

  $('#localityName').focus();

	  return false;

	}
      // alert(data);'code=' + code + '&userid=' + userid

	var data = 'r=insertadd_ons' + '&CitySelec=' + escape(CitySelec) + '&localityName=' + escape(localityName) ; // this where i add multiple data using  ' & '

	// alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
        success: function(html) {

	  // alert(html);
	  $('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		$('.successmsg').html('Zone Added Successfully in city.').show().delay(3000).fadeOut();
		$('#CitySelec').val('');
	   $('#localityName').val('');
		
	 	if(html == 'failed'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.error_msg').html('Zone not inserted in City. Please try again.. ').show().delay(3000).fadeOut();

		}

        }

      });

      return false;

    });
	 
	 
	 
	 
	 
	 // For Changing the password of super admin here 
   
$('#ChangePasAdmin').click(function () {
 var Usename = $('#txtUsename').val();
 var CurrentPassword = $('#txtCrPassword').val();
  var NewPassword = $('#txtNewPassword').val();
   var confPassword = $('#txtconfPassword').val();
   
 if( Usename == ''){
	 $('#txtUsename').focus();
	 return false;
 }
 
 if( Usename == 'undefined'){
 return false;
 }
 
  if( CurrentPassword == ''){
	 $('#txtCrPassword').focus();
	 return false;
 }
   if( NewPassword == ''){
	 $('#txtNewPassword').focus();
	 return false;
 }
   if( confPassword == ''){
	 $('#txtconfPassword').focus();
	 return false;
 }
 
 	if( NewPassword != confPassword){
	 document.getElementById('txtconfPassword').focus(); //$('#signup-password').focus();
	 $('#txtNewPassword').focus();
	 return false;
	 }

    $("#LOderImgId").show();

 document.getElementById('ChangePasAdmin').value="Please Wait..";
//document.getElementById('ChangePasword').disabled=true;

var data = 'r=ChangeADpass' + '&Usename=' + escape(Usename) + '&CurrentPassword=' + escape(CurrentPassword) + '&NewPassword=' + escape(NewPassword); // this where i add multiple data using  ' & '
  //alert(data);
      $.ajax({
        type:"post",
        cache:false,
        url:URLs,
        data:data,    // multiple data sent using ajax
        success: function(html) {
	  	//alert(html);
	 	if(html == 'failed'){
	 		  $("#LOderImgId").hide();
       	   $(".errormsg2").show();
		   document.getElementById('ChangePasAdmin').value="Submit";
	   	   $('.error_msg').html('Password not Changed Successfully').show().delay(3000).fadeOut();
		    $('#ChangePasAdmin').removeAttr("disabled");	
		}
		
 if(html == 'NotPass'){
       	   $(".errormsg2").show();
       	    $('#txtCrPassword').focus();
       	     $("#LOderImgId").hide();
		   document.getElementById('ChangePasAdmin').value="Submit";
	   	   $('.error_msg').html('Incorrect Current Password ').show().delay(3000).fadeOut();
		    $('#ChangePasAdmin').removeAttr("disabled");	
		}
		if(html == 'success'){
		   $("#LOderImgId").hide();
		   $(".Success").html('Password Changed Successfully').show().delay(3000).fadeOut();
	   	   $('#txtNewPassword').val('');
	   	     $('#txtconfPassword').val('');
	   	   document.getElementById('ChangePasAdmin').value="Submit";
		    $('#ChangePasAdmin').removeAttr("disabled");	
			  window.location = 'home.php';
		}
  		}
  });
  return false;
});

 
 
  // for  insert business

	 $('#AddBusiness').click(function () {  

	 //alert('vsae');						 
		var BusinessName = $('#BusinessName').val();  // onchange city id from data
		var BusinessownerName = $('#BusinessownerName').val();
		var CategoryPro = $( "#CategoryPro option:selected" ).val();
	//  	var CategoryPro = $('#CategoryPro').val();
	//alert(CategoryPro);
		var city = $('#CitySelec option:selected').val();
		var Locality = $('#sltLocalityCatDyn option:selected').val();
		var area = $('#AreaProNew option:selected').val();
		var price = $('#PriceBusin').val();
		var address = $('#packNamePro1').val();
		var detail = $('#PostDetail').val();
		var email = $('#email').val();
		var password = $('#bsnpsw').val();
		var cpass = $('#cnfpsw').val();
			var Mobilen = $('#Mobilen').val();
//alert(detail);

if( BusinessName == ''){

  $('#BusinessName').focus();

	  return false;

	}
	
	if( BusinessownerName == ''){

  $('#BusinessownerName').focus();

	  return false;

	}

	 if( CategoryPro == '' || CategoryPro == '0'){
  $('#CategoryPro').focus();
	  return false;
	}
 if( city == '' || city == '0'){
  $('#CitySelec').focus();
	  return false;
	}
	 if( Locality == '' || Locality == '0'){
  $('#sltLocalityCatDyn').focus();
	  return false;
	}	
	 if( area == '' || area == '0'){
  $('#AreaProNew').focus();
	  return false;
	}
	
	
	 if( address == ''){

  $('#packNamePro1').focus();

	  return false;

	}
	
	 if( price == ''){
  $('#PriceBusin').focus();
	  return false;
	}
	
	 if( Mobilen == ''){
  $('#Mobilen').focus();
	  return false;
	}
	
	
	if( email == ''){
  $('#email').focus();
	  return false;
	}
	var filter = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
	if (!email.match(filter)) {
    alert('Please provide a valid email address');
   $('#email').focus();
    return false;
 }
 
  if( password == ''){
  $('#bsnpsw').focus();
	  return false;
	}
	 if( cpass == ''){
  $('#cnfpsw').focus();
	  return false;
	}
	var passw=  /^[A-Za-z]\w{5,14}$/;
	if (!password.match(passw)) {
    alert('Please enter 7-14 with atleast one lowercase, one uppercase letter.');
   $('#bsnpsw').focus();
    return false;
 }
	if (password != cpass) {
		alert('Password do not match.');
		$('#bsnpsw').focus();
	  return false;
		
		}
 
 
	
      // alert(data);'code=' + code + '&userid=' + userid

	var data = 'r=insertBusiness' + '&BusinessName=' + escape(BusinessName) + '&BusinessownerName=' + escape(BusinessownerName) + 
	'&password=' + escape(password) + '&email=' + escape(email) + '&Mobilen=' + escape(Mobilen) + '&CategoryPro=' + escape(CategoryPro) + '&city=' + escape(city) + 
	'&Locality=' + escape(Locality) + '&area=' + escape(area) + '&price=' + escape(price) + '&address=' + escape(address) + 
	'&detail=' + escape(detail) ; // this where i add multiple data using  ' & '

	alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
        success: function(html) {

	  alert(html);
	  
	  $('.dsfsd').html(html);
	  $('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		$('.success').html('Business inserted Successfully.').show().delay(3000).fadeOut();
		
		window.location.href = URL_PHT+'add_bussiness.php?PHTid='+html;
		
		$('#BusinessName').val('');
		
		$('#PriceBusin').val('');
		$('#packNamePro1').val('');
		$('#PostDetail').val('');
		
	 	if(html == 'failed'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.failure').html('Business not inserted . Please try again.. ').show().delay(3000).fadeOut();

		}

        }

      });

      return false;

    });
 

 
 // for  insert city in prixcom

	 $('#catSubmit').click(function () {

	// alert();
	  var cityName = $('#cityName').val();

	// alert(ContinentSel);
	  
	
	if( cityName == ''){

  $('#cityName').focus();

	  return false;

	}
	
    //  alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=insertmenus' + '&cityName=' + escape(cityName); // this where i add multiple data using  ' & '

		//  alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
        success: function(html) {

	 // alert(html);
		// $('.successmsg').html('City Added Successfully').show().delay(3000).fadeOut();

 		//URL
		$('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		$('.successmsg').html('City inserted successfully.').show().delay(3000).fadeOut();
		
	//  window.location.href = URL+'?cityid='+html;
	   $("#loading-image").hide();
       $('#cityName').val('');
	   
	 	if(html == 'failed'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.error_msg').html('city not inserted. Please try again..').show().delay(3000).fadeOut();

		}

		/*if(html == ''){ }
		else{
		$('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		 
		 $('.failure').html('You have not changed in Menu Table').show().delay(3000).fadeOut();
		
		
		}*/

        }

      });

      return false;

    });
	 
	 
	 // for  insert area in locality in city in prixcom

	 $('#AreaSubmit').click(function () {

	// alert();
	  var AreaName = $('#AreaName').val();
	  var AreaPin = $('#AreaPin').val();
		var sltSubCatDyn = $('#sltLocalityCatDyn').val(); // get zone id from data.php
	//alert(sltSubCatDyn);
	  
	
	if( AreaName == ''){

  $('#AreaName').focus();

	  return false;

	}
	
	
	if( sltSubCatDyn == ''){

  $('#sltLocalityCatDyn').focus();

	  return false;

	}
	
	if( AreaPin == ''){

  $('#AreaPin').focus();

	  return false;

	}
	//var pin = /^\d{6}$/ ;
	//if( !AreaPin.match(pin)){
		//$('html, body').animate({
       //  scrollTop: $(".container").offset().top
    	//}, 200);
		//$('.error_msg').html('Please enter six digit pin').show().delay(3000).fadeOut();
     // $('#AreaPin').focus();

//return false;

	//}
	
    //  alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=insertArea' + '&AreaName=' + escape(AreaName) + '&AreaPin=' + escape(AreaPin) + '&sltSubCatDyn=' + escape(sltSubCatDyn); // this where i add multiple data using  ' & '

		//  alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
        success: function(html) {

		$('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		$('.successmsg').html('Area inserted successfully.').show().delay(3000).fadeOut();
		
	//  window.location.href = URL+'?cityid='+html;
	   $("#loading-image").hide();
       $('#AreaName').val('');
	   $('#AreaPin').val('');
	   
	 	if(html == 'failed'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.error_msg').html('Area not inserted. Please try again..').show().delay(3000).fadeOut();

		}

		/*if(html == ''){ }
		else{
		$('html, body').animate({
         scrollTop: $(".container").offset().top
    	}, 200);
		 
		 $('.failure').html('You have not changed in Menu Table').show().delay(3000).fadeOut();
		
		
		}*/

        }

      });

      return false;

    });
 

 

 // for  update locality in city

	 $('#UPdateLocality ').click(function () {

	 	// alert();						 

      var DecodeId = $('#DecodeId').val();
	  var CitySelec = $('#CitySelec').val();
	//  alert(CitySelec);	
	  var localityName = $('#localityName').val();

	if( DecodeId == ''){

  return false;

	}
	 if( CitySelec == ''){

  $('#CitySelec').focus();

	  return false;

	}
	 if( localityName == ''){

  $('#localityName').focus();

	  return false;

	}
	 

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=updatemenus' + '&DecodeId=' + escape(DecodeId) + '&CitySelec=' + escape(CitySelec) + '&localityName=' + escape(localityName); // this where i add multiple data using  ' & '

		//  alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
        success: function(html) {
	  //alert(html);
		if(html == 'success'){
			
      alert("Zone updated successfully");
	  $("#loading-image").hide();
	   window.location.href="view_locality.php";
     //  window.location.href = URL+'?cityid='+HDNEncide;  
	   //$('#catNamePro').val('');
	  // $('#menupricePro').val('');
	  // $('#menuNutriPro').val('');
	 //  $('#chkProDsck').val('');

		}
		else{
		 alert("Zone not updated please try again");
		  window.location.href="view_locality.php";
		 
		
		
		
		}

        }

      });

      return false;

    });
 
 
// for  update subcategorys

	 $('#UpdateSubcat').click(function () {

	 	// alert();						 

      var HDNSubcatID = $('#HDNSubcatID').val();

	  var SubcatName = $('#SubcatNamePro').val();

	if( HDNSubcatID == ''){

  return false;

	}

	   

	 if( SubcatName == ''){

  $('#catNamePro').focus();

	  return false;

	}

	   

	   

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=updateSubCategorys' + '&HDNSubcatID=' + escape(HDNSubcatID) + '&SubcatName=' + escape(SubcatName); // this where i add multiple data using  ' & '

		//  alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		 

        success: function(html) {

	  //alert(html);

	 	if(html != 'success'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.error_msg').html('Subcategory  not update Successfully').show().delay(3000).fadeOut();

		}

		if(html == 'success'){

		 alert('Subcategory updated Successfully');
 
		  $("#loading-image").hide();
        window.location.href="view_subCategory.php";
	   $('#SubcatNamePro').val('');

	  

		}

        }

      });

      return false;

    });


// for  update Business................

	 $('#updatemenubtn').click(function () {

	 	// alert(CategoryPro);						 

      var BusinessName = $('#BusinessName').val();	
	  var CategoryPro = $('#CategoryPro').val();
	   var PriceBusin = $('#PriceBusin').val();
	    var packNamePro1 = $('#packNamePro1').val();
		 var PostDetail = $('#PostDetail').val();
		  var BusinessownerName = $('#BusinessownerName').val();
	    var email = $('#email').val();
		 var bsnpsw = $('#bsnpsw').val();
		  var cnfpsw = $('#cnfpsw').val();
		 
		  var HDNIDEcode = $('#HDNIDEcode').val();
		  var HDNEncide = $('#HDNEncide').val();

	if( HDNIDEcode == ''){

  return false;

	}
	if( HDNEncide == ''){

  return false;

	}

	 if( BusinessName == ''){

  $('#BusinessName').focus();

	  return false;

	}
 if( CategoryPro == ''){

  $('#CategoryPro').focus();

	  return false;

	}
	 if( PriceBusin == ''){

  $('#PriceBusin').focus();

	  return false;

	}
	 if( packNamePro1 == ''){

  $('#packNamePro1').focus();

	  return false;

	}
	 if( PostDetail == ''){

  $('#PostDetail').focus();

	  return false;

	}
	
	if( email == ''){
  $('#email').focus();
	  return false;
	}
	var filter = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
	if (!email.match(filter)) {
    alert('Please provide a valid email address');
   $('#email').focus();
    return false;
 }
 
  if( bsnpsw == ''){
  $('#bsnpsw').focus();
	  return false;
	}
	 if( cnfpsw == ''){
  $('#cnfpsw').focus();
	  return false;
	}
	var passw=  /^[A-Za-z]\w{5,14}$/;
	if (!password.match(passw)) {
    alert('Please enter 7-14 with atleast one lowercase, one uppercase letter.');
   $('#bsnpsw').focus();
    return false;
 }
	if (password != cpass) {
		alert('Password do not match.');
		$('#bsnpsw').focus();
	  return false;
		
		}

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=updateBusiness' + '&HDNIDEcode=' + escape(HDNIDEcode) + '&BusinessName=' + escape(BusinessName) + 
	    				'&CategoryPro=' + escape(CategoryPro) + '&PriceBusin=' + escape(PriceBusin) + 
	    				'&packNamePro1=' + escape(packNamePro1) + '&PostDetail=' + escape(PostDetail); // this where i add multiple data using  ' & '

		  alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function(html) {

	  //alert(html);

	 	if(html != 'success'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.failure').html('Business not updated. Please try again..').show().delay(3000).fadeOut();

		}

		if(html == 'success'){

		  $('.success').html('Business Data updated successfully..').show().delay(3000).fadeOut();

		  $("#loading-image").hide();
        //window.location.href = URL_PHT + "add_bussiness.php?PHTid=" + HDNEncide;
	   $('#SubcatNamePro').val('');

		}

        }

      });

      return false;

    });



// for  search system

	 $('#tySbmt').click(function () {
	 	// alert();						 
      var CTYname = $('#CTYname').val();
	  var ContinentSel = $( "#ContinentSel option:selected" ).val(); //$('#ContinentSel').val();
//alert(ContinentSel);
 
 
      // alert(data);'code=' + code + '&userid=' + userid
	    var data = 'r=SearchFilter' + '&CTYname=' + escape(CTYname) + '&ContinentSel=' + escape(ContinentSel); // this where i add multiple data using  ' & '
		// alert(data);
      $.ajax({
        type:"post",
        cache:false,
        url:URLs,
        data:data,    // multiple data sent using ajax
        success: function(html) {
	   // alert(html);
		 $('#MainResult').fadeOut();
	 		$('#SearchResult').html(html).fadeIn();

        }

      });

      return false;

    });



// for  update area in Zone in city

	 $('#UPdateAreaSubmit').click(function () {

	 	//alert();						 

      var AreaName = $('#AreaName').val();
	  
	   var HDNEncide = $('#DeccodeId').val();
	   var AreaPin = $('#AreaPin').val();
//alert(HDNSubcatID);	
	if( HDNEncide == ''){

  return false;

	}

	 if( AreaName == ''){

  $('#AreaName').focus();

	  return false;

	}
	 if( AreaPin == ''){

  $('#AreaPin').focus();

	  return false;

	}
	   

	   

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=updateSubCategorys' + '&HDNEncide=' + escape(HDNEncide) + '&AreaName=' + escape(AreaName) + '&AreaPin=' + escape(AreaPin); // this where i add multiple data using  ' & '

		// alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		 

        success: function(html) {

	 //alert(html);

	 	if(html != 'success'){

				  $("#loading-image").hide();

				  // document.getElementById('proTypSubmt').value="Add New SubCategory";

				   	 $('.error_msg').html('Area not updated. Please try again').show().delay(3000).fadeOut();

		}

		if(html == 'success'){

$('html, body').animate({scrollTop: $(".container").offset().top }, 3000);

		$('.successmsg').html('Area updated Successfully').show().delay(3000).fadeOut();
 //alert('Area updated successfully..')
		  $("#loading-image").hide();
        window.location.href="view_area.php";
	   $('#SubcatNamePro').val('');

	  

		}

        }

      });

      return false;

    });



/*delete Business images*/
 $(".removemmgg").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteMenuIMG' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url:URLs,
   data: data,
   success: function(){
 }
});
  $('#delim-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});
 
 
 
/*Add new Winner int the Table*/
 $(".AddNewWinner").click(function(){
var element = $(this);
var del_id = element.attr("id");
// alert(del_id);
 var data = 'r=Adddgift' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to Gift this?"))
{
 $.ajax({
   type: "POST",
   url:URLs,
   data: data,
   success: function(){
	   alert('Thanks For Adding The New Winner For This Gift');
	    window.location.href="viewusera.php"; 
 }
});
  $('#delim-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});

/*delete BlogPost images*/
 $(".removBlogImg").click(function(){
var element = $(this);
var del_id = element.attr("id");
 //alert(del_id);
 var data = 'r=deleteBlogIMG' + '&del_id=' + escape(del_id);
 //alert(data);
 if(confirm("Are you sure you want to delete this?"))
{
 $.ajax({
   type: "POST",
   url: URLs,
   data: data,
   success: function(){
 }
});
  $('#delim-'+del_id).animate({ backgroundColor: "#ccc" }, "fast")
  .animate({ opacity: "hide" }, 700);
 }
return false;
});



});



	 
function OnchangeIMG(){ 
	 
    var Ids  = $('#txtcntrynamedy :selected').val();
	//alert(Ids);
    $('#product_id').val(Ids);	
	if(Ids != ''){
	 $('#ImageAddPhoto').show();
	}
	if(Ids == '0'){
	  $('#ImageAddPhoto').hide();
	 }
}
 
 
	 

	function valid(){ 

	 

      if(catProform.catproNamed.value=='0'){

		 $('.error_msg').html('Please select the category').show().delay(3000).fadeOut();

		  $('#catproNamed').focus();

		  return false;

		  }

		  

		   

      if(catProform.sltSubCatDyn.value=='0'){

		 $('.error_msg').html('Please select the sub category').show().delay(3000).fadeOut();

		  $('#sltSubCatDyn').focus();

		  return false;

		  }

	

		   

      if(catProform.txtProName.value=='0'){

		 $('.error_msg').html('Please Enter the Product Name').show().delay(3000).fadeOut();

		  $('#txtProName').focus();

		  return false;

		  }
 }

// Locality to Area 

function LocalityArea() {

var LocalId = $('#sltLocalityCatDyn').val();
//alert(LocalId);
if(LocalId == ''){
	alert('No area in this Locality..');
	$('#dataShowArea').slideUp().hide();
	$('#AreaPro').slideUp().hide();
	return false;
	}
	
	var data = 'r=LocalityChangeToArea' + '&LocalId=' + escape(LocalId);
	//alert(data);
	
	$.ajax({
		   type:"post",
		   cache:false,
		   url:"data.php",
		   data:data,
		   success: function(html){
			   
			   $("#dataShowArea").slideDown().html(html).show();
			   $("#AreaPro").hide();
			   if(html == 'failed'){
				   
				   $("#dataShowArea").hide();
				    $("#AreaPro").hide();
				   }
			   }	   
		   
		   });
	
	
}
 
 
 
 
 function loadXMLDoctr(id)

{

var str=id;

if (str==0)

  {

document.getElementById("myDiv").innerHTML="";

return;

  } 

var xmlhttp;

if (window.XMLHttpRequest)

  {// code for IE7+, Firefox, Chrome, Opera, Safari

  xmlhttp=new XMLHttpRequest();

  }

else

  {// code for IE6, IE5

  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

  }

xmlhttp.onreadystatechange=function()

  {

  if (xmlhttp.readyState==4 && xmlhttp.status==200)

    {

   alert(xmlhttp.responseText);

    document.getElementById("myDiv"+str).innerHTML=xmlhttp.responseText;

    }

  }

xmlhttp.open("GET","data.php?r=Urstatusdev&qs="+str,true);

xmlhttp.send();

}

//for paid status

function loadXMLDoc1(id)

{

var str=id;

if (str==0)

  {

document.getElementById("myDiv").innerHTML="";

return;

  } 

var xmlhttp;

if (window.XMLHttpRequest)

  {// code for IE7+, Firefox, Chrome, Opera, Safari

  xmlhttp=new XMLHttpRequest();

  }

else

  {// code for IE6, IE5

  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

  }

xmlhttp.onreadystatechange=function()

  {

  if (xmlhttp.readyState==4 && xmlhttp.status==200)

    {

//alert(xmlhttp.responseText);

    document.getElementById("myDiv"+str).innerHTML=xmlhttp.responseText;

    }

  }

xmlhttp.open("GET","data.php?r=Urstatusdev1&qs="+str,true);

xmlhttp.send();

}

//cancel status
function loadXMLDoc2(id)

{

var str=id;

if (str==0)

  {

document.getElementById("myDiv2").innerHTML="";

return;

  } 

var xmlhttp;

if (window.XMLHttpRequest)

  {// code for IE7+, Firefox, Chrome, Opera, Safari

  xmlhttp=new XMLHttpRequest();

  }

else

  {// code for IE6, IE5

  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

  }

xmlhttp.onreadystatechange=function()

  {

  if (xmlhttp.readyState==4 && xmlhttp.status==200)

    {

// alert(xmlhttp.responseText);

    document.getElementById("myDiv2"+str).innerHTML=xmlhttp.responseText;

    }

  }

xmlhttp.open("GET","data.php?r=Urstatusdev2&qs="+str,true);

xmlhttp.send();

}