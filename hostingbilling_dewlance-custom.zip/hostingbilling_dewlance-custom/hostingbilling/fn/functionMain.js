$(document).ready(function() {
 var URLHD = location.protocol + "//" + document.domain + "/";//+ location.pathname.split('/')[1] + "/";
 var URLs = URLHD +'housekeeping'+'/'+'dataMain.php';
 //alert(URLs);
 var URLsL = URLHD +"cart.php";
 var URLHDRP = URLHD +'housekeeping'+'/'+'login.php';
 var URLHDRPDoc = URLHD +'housekeeping'+'/'+'index.php';
 
 ///////////////////////////////////////////////////////////////////////////////// for Docotr Login into the khowa here.	  

  $('#UserLoginN').click(function () {
      //alert();
  var username = $('#DoctorsEmail').val();
  var password = $('#Doctorspass').val();
  
	if( username == ''){
   //  $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
	 $('#DoctorsEmail').focus();

	  return false;

	}

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('DoctorsEmail').value.match(mailformat))

	{  $('#DoctorsEmail').focus();

	// $('#errlogD').show().delay(2800).fadeOut();

	  return false; }

	   if( password == ''){

 // $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
  $('#Doctorspass').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=login_user' + '&usernamelogIn=' + escape(username) + '&passwordlogIn=' + escape(password); // this where i add multiple data using  ' & '
window.location.href = "deshboard/index.php";
		  alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
       beforeSend: function() {
 alert(html);
     $("#loadingLogD").show();
	 document.getElementById('UserLoginN').value="Please Wait..";

           },
        success: function(html) {

	    // document.getElementById('Lsubmit').value="LOGIN";

	  alert(html);

		if(html != 111){
        $("#loadingLogD").hide();
		$('#errlogD').html(html).show().delay(2000).fadeOut();
		 document.getElementById('UserLoginN').value="submit";

		}
 alert(html);
		if(html == 111){
		 $("#loadingLogD").hide();
         document.getElementById('UserLoginN').value="submit";
		//$('.successmsgd').html('Login Success').show().delay(2000).fadeOut();
	    $('#DoctorsEmail').val('');
	    $('#Doctorspass').val('');
		//window.location.href = URLHDRPDoc;
		window.location.href = "deshboard/index.php";

		}
   }

      });

      return false;

    });
  
  
   /////////////////////////// /////////////////////////////////////////// for Docotr Login1 into the khowa here.	  

  $('#UserLoginN1').click(function () {
    alert();
  var username = $('#DoctorsEmail1').val();
  var password = $('#Doctorspass1').val();
  
	if( username == ''){
   //  $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
	 $('#DoctorsEmail1').focus();

	  return false;

	}

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('DoctorsEmail1').value.match(mailformat))

	{  $('#DoctorsEmail1').focus();

	// $('#errlogD').show().delay(2800).fadeOut();

	  return false; }

	   if( password == ''){

 // $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
  $('#Doctorspass1').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=TravelAgent' + '&usernamelogIn1=' + escape(username) + '&passwordlogIn1=' + escape(password); // this where i add multiple data using  ' & '

		// alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:"dataMainD.php",

        data:data,    // multiple data sent using ajax
       beforeSend: function() {

     $("#loadingLogD1").show();
	 document.getElementById('UserLoginN1').value="Please Wait..";

           },
        success: function(html) {

	    // document.getElementById('Lsubmit').value="LOGIN";

	   //alert(html);

		if(html != 111){
        $("#loadingLogD1").hide();
		$('#errlogD').html(html).show().delay(2000).fadeOut();
		 document.getElementById('UserLoginN1').value="submit";

		}

		if(html == 111){
			//alert(html);
		 $("#loadingLogD1").hide();
         document.getElementById('UserLoginN1').value="submit";
		//$('.successmsgd').html('Login Success').show().delay(2000).fadeOut();
	    $('#DoctorsEmail1').val('');
	    $('#Doctorspass1').val('');
		window.location.href = "about.php";

		}
   }

      });

      return false;

    });
  
   ///////////////////////////////////////////////////////////////////////////////// for Docotr Login into the khowa here.	  

  $('#UserLoginN2').click(function () {
    // alert();
  var username = $('#DoctorsEmail2').val();
  var password = $('#Doctorspass2').val();
  
	if( username == ''){
   //  $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
	 $('#DoctorsEmail2').focus();

	  return false;

	}

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('DoctorsEmail2').value.match(mailformat))

	{  $('#DoctorsEmail2').focus();

	// $('#errlogD').show().delay(2800).fadeOut();

	  return false; }

	   if( password == ''){

 // $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
  $('#Doctorspass2').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=login_DoctorS2' + '&usernamelogIn2=' + escape(username) + '&passwordlogIn2=' + escape(password); // this where i add multiple data using  ' & '

		 alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
       beforeSend: function() {

     $("#loadingLogD2").show();
	 document.getElementById('UserLoginN2').value="Please Wait..";

           },
        success: function(html) {

	    // document.getElementById('Lsubmit').value="LOGIN";

	   //alert(html);

		if(html != 111){
        $("#loadingLogD2").hide();
		$('#errlogD').html(html).show().delay(2000).fadeOut();
		 document.getElementById('UserLoginN2').value="submit";

		}

		if(html == 111){
		 $("#loadingLogD2").hide();
         document.getElementById('UserLoginN2').value="submit";
		//$('.successmsgd').html('Login Success').show().delay(2000).fadeOut();
	    $('#DoctorsEmail2').val('');
	    $('#Doctorspass2').val('');
		//window.location.href = URLHDRPDoc;
		window.location.href = "about.php";
		
		}
   }

      });

      return false;

    });
  
   ///////////////////////////////////////////////////////////////////////////////// for Docotr Login into the khowa here.	  

  $('#UserLoginN3').click(function () {
    // alert();
  var username = $('#DoctorsEmail3').val();
  var password = $('#Doctorspass3').val();
  
	if( username == ''){
   //  $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
	 $('#DoctorsEmail3').focus();

	  return false;

	}

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('DoctorsEmail3').value.match(mailformat))

	{  $('#DoctorsEmail3').focus();

	// $('#errlogD').show().delay(2800).fadeOut();

	  return false; }

	   if( password == ''){

 // $('#errlogD').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
  $('#Doctorspass3').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=login_DoctorS3' + '&usernamelogIn3=' + escape(username) + '&passwordlogIn3=' + escape(password); // this where i add multiple data using  ' & '

		 alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
       beforeSend: function() {

     $("#loadingLogD3").show();
	 document.getElementById('UserLoginN3').value="Please Wait..";

           },
        success: function(html) {

	    // document.getElementById('Lsubmit').value="LOGIN";

	   //alert(html);

		if(html != 111){
        $("#loadingLogD3").hide();
		$('#errlogD').html(html).show().delay(2000).fadeOut();
		 document.getElementById('UserLoginN3').value="submit";

		}

		if(html == 111){
		 $("#loadingLogD3").hide();
         document.getElementById('UserLoginN3').value="submit";
		//$('.successmsgd').html('Login Success').show().delay(2000).fadeOut();
	    $('#DoctorsEmail3').val('');
	    $('#Doctorspass3').val('');
		//window.location.href = URLHDRPDoc;
		window.location.href = "about.php";

		}
   }

      });

      return false;

    });
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 /////////////////////////////////////////////////////////////////////////////////////// for sing up register user of khawa
 $('#UserHouseData').click(function () {
	 		  alert();				 
      var bidName    = $('#bidName').val();
	  var Name   = $('#Name').val();
	  var Title   = $('#Title').val();
	  var MailId    = $('#Email').val();
	  var adbName   = $('#adbName').val();
	  var adbTitle   = $('#adbTitle').val();
	  var adbMailId    = $('#adbEmail').val();
	  var Steet    = $('#Steet').val();
	  var city    = $('#city').val();
	  var State    = $('#State').val();
	  var Zip    = $('#Zip').val();
	  var phone1    = $('#phone1').val();
	  var phone2 = $('#phone2').val(); 
	  var phone3 = $('#phone3').val();
	  var website = $('#website').val();
		  
		  
	alert();	
	 
   	if( bidName == ''){

   // $('#ErrorDocr').html('Please Enter Your First Name').show().delay(2800).fadeOut();

	 $('#bidName').focus();

	  return false;

	}
	
	if( Name == ''){

   // $('#ErrorDocr').html('Please Enter Your Last Name').show().delay(2800).fadeOut();

	 $('#Name').focus();

	  return false;

	}

	

alert();	

	 if( MailId == ''){

   // $('#ErrorDocr').html('Please Enter Your Email').show().delay(2800).fadeOut();
	 $('#Email').focus();

	  return false;

	}

	

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('Email').value.match(mailformat))
	{ 
	
	//$('#ErrorDocr').html('Please Enter Your vailid Email').show().delay(2800).fadeOut();
	
	$('#Email').focus();

	  return false; }

	 	if( phone == ''){

	// $('#ErrorDocr').html('Please enter your Mobile Number').show().delay(2800).fadeOut();

	 $('#Email').focus();

	 return false;

	}
 
	 alert();	
	
   // alert(data);'code=' + code + '&userid=' + userid
 var data = 'r=RegisterDoctor' + '&bidName=' + escape(bidName)+ '&Name=' + escape(Name) + '&Title=' + escape(Title)++ '&MailId=' + escape(MailId) '&adbName=' + escape(adbName)+ '&adbTitle=' + escape(adbTitle)+ '&adbEmail=' + escape(adbEmail)+ '&Steet=' + escape(Steet) + '&city=' + escape(city)+ '&State=' + escape(State) '&Zip=' + escape(Zip)+ '&phone1=' + escape(phone1)+ '&phone2=' + escape(phone2) '&phone3=' + escape(phone3)+ '&website=' + escape(website;

		alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

              $("#loadingLo").show();
			document.getElementById('UserHouseData').value="Please Wait..";

           },

        success: function(html) {

			//$("#loading-image").hide();

			 //document.getElementById('LogRegister').value="Register";

    alert(html);

		if(html == 1011){

			 $("#loadingLo").hide();

			 $('#ErrorDocr').html('Email id already exists!').show().delay(3900).fadeOut();

			  $('#Email').val('');

			$('#UserHouseData').val("Submit");

			 

		}else 

		if(html == 1211){
       $("#loadingLo").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserHouseData').value="Submit";



		  $('#registerformDev').hide();

		  //$('.cd-switcher').hide();

		  $('#ActiveCodeDV').show();

	    
		
		
		
		
		
		
		

		}else 

		if(html == 'successRe'){
        $("#loadingLo").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserHouseData').value="Submit";

		  

		   $('#registerformDev').hide();

		  $('#ActiveCodeDV').hide();

		  $('#REActiveCodeDV').show();

	    

		}else 
		if(html == '8765'){

			 $("#loadingLo").hide();
			 $('#ErrorDocr').html('Above E-mail Id already activated').show().delay(3900).fadeOut();
			 $('#signup-email').val();
			  document.getElementById('UserHouseData').value="Submit";

			 
		}else {

			 $('#ErrorDocr').html('Network connection problem..').show().delay(3900).fadeOut();
			 $("#loadingLo").hide();

			}

		 



        }

      });

      return false;

    });






 /////////////////////////////////////////////////////////////////////////////////////// for sing up register travel agent of khawa
 $('#UpdateBits').click(function () {
	 		 alert();				 
      var prospect    = $('#prospect').val();
	  var bidname   = $('#bidname').val();
	  var typename   = $('#typename').val();
	  var Frequency    = $('#Frequency').val();
	 
	   
	 
   	if( bidname == ''){

   $('#ErrorDocr').html('Please Enter Your bidname').show().delay(2800).fadeOut();

	 $('#bidname').focus();

	  return false;

	}
	
	if( prospect == ''){

     $('#ErrorDocr').html('Please select Your prospect Name').show().delay(2800).fadeOut();

	 $('#prospect').focus();

	  return false;

	}

	

 
	
   // alert(data);'code=' + code + '&userid=' + userid
 var data = 'r=RegisterDoctor1' + '&Fname1=' + escape(prospect)+ '&LastNAme1=' + escape(bidname)+ '&Address1=' + escape(Frequency);

		alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

              $("#loadingBid").show();
			document.getElementById('UpdateBits').value="Please Wait..";

           },

        success: function(html) {

			//$("#loading-image").hide();

			 //document.getElementById('LogRegister').value="Register";

    alert(html);

		if(html == 1011){

			 $("#loadingBid").hide();

			 $('#ErrorDocr').html('Email id already exists!').show().delay(3900).fadeOut();

			  //$('#signup-email1').val('');

			  document.getElementById('UpdateBits').value="Submit";

			 

		}else 

		if(html == 1211){
       $("#loadingBid").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UpdateBits').value="Submit";



		  $('#registerformDev').hide();

		  //$('.cd-switcher').hide();

		  $('#ActiveCodeDV').show();

	    
		
		
		
		
		
		
		

		}else 

		if(html == 'successRe'){
        $("#loadingBid").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserRegisterU').value="Submit";

		  

		   $('#registerformDev').hide();

		  $('#ActiveCodeDV').hide();

		  $('#REActiveCodeDV').show();

	    

		}else 
		if(html == '8765'){

			 $("#loadingBid").hide();
			 $('#ErrorDocr').html('Above E-mail Id already activated').show().delay(3900).fadeOut();
			// $('#signup-email').val();
			  document.getElementById('UserRegisterU').value="Submit";

			 
		}else {

			 $('#ErrorDocr').html('Network connection problem..').show().delay(3900).fadeOut();
			 $("#loadingLo").hide();

			}

		 



        }

      });

      return false;

    });

 

 /////////////////////////////////////////////////////////////////////////////////////// for sing up register Tranlator agent of khawa
 $('#UserRegisterU2').click(function () {
	 		//alert();				 
      var Fname    = $('#signup-Fname2').val();
	  var LastNAme   = $('#LastNAme2').val();
	  var MailId   = $('#signup-email2').val();
	  var phone    = $('#signup-phone2').val();
	 var Address    = $('#Address2').val();
	  var Pincode    = $('#Pincode2').val();
	   var language    = $('#language').val();
	  var Useraname    = $('#Useraname2').val();
	 var Password = $('#signup-password2').val(); 
	  var CPasswrd = $('#signup-Cpassword2').val();
		 //var DoctorCv = $('#DoctorCv').val(); 
	/*	 

  

     var dateofBirth = $('#dateofBirth').val();
      var AddressName    = $('#AddressName').val();
	  var CountryName = $('#CountryName').val();
	  var statename = $('#statename').val(); 
	  
	  var cityName = $('#cityName').val(); 

	  var Zipcodedt = $('#Zipcode').val();*/
	 
   	if( Fname == ''){

   // $('#ErrorDocr').html('Please Enter Your First Name').show().delay(2800).fadeOut();

	 $('#signup-Fname2').focus();

	  return false;

	}
	
	if( LastNAme == ''){

   // $('#ErrorDocr').html('Please Enter Your Last Name').show().delay(2800).fadeOut();

	 $('#LastNAme2').focus();

	  return false;

	}

	



	 if( MailId == ''){

   // $('#ErrorDocr').html('Please Enter Your Email').show().delay(2800).fadeOut();
	 $('#signup-email2').focus();

	  return false;

	}

	

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('signup-email2').value.match(mailformat))
	{ 
	
	//$('#ErrorDocr').html('Please Enter Your vailid Email').show().delay(2800).fadeOut();
	
	$('#signup-email2').focus();

	  return false; }

	 	if( phone == ''){

	// $('#ErrorDocr').html('Please enter your Mobile Number').show().delay(2800).fadeOut();

	 $('#signup-phone2').focus();

	 return false;

	}
	 

		
	
	  if( Password == ''){

	 // $('#ErrorDocr').html('Please enter your password').show().delay(2800).fadeOut();

	 $('#signup-password2').focus();

	  return false;

	}

	 if( CPasswrd == ''){

//$('#ErrorDocr').html('Please Re-enter your password').show().delay(2800).fadeOut();

	 $('#signup-Cpassword2').focus();

	 return false;

	}

	if( Password != CPasswrd){

	 document.getElementById('signup-password2').focus(); //$('#signup-password').focus();
//$('#ErrorDocr').html('Please confirm your password').show().delay(2800).fadeOut();
	 $('#signup-Cpassword2').focus();

	 return false;

	 }
	
	
   // alert(data);'code=' + code + '&userid=' + userid
 var data = 'r=RegisterDoctor2' + '&Fname2=' + escape(Fname)+ '&LastNAme2=' + escape(LastNAme) + '&Useraname2=' + escape(Useraname)+ '&Pincode2=' + escape(Pincode)+ '&language=' + escape(language)+ '&Address2=' + escape(Address)+ '&MailId2=' + escape(MailId)+ '&phone2=' + escape(phone) + '&Password2=' + escape(Password);

		alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

              $("#loadingLo2").show();
			document.getElementById('UserRegisterU2').value="Please Wait..";

           },

        success: function(html) {

			//$("#loading-image").hide();

			 //document.getElementById('LogRegister').value="Register";

    alert(html);

		if(html == 1011){

			 $("#loadingLo2").hide();

			 $('#ErrorDocr').html('Email id already exists!').show().delay(3900).fadeOut();

			  $('#signup-email2').val('');

			  document.getElementById('UserRegisterU2').value="Submit";

			 

		}else 

		if(html == 1211){
       $("#loadingLo2").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserRegisterU2').value="Submit";



		  $('#registerformDev').hide();

		  //$('.cd-switcher').hide();

		  $('#ActiveCodeDV').show();

	    
		
		
		
		
		
		
		

		}else 

		if(html == 'successRe'){
        $("#loadingLo").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserRegisterU').value="Submit";

		  

		   $('#registerformDev').hide();

		  $('#ActiveCodeDV').hide();

		  $('#REActiveCodeDV').show();

	    

		}else 
		if(html == '8765'){

			 $("#loadingLo").hide();
			 $('#ErrorDocr').html('Above E-mail Id already activated').show().delay(3900).fadeOut();
			 $('#signup-email').val();
			  document.getElementById('UserRegisterU').value="Submit";

			 
		}else {

			 $('#ErrorDocr').html('Network connection problem..').show().delay(3900).fadeOut();
			 $("#loadingLo").hide();

			}

		 



        }

      });

      return false;

    });

 

 /////////////////////////////////////////////////////////////////////////////////////// for sing up register Taxi agent of khawa
 $('#UserRegisterU3').click(function () {
	 		//alert();				 
      var Fname    = $('#signup-Fname3').val();
	  var LastNAme   = $('#LastNAme3').val();
	  var MailId   = $('#signup-email3').val();
	  var phone    = $('#signup-phone3').val();
	 var Address    = $('#Address3').val();
	  var Pincode    = $('#Pincode3').val();
	   var Useraname    = $('#Useraname3').val();
	 var Password = $('#signup-password3').val(); 
	  var CPasswrd = $('#signup-Cpassword3').val();
		 //var DoctorCv = $('#DoctorCv').val(); 
	/*	 

  

     var dateofBirth = $('#dateofBirth').val();
      var AddressName    = $('#AddressName').val();
	  var CountryName = $('#CountryName').val();
	  var statename = $('#statename').val(); 
	  
	  var cityName = $('#cityName').val(); 

	  var Zipcodedt = $('#Zipcode').val();*/
	 
   	if( Fname == ''){

   // $('#ErrorDocr').html('Please Enter Your First Name').show().delay(2800).fadeOut();

	 $('#signup-Fname3').focus();

	  return false;

	}
	
	if( LastNAme == ''){

   // $('#ErrorDocr').html('Please Enter Your Last Name').show().delay(2800).fadeOut();

	 $('#LastNAme3').focus();

	  return false;

	}

	



	 if( MailId == ''){

   // $('#ErrorDocr').html('Please Enter Your Email').show().delay(2800).fadeOut();
	 $('#signup-email3').focus();

	  return false;

	}

	

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('signup-email3').value.match(mailformat))
	{ 
	
	//$('#ErrorDocr').html('Please Enter Your vailid Email').show().delay(2800).fadeOut();
	
	$('#signup-email3').focus();

	  return false; }

	 	if( phone == ''){

	// $('#ErrorDocr').html('Please enter your Mobile Number').show().delay(2800).fadeOut();

	 $('#signup-phone3').focus();

	 return false;

	}
	 

		
	
	  if( Password == ''){

	 // $('#ErrorDocr').html('Please enter your password').show().delay(2800).fadeOut();

	 $('#signup-password3').focus();

	  return false;

	}

	 if( CPasswrd == ''){

//$('#ErrorDocr').html('Please Re-enter your password').show().delay(2800).fadeOut();

	 $('#signup-Cpassword3').focus();

	 return false;

	}

	if( Password != CPasswrd){

	 document.getElementById('signup-password3').focus(); //$('#signup-password').focus();
//$('#ErrorDocr').html('Please confirm your password').show().delay(2800).fadeOut();
	 $('#signup-Cpassword3').focus();

	 return false;

	 }
	
	
   // alert(data);'code=' + code + '&userid=' + userid
 var data = 'r=RegisterDoctor3' + '&Fname3=' + escape(Fname)+ '&LastNAme3=' + escape(LastNAme) + '&Useraname3=' + escape(Useraname)+ '&Pincode3=' + escape(Pincode)+ '&Address3=' + escape(Address)+ '&MailId3=' + escape(MailId)+ '&phone3=' + escape(phone) + '&Password3=' + escape(Password);

		alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

              $("#loadingLo3").show();
			document.getElementById('UserRegisterU3').value="Please Wait..";

           },

        success: function(html) {

			//$("#loading-image").hide();

			 //document.getElementById('LogRegister').value="Register";

    alert(html);

		if(html == 1011){

			 $("#loadingLo3").hide();

			 $('#ErrorDocr').html('Email id already exists!').show().delay(3900).fadeOut();

			  $('#signup-email3').val('');

			  document.getElementById('UserRegisterU3').value="Submit";

			 

		}else 

		if(html == 1211){
       $("#loadingLo3").hide();
		$('.successmsg').html('Ragistraition Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserRegisterU3').value="Submit";



		  $('#registerformDev').hide();

		  //$('.cd-switcher').hide();

		  $('#ActiveCodeDV').show();

	    
		
		
		
		
		
		
		

		}else 

		if(html == 'successRe'){
        $("#loadingLo").hide();
		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('UserRegisterU').value="Submit";

		  

		   $('#registerformDev').hide();

		  $('#ActiveCodeDV').hide();

		  $('#REActiveCodeDV').show();

	    

		}else 
		if(html == '8765'){

			 $("#loadingLo").hide();
			 $('#ErrorDocr').html('Above E-mail Id already activated').show().delay(3900).fadeOut();
			 $('#signup-email').val();
			  document.getElementById('UserRegisterU').value="Submit";

			 
		}else {

			 $('#ErrorDocr').html('Network connection problem..').show().delay(3900).fadeOut();
			 $("#loadingLo").hide();

			}

		 



        }

      });

      return false;

    });



 // for user Login into the DawaMDaccount here.	  

  $('#LOgInfont').click(function () {

  var username = $('#signinemailLog').val();
  var password = $('#signinpasswordLog').val();
       

	if( username == ''){
     $('#errlog').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
	 $('#signinemailLog').focus();

	  return false;

	}

	//var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	//if(!document.getElementById('signin-email').value.match(mailformat))

	//{  $('#signin-email').focus();

	//  $('#er1').show().delay(2800).fadeOut();

	 // return false; }

	   if( password == ''){

  $('#errlog').html('Please Enter Your Email Or UserName').show().delay(2800).fadeOut();
  $('#signinpasswordLog').focus();

	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=login_users' + '&usernamelogIn=' + escape(username) + '&passwordlogIn=' + escape(password); // this where i add multiple data using  ' & '

		// alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
       beforeSend: function() {

     $("#loadingLog").show();
	 document.getElementById('LOgInfont').value="Please Wait..";

           },
        success: function(html) {

	
	    // document.getElementById('Lsubmit').value="LOGIN";

	  // alert(html);

		if(html != '111'){
        $("#loadingLog").hide();
		$('#ErrorLogin').html(html).show().delay(2000).fadeOut();
		 document.getElementById('LOgInfont').value="LOGIN";

		}

		if(html == '111'){
		 $("#loadingLog").hide();
         document.getElementById('LOgInfont').value="LOGIN";
		$('.successmsg').html('Login Success').show().delay(2000).fadeOut();
	    $('#signinemailLog').val('');
	    $('#signinpasswordLog').val('');
		window.location.href = URLHDRP;

		}
   }

      });

      return false;

    });
  
  
  
 // for Searching the Doctors From HEre.	  

 $('#specialityD').on('change', function() {

  //alert();
   var Cityid = $( "#myselect option:selected" ).val();
   var Localityid = $("#Locality option:selected" ).val();
   var speciality = $("#specialityD option:selected" ).val();
 
        //alert(Cityid);

	if( Cityid == '0'){
     $('#serlog').html('Please Select The city name First').show().delay(2800).fadeOut();
	 $('#myselect').focus();
	  return false;

	}

	if( Localityid == '0'){
     $('#serlog').html('Please Select The Locality name First').show().delay(2800).fadeOut();
	 $('#Locality').focus();
	  return false;

	}

		if( speciality == '0'){
     $('#serlog').html('Please Select The Speciality name First').show().delay(2800).fadeOut();
	 $('#specialityD').focus();
	  return false;

	}
      // alert(data);'code=' + code + '&userid=' + userid
	 // $("#LOderImgId").show();
	  //document.getElementById('LOgInfont').value="Wait..";  $("#LOderImgId").show();

	     var data = 'r=SearchArchives' + '&Cityid=' + escape(Cityid) + '&Localityid=' + escape(Localityid)+ '&speciality=' + escape(speciality); 
		 // this where i add multiple data using  ' & '

		//alert(data);

        $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax
       beforeSend: function() {

     $("#loadingSocimg").show();
	// document.getElementById('SerchArchive').value="Please Wait..";

           },
        success: function(html) {
	    // document.getElementById('Lsubmit').value="LOGIN";
	  //alert(html);
	  		if(html != '1111'){
		 $("#loadingSocimg").hide();
		 $("#mnds").hide();
        $('#Nextd').html(html).show();
		}
		if(html == '1111'){
		 $("#loadingSocimg").hide();
        // document.getElementById('SerchArchive').value="Search";
        $('#serlog').html('Your Request Could not be completed').show().delay(2800).fadeOut();
		}
   }

      });

      return false;

    });
 // for sing up register of patience
 $('#LogRegister').click(function () {
	 //alert(URLHD);						 
      var Fname    = $('#signup-Fname').val();
	  var LastNAme   = $('#LastNAme').val();
	  var MailId   = $('#signup-email').val();
	  
	  var UserNameL    = $('#UserNameL').val();
	  var Password = $('#signup-password').val(); 
	  var CPasswrd = $('#signup-Cpassword').val();
     var phone    = $('#signup-phone').val();

     var dateofBirth = $('#dateofBirth').val();
      var AddressName    = $('#AddressName').val();
	  var CountryName = $('#CountryName').val();
	  var statename = $('#statename').val(); 
	  
	  var cityName = $('#cityName').val(); 

	  var Zipcodedt = $('#Zipcode').val();
	 
   	if( Fname == ''){

    $('#errrB').html('Please Enter Your First Name').show().delay(2800).fadeOut();

	 $('#signup-Fname').focus();

	  return false;

	}
	
	if( LastNAme == ''){

    $('#errrB').html('Please Enter Your Last Name').show().delay(2800).fadeOut();

	 $('#LastNAme').focus();

	  return false;

	}

	 if( MailId == ''){

    $('#errrB').html('Please Enter Your Email').show().delay(2800).fadeOut();
	 $('#signup-email').focus();

	  return false;

	}

	

	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  

	if(!document.getElementById('signup-email').value.match(mailformat))
	{ 
	
	$('#errrB').html('Please Enter Your vailid Email').show().delay(2800).fadeOut();
	
	$('#signup-email').focus();

	  return false; }


	 
	if( UserNameL == ''){

	 $('#errrB').html('Please Enter Your User Name').show().delay(2800).fadeOut();

	 $('#UserNameL').focus();

	 return false;

	}
	 


	  if( Password == ''){

	  $('#errrB').html('Please enter your password').show().delay(2800).fadeOut();

	 $('#signup-password').focus();

	  return false;

	}

	 if( CPasswrd == ''){

$('#errrB').html('Please Re-enter your password').show().delay(2800).fadeOut();

	 $('#signup-Cpassword').focus();

	 return false;

	}

	if( Password != CPasswrd){

	 document.getElementById('signup-password').focus(); //$('#signup-password').focus();
$('#errrB').html('Please confirm your password').show().delay(2800).fadeOut();
	 $('#signup-Cpassword').focus();

	 return false;

	 }
	 
	  
	 	if( phone == ''){

	 $('#errrB').html('Please enter your Mobile Number').show().delay(2800).fadeOut();

	 $('#signup-phone').focus();

	 return false;

	}
	 

	
	
	 if( dateofBirth == ''){
	 $('#errrB').html('Please enter your date of birth').show().delay(2800).fadeOut();

	 $('#dateofBirth').focus();

	 return false;

	}




	
		 if( AddressName == ''){

	 $('#errrB').html('Please enter your address').show().delay(2800).fadeOut();

	 $('#AddressName').focus();

	 return false;

	}
	
		 if( statename == ''){

	 $('#errrB').html('Please Select your Stete name').show().delay(2800).fadeOut();

	 $('#statename').focus();

	 return false;

	}
	
			 if( cityName == ''){

	 $('#errrB').html('Please Select your City name').show().delay(2800).fadeOut();

	 $('#cityName').focus();

	 return false;

	}
	
				 if( Zipcodedt == ''){

	 $('#errrB').html('Please Select your Zip code').show().delay(2800).fadeOut();

	 $('#Zipcode').focus();

	 return false;

	}
	

      // alert(data);'code=' + code + '&userid=' + userid

 var data = 'r=LoginRegister' + '&Fname=' + escape(Fname)+ '&LastNAme=' + escape(LastNAme) + '&MailId=' + escape(MailId) + '&UserNameL=' + escape(UserNameL)
+ '&Password=' + escape(Password) + '&phone=' + escape(phone) + '&dateofBirth=' + escape(dateofBirth)+ '&AddressName=' + escape(AddressName)+ '&CountryName=' + escape(CountryName)+ '&statename=' + escape(statename) + '&cityName=' + escape(cityName) + '&Zipcodedt=' + escape(Zipcodedt);

		  // alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

              $("#loading-image").show();
			document.getElementById('LogRegister').value="Please Wait..";

           },

        success: function(html) {

			//$("#loading-image").hide();

			 //document.getElementById('LogRegister').value="Register";

   // alert(html);

		if(html == '1011'){

			 $("#loading-image").hide();

			 $('#mailErrorEst').html('Email id already exists!').show().delay(3900).fadeOut();

			  $('#signup-email').val('');

			  document.getElementById('LogRegister').value="Register";

			 

		} else 

		if(html == 'success'){

		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('LogRegister').value="Register";

		  $("#loading-image").hide();

		  $('#registerformDev').hide();

		  //$('.cd-switcher').hide();

		  $('#ActiveCodeDV').show();

	    

		}else 

		if(html == 'successRe'){

		$('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();

		 document.getElementById('LogRegister').value="Register";

		  $("#loading-image").hide();

		   $('#registerformDev').hide();

		  $('#ActiveCodeDV').hide();

		  $('#REActiveCodeDV').show();

	    

		}else 

		if(html == '8765'){

			 $("#loading-image").hide();

			 $('#mailErrorEst').html('Above E-mail Id already activated').show().delay(3900).fadeOut();

			  $('#signup-email').val();

			  document.getElementById('LogRegister').value="Register";

			 

		} 

		 else {

			 $('#mailErrorEst').html('Network connection problem..').show().delay(3900).fadeOut();

			  $("#loading-image").hide();

			}

		 



        }

      });

      return false;

    });

 
 
 
 
  $("#signup-phone").keypress(function (e) {

     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
     $("#errrB").html("Please Enter Only Digit").show().fadeOut("slow");

               return false;

    }

   });
  
  
    $("#Zipcode").keypress(function (e) {

     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
     $("#errrB").html("Please Enter Only Digit").show().fadeOut("slow");

               return false;

    }

   });	
	
 // for active code 
 $('#DevidayalActive').click(function () {
							 
	  var UserNameL    = $('#UserNameL').val();
	  
	  var MailId   = $('#signup-email').val();
	  
	  var activeC =  $('#txtActivCoded').val();


     if( activeC == ''){
	   
     $('#errrBa').html('Please enter Activation Code').show().delay(2800).fadeOut();
	 $('#txtActivCoded').focus();

	  return false;
	}


 //alert(data);'code=' + code + '&userid=' + userid

 var data = 'r=UserActive' + '&UserNameL=' + escape(UserNameL) + '&MailId=' + escape(MailId) + '&activeC=' + escape(activeC);

		// alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

          $("#loading-imagea").show();
			document.getElementById('DevidayalActive').value="Please Wait..";

           },

        success: function(html) {

	// document.getElementById('activeAsbmt').value="Submit";

	 // alert(html);

		if(html == 'invalid'){

			 $("#loading-imagea").hide();

			 $('#errrBa').html('Invalid Activation Code').show().delay(3900).fadeOut();

			  //$('#signup-email').val('');
            document.getElementById('DevidayalActive').value="Submit";

		} else 

		if(html == 'okOye'){

       $("#loading-imagea").hide();
	   $('#errrBa').html('Thanks For Submitting Your details').show().delay(3900).fadeOut();
	    window.location.href = URLHDRP;
	// $('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();
		 document.getElementById('DevidayalActive').value="Submit";

		}else{

			 $('#errrBa').html('Network connection problem..').show().delay(3900).fadeOut();
			  $("#loading-imagea").hide();

			}

        }

      });

      return false;

    });

	
	
// for Reactive code 
 $('#DevActive').click(function () {
							 
	  var UserNameL    = $('#UserNameL').val();
	  
	  var MailId   = $('#signup-email').val();
	  
	  var activeC =  $('#txtReact').val();


     if( activeC == ''){
	   
     $('#errrBaR').html('Please enter Activation Code').show().delay(2800).fadeOut();
	 $('#txtReact').focus();

	  return false;
	}


 //alert(data);'code=' + code + '&userid=' + userid

 var data = 'r=UserActiveR' + '&UserNameL=' + escape(UserNameL) + '&MailId=' + escape(MailId) + '&activeC=' + escape(activeC);

		// alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

          $("#loading-imageaR").show();
			document.getElementById('DevActive').value="Please Wait..";

           },

        success: function(html) {

	// document.getElementById('activeAsbmt').value="Submit";

	 // alert(html);

		if(html == 'invalid'){

			 $("#loading-imageaR").hide();

			 $('#errrBaR').html('Invalid Activation Code').show().delay(3900).fadeOut();

			  //$('#signup-email').val('');
            document.getElementById('DevActive').value="Submit";

		} else 

		if(html == 'okOye'){

       $("#loading-imagea").hide();
	   $('#errrBaR').html('Thanks For Submitting Your details').show().delay(3900).fadeOut();
	    window.location.href = URLHDRP;
	// $('.successmsg').html('Mobile Number Details Added Successfully').show().delay(3000).fadeOut();
		 document.getElementById('DevActive').value="Submit";

		}else{

			 $('#errrBaR').html('Network connection problem..').show().delay(3900).fadeOut();
			  $("#loading-imageaR").hide();

			}

        }

      });

      return false;

    });
	
	
	
$('#CountryName').on('change', function() {

      var ProductCatIds = $('#CountryName').val();

	  // alert(ProductCatIds);

	   if( ProductCatIds == '0'){

	  $('#CountryName').focus();

	   	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=ShowState' + '&ProductCatIds=' + escape(ProductCatIds); // this where i add multiple data using  ' & '

	 	//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function (html) {

		//alert(html);
		if(html == '1111'){

       $('#mailErrorEst').html('Please Select Country Name First').show().delay(3900).fadeOut();
			//$('.contantFcaRDTTl').hide();

		}

		 if(html != '1111'){

			$('#statename').show().html(html);

		}

        }

      });

      return false;

    });

	
	$('#statename').on('change', function() {

      var ProductCatIds = $('#statename').val();

	   //alert(ProductCatIds);

	   if( ProductCatIds == '0'){

	  $('#statename').focus();

	   	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=ShowCity' + '&ProductCatIds=' + escape(ProductCatIds); // this where i add multiple data using  ' & '

	 	//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function (html) {

		//alert(html);
		if(html == '1111'){

       $('#mailErrorEst').html('Please Select Country Name First').show().delay(3900).fadeOut();
			//$('.contantFcaRDTTl').hide();

		}

		 if(html != '1111'){

			$('#cityName').show().html(html);

		}

        }

      });

      return false;

    });



/*For Visiting  The Appointment ofBooking here.*/

$(".VisitDoc").click(function(){

var element = $(this);

var del_id = element.attr("id");
//var del_id = $('#storeIDs').val();
 //alert(del_id);

 var data = 'r=Showprovider' + '&del_id=' + escape(del_id);

 //alert(data);

 $.ajax({
   type: "POST",

    url:URLs,

   data: data,

   success: function(html){   
   //alert(html);
   
    if(html != '1111'){
		
	$('#prvido').hide()
    $('#Providrr').show().html(html);
		}
		
  if(html == '1111'){
   $('#errrBaR').html('Thanks Your Details has Been Removed.......').show().delay(3900).fadeOut();
	    //window.location.href = URLHDRPM;
		location.reload();
		//document.getElementById('RemoveStoreOwn').value="Submit";
		}

 }

});

return false;

});



/*For Scheduling The Appointment ofBooking here.*/

$(".schedules").click(function(){

var element = $(this);

var del_id = element.attr("id");
//var del_id = $('#storeIDs').val();
 //alert(del_id);

 var data = 'r=ShowdoctrProfile' + '&del_id=' + escape(del_id);

 alert(data);

 $.ajax({
   type: "POST",

    url:URLs,

   data: data,

   success: function(html){   
   //alert(html);
    if(html != '1111'){
    $('#Docprofile').show().html(html);
		}
		
  if(html == '1111'){

	   $('#errrBaR').html('Thanks Your Details has Been Removed.......').show().delay(3900).fadeOut();
	    //window.location.href = URLHDRPM;
		location.reload();
		//document.getElementById('RemoveStoreOwn').value="Submit";
		}

 }

});

return false;

});

	//Main Function Close Here Devidayal
						   });

//From HEre Starts New Functon Details Devidayal ....
function closePopup(){
			//alert();
		location.reload();
	}

//From HEre Starts New Functon Details Devidayal ....
function Showloclity(){
 var URLHD = location.protocol + "//" + document.domain + "/";//+ location.pathname.split('/')[1] + "/";
 var URLs = URLHD +'DawaMddoctor'+'/'+'dataMain.php';
  var ProductCatIds = $('#myselect').val();

	   //alert(ProductCatIds);

	   if( ProductCatIds == '0'){

	  $('#myselect').focus();

	   	  return false;

	   }

      // alert(data);'code=' + code + '&userid=' + userid

	    var data = 'r=ShowLoclity' + '&ProductCatIds=' + escape(ProductCatIds); // this where i add multiple data using  ' & '

	 	//alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

        success: function (html) {

		//alert(html);
		if(html == '1111'){

       $('#DRRCt').html('Please Select City Name First').show().delay(3900).fadeOut();
			//$('.contantFcaRDTTl').hide();

		}

		 if(html != '1111'){

			$('#Locality').show().html(html);

		}

        }

      });

    	//return false;

	}



//For Checking The USername here
function quikPopupUser(){
 var URLHD = location.protocol + "//" + document.domain + "/";//+ location.pathname.split('/')[1] + "/";
 var URLs = URLHD +'DawaMddoctor'+'/'+'dataMain.php';
 var UserNameL    = $('#UserNameL').val();
	   
	   //alert(UserNameL);

	   var data = 'r=CheckuserAvl' + '&UserNameL=' + escape(UserNameL);
       //alert(data);
       $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {
      $("#loading-image").show();
		},

        success: function(html) {
          if(html == '1404'){
			 $("#loading-image").hide();

			 $('#mailErrorEst').html('This User Name  already exists! Please Enter Another User Name').show().delay(3900).fadeOut();

			  $('#UserNameL').val('');

			  //document.getElementById('LogRegister').value="Register";
			   $('#UserNameL').focus();

			 

		} else 

		if(html == '2001'){
			 $("#loading-image").hide();

			 $('#mailErrorEst').html('This User Name Available').show().delay(3900).fadeOut();
			 
		}else{
			 $("#loading-image").hide();
			}

		}

      });

	
	//return false;
	}
	
//For Checking the UserEmail
	function quikPopupEmail(){
 var URLHD = location.protocol + "//" + document.domain + "/";//+ location.pathname.split('/')[1] + "/";
 var URLs = URLHD +'DawaMddoctor'+'/'+'dataMain.php';
 
	  var signupemail    = $('#signup-email').val();
	   
	   //alert(signupemail);

	   var data = 'r=CheckEmailAvl' + '&signupemail=' + escape(signupemail);
       //alert(data);
       $.ajax({

        type:"post",

        cache:false,

        url:"dataMain.php",

        data:data,    // multiple data sent using ajax

		beforeSend: function() {
      $("#loading-image").show();
		},

        success: function(html) {

	if(html == '1404'){

			 $("#loading-image").hide();

			 $('#mailErrorEst').html('This Email id already exists! Please Enter Another Email').show().delay(3900).fadeOut();

			  $('#signup-email').val('');

                $('#signup-email').focus();
			  //document.getElementById('LogRegister').value="Register";		 

		}else 

		if(html == '2001'){
			 $("#loading-image").hide();

			 $('#mailErrorEst').html('OK').show().delay(3900).fadeOut();

			 // $('#UserNameL').val('');

			  //document.getElementById('LogRegister').value="Register";
			  // $('#UserNameL').focus();

		}else{
			 $("#loading-image").hide();
			}

		}

      });
	//return false;
}
	
/*For Requesting the New Appointment ofBooking here.*/
function quickRequest(){
var URLHD = location.protocol + "//" + document.domain + "/";//+ location.pathname.split('/')[1] + "/";
var URLs = URLHD +'DawaMddoctor'+'/'+'dataMain.php';
var URLHDRP = URLHD +'DawaMddoctor'+'/'+'seeadoctorlogin.php'; 

  var rqstuid    = $('#rqstuid').val();
  var rqstuname   = $('#rqstuname').val();
  var rqstuLname =  $('#rqstuLname').val();
  var AppDAte    = $('#datetimepicker144').val();
  var AppTime   = $('#basicExample').val();
  var Apptype = $('input[name="contact"]:checked').val();
  var ContactMob =  $('#ContactMob').val();
//alert(rqstuid);
//alert(Apptype);

     if( AppDAte == ''){
	   
     $('#errD').html('Please Enter The Date of your appointment').show().delay(2800).fadeOut();
	 $('#datetimepicker144').focus();

	  return false;
	}
     if( AppTime == ''){
	   
     $('#errD').html('Please Enter The Time of your appointment').show().delay(2800).fadeOut();
	 $('#basicExample').focus();

	  return false;
	}
	
	if( Apptype == ''){   
     $('#errD').html('Please Select the type of your appointment').show().delay(2800).fadeOut();
    // $('input[name="contact"]').focus();
	  return false;
	}

 //alert(data);'code=' + code + '&userid=' + userid

 var data = 'r=PreRequestApp' + '&rqstuid=' + escape(rqstuid) + '&rqstuname=' + escape(rqstuname) + '&rqstuLname=' + escape(rqstuLname)
                            + '&AppDAte=' + escape(AppDAte) + '&AppTime=' + escape(AppTime) + '&Apptype=' + escape(Apptype)
							+ '&ContactMob=' + escape(ContactMob);

		 //alert(data);

      $.ajax({

        type:"post",

        cache:false,

        url:URLs,

        data:data,    // multiple data sent using ajax

		beforeSend: function() {

          $("#loadimageaR").show();
			document.getElementById('RequestApp').value="Please Wait..";

           },

        success: function(html) {

	// document.getElementById('activeAsbmt').value="Submit";

	 //alert(html);

		if(html == '1111'){

			 $("#loadimageaR").hide();

			 $('#errD').html('Invalid Activation Code').show().delay(3900).fadeOut();

			  //$('#signup-email').val('');
            document.getElementById('RequestApp').value="submit";

		} else 

		if(html == 'success'){

       $("#loadimageaR").hide();
	   $('#errD').html('Thanks For Submitting Your details').show().delay(3900).fadeOut();
	    window.location.href = URLHDRP;
		document.getElementById('RequestApp').value="Submit";

		}else{

			 $('#errD').html('Network connection problem..').show().delay(3900).fadeOut();
			  $("#loadimageaR").hide();

			}

        }

      });

		
		//return false;	
		}	
		
		
		
		
		
		