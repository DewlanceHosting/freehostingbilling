<?php 
session_start();
include('connect.php');


   // for update Status user account activate  

if($_GET['r']){

$r = $_GET['r'];

   if($r == 'Urstatusdev1'){

      $Idsds = mysql_real_escape_string(trim($_GET['qs']));

    if( !empty($Idsds) && ($Idsds != 'undefined' ) ){

	

		$sqlSH = "SELECT * FROM cl_user WHERE ur_id='$Idsds'";

		$reSH = mysql_query($sqlSH) or die( mysql_error());

		$nuMs = mysql_num_rows($reSH);

		$FRdt = mysql_fetch_array($reSH);
		$email=$FRdt['ur_mailid'];
		$name=$FRdt['ur_name'];

		if($nuMs>0){

		if($FRdt['ur_status'] == 0){

		$sql = "UPDATE cl_user SET ur_status = '1' WHERE cl_user.ur_id = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());
		
         
		if($re){
       
    
 
    //   CHANGE THE BELOW VARIABLES TO YOUR NEEDS
$to = $email;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="image/logo.png" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello Dear</p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Name: &nbsp;'. $name.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $email.'</strong></p>
  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
';

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: dewlance@gmail.com>' . "\r\n";
$headers .= 'Cc:dewlance@gmail.com' . "\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);
		 
		 
		 
		     echo '<span style="color:green;" >Active</span> ';
			 
      

		 }

		}else{

		$sql = "UPDATE cl_user SET ur_status = '0' WHERE cl_user.ur_id = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());

		if($re){

		    echo '<span style="color:red;" class="srnum">Inactive</span>';

		  }

		}

		}

		

		

		}else { echo 'failed';}

      }

   }

// for update Status user account activate  

if($_GET['r']){

$r = $_GET['r'];

   if($r == 'Urstatusdev'){

      $Idsds = mysql_real_escape_string(trim($_GET['qs']));

    if( !empty($Idsds) && ($Idsds != 'undefined' ) ){

	

		$sqlSH = "SELECT * FROM tbl_doctors WHERE dr_id='$Idsds'";

		$reSH = mysql_query($sqlSH) or die( mysql_error());

		$nuMs = mysql_num_rows($reSH);

		$FRdt = mysql_fetch_array($reSH);
		$email=$FRdt['ur_mailid'];
		$fname=$FRdt['dr_Fname'];
        $lname=$FRdt['dr_Lname'];
		if($nuMs>0){

		if($FRdt['ur_status'] == 0){

		$sql = "UPDATE tbl_doctors SET ur_status = '1' WHERE tbl_doctors.dr_id = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());

		if($re){


    //   CHANGE THE BELOW VARIABLES TO YOUR NEEDS
$to = $email;
$subject = "Your Account Details";
// Get HTML contents from file
$htmlContent = '<html><body>
<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">
<img src="image/logo.png" alt="logo" title="MyBrochure" style="width:160px;">
<p style="font:14px calibri;color:#333;margin:12px 0; "> <strong>Your  Account Details.</strong></p>
<p style="font:14px calibri;color:#333;margin:12px 0; ">Hello </p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Name: &nbsp;'. $fname.' &nbsp;'. $lname.'</strong></p>
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Email Address: &nbsp;'. $email.'</strong></p>
  
<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong>Your Account Is Active</strong><strong style=" color:Green;font:17px/44px calibri;"></strong></p>
 </div>

</body>
</html>
';

// Set content-type for sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
$headers .= 'From: dewlance@gmail.com>' . "\r\n";
$headers .= 'Cc:dewlance@gmail.com' . "\r\n";

// Send email
mail($to,$subject,$htmlContent,$headers);
		 






		     echo '<span style="color:green;" >Active</span> ';

		 }

		}else{

		$sql = "UPDATE tbl_doctors SET ur_status = '0' WHERE tbl_doctors.dr_id = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());

		if($re){

		    echo '<span style="color:red;" class="srnum">Inactive</span>';

		  }

		}

		}

		

		

		}else { echo 'failed';}

      }

   }
   



if($_POST['r']){

$r = $_POST['r'];
if($r == 'Showsearchd'){

echo'<div class="ser-op">
<select id="categoryByder">
<option value="0">Your City</option>';

$cat_fetc="SELECT PB.city_id, PB.city_name
FROM px_city AS PB
ORDER BY PB.city_id ASC";
$cat_querc=mysql_query($cat_fetc) or die(mysql_error());

while($mycat_rowc=mysql_fetch_array($cat_querc)){
   
   $der = $mycat_rowc['city_id'];
   


echo'<option value="'.$mycat_rowc[city_id].'">'.$mycat_rowc[city_name].'</option>';


  }
echo'</select>
            </div>
            <div class="ser-op">
<select id="categoryByrty">';

$cat_fet="SELECT PB.Category_id, PB.Category_name
FROM px_category AS PB
ORDER BY PB.Category_id ASC";
$cat_quer=mysql_query($cat_fet) or die(mysql_error());

while($mycat_row=mysql_fetch_array($cat_quer)){
   
   $derw = $mycat_row['Category_id'];
   
 $cat_fetIMG="SELECT catimgname FROM cat_img WHERE catgidFk='$derw' ORDER BY catimg desc LIMIT 1 ";
 $cat_querIMG=mysql_query($cat_fetIMG) or die(mysql_error());

 $mycat_rowimg=mysql_fetch_array($cat_querIMG);

 $frtg = $mycat_rowimg['catimgname'];


echo'<option value="'.$mycat_row[Category_id].'">'.$mycat_row[Category_name].'</option>';
  }

echo'</select></div>
			<div class="ser-op">
<select id="categoryByderffrtg">

<option value="0">Select Your Store</option>';


$cat_fet="SELECT PB.business_id, PB.business_name
FROM px_business AS PB
where PB.bs_city ='$der'
and PB.bs_cat = '$derw' 
ORDER BY PB.business_id ASC";
$cat_quer=mysql_query($cat_fet) or die(mysql_error());

while($mycat_row=mysql_fetch_array($cat_quer)){
   
   $derb = $mycat_row['business_id'];
echo'<option value="'.$mycat_row[business_id].'">'.$mycat_row[business_name].'</option>';
  }



echo'</select>
            </div>
            <div class="ser-op">
			<button class="btn1" id="searchDetail">Search</button>
            </div>';

}
}

if($_POST['r']){

$r = $_POST['r'];
if($r == 'showGiftDatas'){

echo'<div id="NewtownAreaPro"></div>
<div id="Newtownold">
<div class="gift-se">
			<div class="you-tube-sec">
			<h3>Special <span class="red"> GIFT </span> For you <br>every month!</h3>
   		
			<p style="padding-top:250px;"><a href="" style="color:#000;"><u>Comes to you from:</u></a></p>';
      
			$cat_fet="SELECT PB.Gid, PB.giftName, PB.sotre_urL,
				PXIMG.gimgid, PXIMG.gimgname
				FROM px_Gift as PB 
				INNER JOIN Gift_img as PXIMG on PB.Gid = PXIMG.gidFK 
				ORDER BY PB.Gid DESC 
				limit 0, 1";
          $cat_quer=mysql_query($cat_fet) or die(mysql_error());
         $mycat_row=mysql_fetch_array($cat_quer);			
			 
			echo'<h4 style="text-align:center;"><img src="http://miracitechnology.net/mybrochure/admin/images/'.$mycat_row[gimgname].'" style=""> </h4>
			<h4>To participate; just like our video on : </h4>
			<div align="center" class="ytubr"><a href="https://www.youtube.com/channel/UC1veOBIa7ILnXCYrwCBobRA">
			<img src="http://miracitechnology.net/mybrochure/images/you-button.png" alt=""/> </a></div>
            <p style="padding:0 40px;"> Check out our social media networks to know the winner </p>
            <div class="soci-med">
            <ul>
            <li><a href="https://www.facebook.com/mybrochure"><img src="http://miracitechnology.net/mybrochure/images/Facebook.png" alt=""/></a></li>
            <li><a href="https://twitter.com/My_Brochure"><img src="http://miracitechnology.net/mybrochure/images/Twitter.png" alt=""/></a></li>
            <li><a href="https://www.instagram.com/my_brochure"><img src="http://miracitechnology.net/mybrochure/images/Instagram.png" alt=""/></a></li>
            </ul>
            
             </div>

            
			
			
			</div>
</div>

</div>';

}

}

if($_POST['r']){

$r = $_POST['r'];
if($r == 'ShowStore'){
   
echo'<section id="store-sec">
 <ul style="list-style:none;">';

$cat_fet = "SELECT BS.business_id,BS.business_name, BS.business_address, BS.business_status,PC.Category_id, 
				PC.Category_name, PCI.city_id, PCI.city_name, PL.locality_id, PL.locality_name, PA.area_id, PA.area_name, 
				PA.area_pin FROM px_business BS INNER JOIN px_category as PC on BS.bs_cat = PC.Category_id 
				INNER JOIN px_city as PCI on BS.bs_city = PCI.city_id 
				INNER JOIN px_locality as PL on BS.bs_locality = PL.locality_id 
				INNER JOIN px_area as PA on BS.bs_area = PA.area_id" ;
$cat_quer = mysql_query($cat_fet) or die(mysql_error());

$i=0;
while($mycat_row = mysql_fetch_array($cat_quer)){
$i++;
$business_id = $mycat_row['business_id'];
$business_name = $mycat_row['business_name'];
$business_price = $mycat_row['business_price'];
$business_address = $mycat_row['business_address'];
$business_status = $mycat_row['business_status'];
$bs_cat = $mycat_row['Category_name'];
$bs_city = $mycat_row['city_name'];
$bs_locality = $mycat_row['locality_name'];
$bs_area = $mycat_row['area_name'];
$area_pin = $mycat_row['area_pin'];

$encodedcty_id = base64_encode($business_id);

$selImg = "select * from px_business_img where business_imgFK = '$business_id' LIMIT 1";
$selQry = mysql_query($selImg) or die(mysql_error());
$fetchDate = mysql_fetch_array($selQry);
$business_img_id = $fetchDate ['business_img_id'];
$business_img = $fetchDate ['business_img'];
$business_thumbnail = $fetchDate ['business_thumbnail'];
$business_imgFK = $fetchDate ['business_imgFK'];
$IMGfk = base64_encode($business_imgFK);


echo'<li style="width:46%; float:left; margin:8px 6px;">
<div class="store-item">

<a href="#" onClick="showStoreCatDtlfr('.$business_id.')"><img src="http://miracitechnology.net/mybrochure/admin/images/'.$business_img.'" alt="" ></a>
'.$business_name.' </div>
</li>'; 

}
echo'</ul>
</section>';
 
}
}


// For Showing The All Slider Imaeges In Dynamic

if($_POST['r']){

$r = $_POST['r'];
if($r == 'ShowSlider'){

	echo'<div class="container">
<section  id="banner-slide">

    <div id="owl-demo" class="owl-carousel owl-theme">
     
      <div class="item"><img src="http://miracitechnology.net/mybrochure/images/slide1.png" alt="first"></div>
      <div class="item"><img src="http://miracitechnology.net/mybrochure/images/slide2.png"  alt="second"></div>
      <div class="item"><img src="http://miracitechnology.net/mybrochure/images/slide3.png"  alt="third"></div>';
 
    $cat_fet="SELECT PB.Gid, PB.giftName, PB.sotre_urL, PXIMG.gimgid, PXIMG.gimgname
FROM px_Gift AS PB
INNER JOIN Gift_img AS PXIMG ON PB.Gid = PXIMG.gidFK
ORDER BY PB.Gid DESC
LIMIT 0 , 1";
$cat_quer=mysql_query($cat_fet) or die(mysql_error());

while($mycat_row=mysql_fetch_array($cat_quer)){
$dev = $mycat_row['sotre_urL'];
$devimg = $mycat_row['gimgname'];
}


       echo'<div class="item"><img src="http://miracitechnology.net/mybrochure/images/slide4.png"  alt="third">
      <p  class="shaukin"><img src="http://miracitechnology.net/mybrochure/admin/images/'.$devimg.'" alt="sadf"></p>
      </div>';
      
	     $cat_fets="SELECT PB.Gid, PB.giftName, PB.sotre_urL, PXIMG.sploid, PXIMG.splogoimg
FROM px_Gift AS PB
INNER JOIN spnsrLogo AS PXIMG ON PB.Gid = PXIMG.spidFk
ORDER BY PB.Gid DESC
LIMIT 0 , 1";
$cat_quers=mysql_query($cat_fets) or die(mysql_error());

while($mycat_rows=mysql_fetch_array($cat_quers)){
$devs = $mycat_rows['sotre_urL'];
$devimgs = $mycat_rows['splogoimg'];
}
      
          echo'<div class="item"><a href="all-catagoryoff.html"><img src="http://miracitechnology.net/mybrochure/images/slide5.png" alt="fif"></a>
      <p class="start-aid"><img src="http://miracitechnology.net/mybrochure/admin/images/'.$devimgs.'" alt="sta"></p>
      
      </div>
     
    </div>
  </section>
</div>';

echo'<script>


    $(document).ready(function() {
     
      $("#owl-demo").owlCarousel({
     
          navigation : true, // Show next and prev buttons
          slideSpeed : 300,
          paginationSpeed : 400,
          singleItem:true
     
          // "singleItem:true" is a shortcut for:
          // items : 1, 
          // itemsDesktop : false,
          // itemsDesktopSmall : false,
          // itemsTablet: false,
          // itemsMobile : false
     
      });
     
    });


</script>';

}
}



   // For Showing The All Slider Imaeges In Dynamic

if($_POST['r']){

$r = $_POST['r'];
if($r == 'ShowofferD'){

	$DelivDate = date('Y-m-d', strtotime("+3 days"));
 $SQAXa ="SELECT PB.business_id, PB.business_name, PB.business_status, PXIMG.business_imgFK, PXIMG.business_img, PXOf.ofid, PXOf.ofexpdate
             FROM px_business AS PB
             INNER JOIN px_business_img AS PXIMG ON PB.business_id = PXIMG.business_imgFK
             INNER JOIN offer AS PXOf ON PB.business_id = PXOf.ofFKidStr
			 where  PXOf.ofexpdate <= '$DelivDate'
			 GROUP BY PXOf.ofexpdate";
$ResDCs = mysql_query($SQAXa) or die( mysql_error());

echo'<ul class="ami">';

while($keys = mysql_fetch_array($ResDCs))
{ 
echo'<li>
<img id="'.$keys[business_id].'" src="http://miracitechnology.net/mybrochure/admin/images/'.$keys[business_img].'" alt="s">
<div class="broch">
<div class="b-left"><span>'.$keys[business_name].'</span></div>
<div class="b-right"><span>'.$keys[ofexpdate].'</span></div>
</div>
</li>';
}

echo'</ul>';

}
}



   // For Showing The All Category Into Dynamic Way

if($_POST['r']){

$r = $_POST['r'];
if($r == 'ShowAllCategoery'){

 $cat_fet="SELECT PB.Category_id, PB.Category_name
FROM px_category AS PB
ORDER BY PB.Category_id ASC";
$cat_quer=mysql_query($cat_fet) or die(mysql_error());
  while($mycat_row=mysql_fetch_array($cat_quer)){
   
   $der = $mycat_row['Category_id'];  
   echo'<input type="hidden" value="'.$der.'" class="grtcat" />';
 $cat_fetIMG="SELECT catimgname FROM cat_img WHERE catgidFk='$der' ORDER BY catimg desc LIMIT 1";
 $cat_querIMG=mysql_query($cat_fetIMG) or die(mysql_error());
  $mycat_rowimg=mysql_fetch_array($cat_querIMG);
   $frtg = $mycat_rowimg['catimgname'];

  echo'<a class="devimglink" href="#" onClick="showStoreCat('.$der.')">
  <img src="http://miracitechnology.net/mybrochure/admin/images/'.$frtg.'">
  <span class="allcat">'.$mycat_row[Category_name].'</span></a>';

  }
   }

}

    
  

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'logins'){

   
	      $username = mysql_real_escape_string(trim($_POST['username']));
		  $password = mysql_real_escape_string(trim($_POST['password']));

		//  $cityName = mysql_real_escape_string($_POST['cityName']);


		if( !empty($username)  && !empty($password) ){

		$protect = md5($password);

	  $sql = "SELECT * FROM admin WHERE user_email='$username' and ad_password='$protect';";

		$re = mysql_query($sql) or die( mysql_error());

		$fetch = mysql_fetch_array($re);
 
        $ad_name = $fetch['ad_name'];

		$FTCUnM = $fetch['user_email'];

		$pass =   $fetch['ad_password'];

		$AD_ID =   $fetch['ad_id'];

		  $num = mysql_num_rows($re);

		if($num == 1){

		   if( ($FTCUnM !=  $username) && ($pass !=  $protect ) ){

		     echo 'incorrect username and password .';	// for username and password incorect	   

		   }

		   

		   elseif(($FTCUnM !=  $username) && ($pass ==  $protect )){

		   

		   echo 'incorrect username .'; // for username incorect	

		   

		      }

			  

			  elseif(($FTCUnM ==  $username) && ($pass !=  $protect )){

			  

			  echo 'incorrect Password please try again.'; 

			   

		   }

		   elseif(($FTCUnM ==  $username) && ($pass ==  $protect )){

		        echo '111';

		     $_SESSION['Prix_email'] = $FTCUnM;

		     $_SESSION['Prix_pass'] = $pass;

			 $_SESSION['Prix_id'] = $AD_ID;
			 $_SESSION['txtloginName'] = $ad_name;

		   

		   }else{}

						

		}else{   echo 'incorrect username and password '; }

		

		 

    }

   

   }

  }
  
  
  
 // for Changing the Super Admin Password Here Password
 
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'ChangeADpass'){
 
     $Usename = mysql_real_escape_string(trim($_POST['Usename']));
     $CurrentPassword = mysql_real_escape_string(trim($_POST['CurrentPassword']));
     $NewPassword = mysql_real_escape_string(trim($_POST['NewPassword']));
     $NewPassworda = md5($NewPassword);
     $CurrentPassworda = md5($CurrentPassword);
     if( !empty($Usename) && ($Usename != 'undefined' ) && !empty($CurrentPassword) && !empty($NewPassword) ){
     	
     $sqlas = "SELECT ad_id FROM admin WHERE ad_password = '$CurrentPassworda'";
	  $resds = mysql_query($sqlas) or die( mysql_error());
	  $nuMS = mysql_num_rows($resds);
 
		if($nuMS>0){
	  $SLKJ = "UPDATE admin SET  
	  user_email = '$Usename',
	  ad_password = '$NewPassworda'
	  WHERE ad_id = '$_SESSION[Prix_id]'";
	  $resds = mysql_query($SLKJ) or die( mysql_error());
	  
	  if($resds){
	  	echo 'success';
	  }else { echo 'failed';}
	  
	   }else{  echo 'NotPass'; }
		}else { echo 'failed';}
      }

   }



  // for add cat

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'CatAdd'){

   

	     $catNamePro = mysql_real_escape_string(trim($_POST['catNamePro']));

	      

		//  $cityName = mysql_real_escape_string($_POST['cityName']);



	    

		if( !empty($catNamePro)){

	 

		$sql = "INSERT INTO cl_categories VALUES ('', '$catNamePro','' ,'1');";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();

		if($effect>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }

   // for city change to locality

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'ChangeCatTo'){

   

	   $ProductCatId = mysql_real_escape_string(trim($_POST['ProductCatId']));

	  

	    

		if(!empty($ProductCatId) ){

		$sql = "SELECT locality_id, locality_name FROM px_locality WHERE locality_FKcity = '$ProductCatId'";

		$re = mysql_query($sql) or die( mysql_error());

		$num = mysql_num_rows($re);

		if($num > 0){ //.data('daily-ss')

		echo '<select name="sltLocalityCatDyn" class="selectBox" id="sltLocalityCatDyn" onChange="LocalityArea();">';

		echo '<option value="0" data-daily-ss="not" >Select Zone </option>';

		while($fetched  = mysql_fetch_array($re)){

		$locality_id  = $fetched['locality_id'];

		$locality_name  = $fetched['locality_name'];

		echo '<option  value="'.$locality_id.'" data-daily-ss="'.$locality_name.'" >'.$locality_name.'</option>';

		}

		echo '</select>';

		

		

		}else { echo 'failed'; }

    }

   

   }

}

// for Locality change to area
if($_POST['r']){
$r = $_POST['r'];
	if($r == 'LocalityChangeToArea'){
	
	$LocalId = mysql_real_escape_string($_POST['LocalId']);
	
	if(!empty($LocalId)){
		
		 $sql = "SELECT area_id, area_name FROM px_area WHERE area_FkLocality = '$LocalId' ";
		 $AreaQry = mysql_query($sql) or die(mysql_error());
				 
		 $num = mysql_num_rows($AreaQry);
		 if($num > 0){
		 
	echo'<br><select id="AreaProNew" class="CatAddInput" name="AreaProNew" onchange = "GetAreaId();" >
 	<option value="0">Select Area</option>';
 		
		while($AreaFetch = mysql_fetch_array($AreaQry)){
 			$area_id = $AreaFetch['area_id'];
		 $area_name = $AreaFetch['area_name'];

  echo"<option  value='$area_id'> $area_name </option>";
 		} 
 echo'</select>';
		 }
	else{echo 'failed';}
		 
	}
	
	else{echo 'failed';}
	
	}
}



 // for cat change

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'ChangeSUBTo'){

   

	    $catIda = mysql_real_escape_string(trim($_POST['catIda']));

	      $subCatidd = mysql_real_escape_string(trim($_POST['subCatidd']));

	  

	    

		if(!empty($catIda) ){

		$sql = "SELECT pt_id,pt_name FROM cl_protype WHERE pt_cat_Fkid='$catIda' and pt_scat_Fkid='$subCatidd'";

		$re = mysql_query($sql) or die( mysql_error());

		$num = mysql_num_rows($re);

		if($num > 0){

		echo '<select name="typDynmc" class="selectBox" id="typDynmc">';

		echo '<option value="0">Product Type </option>';

		while($fetched  = mysql_fetch_array($re)){

		$sub_cat_id  = $fetched['pt_id'];

		$sub_cat_name  = $fetched['pt_name'];

		echo '<option  value="'.$sub_cat_id.'">'.$sub_cat_name.'</option>';

  	

		}

		echo '</select>';

		

		//if($sub_cat_name == 'Nose pins' || $sub_cat_name == 'Necklaces'){

//	   echo '<label for="nameCat" class="text_leble">Length of necklace </label>

//   	   <br />

//	   <input type="number" class="mod" name="quantity" min="1" max="30" value="9">

//       <br /><br />';

//		}

//		

	}else { echo 'failed'; }

    }

   

   }

 }


 
 // for search city wise
 
if($_POST['r']){

$r = $_POST['r'];

   if($r == 'SearchFilter'){
 
	   $CTYname = mysql_real_escape_string(trim($_POST['CTYname']));
	    $ContinentSel = mysql_real_escape_string(trim($_POST['ContinentSel']));

	  
		
if(!empty($CTYname) && empty($ContinentSel)){ 
 $sql = "SELECT CNT.Cnt_id,CNT.Cnt_name, PCT.city_id,PCT.city_name,PCT.Package1,PCT.Package2,PCT.Package3,PCT.Package4 
FROM continent as CNT 
INNER JOIN po_city as PCT on CNT.Cnt_id = PCT.Ct_fk_cpk
where PCT.city_name = '$CTYname'
";
}else if(!empty($ContinentSel) && empty($CTYname)){

 $sql = "SELECT CNT.Cnt_id,CNT.Cnt_name, PCT.city_id,PCT.city_name,PCT.Package1,PCT.Package2,PCT.Package3,PCT.Package4 
FROM continent as CNT 
INNER JOIN po_city as PCT on CNT.Cnt_id = PCT.Ct_fk_cpk
where CNT.Cnt_id = '$ContinentSel'
";
}else if(!empty($ContinentSel) && !empty($CTYname)){
 $sql = "SELECT CNT.Cnt_id,CNT.Cnt_name, PCT.city_id,PCT.city_name,PCT.Package1,PCT.Package2,PCT.Package3,PCT.Package4 
FROM continent as CNT 
INNER JOIN po_city as PCT on CNT.Cnt_id = PCT.Ct_fk_cpk
where CNT.Cnt_id = '$ContinentSel' and PCT.city_name = '$CTYname'
";
}
$sql_recat = mysql_query($sql) or die(mysql_error());
$sql_recatsd = mysql_query($sql) or die(mysql_error());
$num = mysql_num_rows($sql_recatsd);
 if($num>0){
 
		echo '<div class="view_table photoview">
		<ul class="headtable cityTable">
		<li>S.No.</li>
		<li>city</li>
		<li>Name</li>
		<li>Continent</li>
		<li>Package-1</li>
		<li>Package-2</li>
		<li>Package-3</li>
		<li>Package-4</li>
		<li>Edit</li>
		<li>Delete</li><div class="clear"></div>
		</ul>';

 
$i=0;
while($mycat_row=mysql_fetch_array($sql_recat)){
$i++;
$Cnt_id = $mycat_row['Cnt_id'];
$Cnt_name = $mycat_row['Cnt_name'];

$city_name = $mycat_row['city_name'];
$city_id = $mycat_row['city_id'];
$Package1 = $mycat_row['Package1'];
$Package2 = $mycat_row['Package2'];
$Package3 = $mycat_row['Package3'];
$Package4 = $mycat_row['Package4'];


echo '<ul class="bottomtable CTABLE" id="subdel-'.$city_id.'" >';
echo '<li> '.$i.' </li>';


 
$selsucat="SELECT city_image_id,city_image_name,city_image_thumbnail FROM po_city_images WHERE city_image_fk_ctid = '$city_id' LIMIT 1";
$quersubcat=mysql_query($selsucat) or die(mysql_error());
while($fetchsubcat=mysql_fetch_array($quersubcat)){
$city_image_id = $fetchsubcat['city_image_id'];
$city_image_name = $fetchsubcat['city_image_name'];
$city_image_thumbnail = $fetchsubcat['city_image_thumbnail'];

$encodedCTYt_id = base64_encode($city_id);
 



echo '<li>';
echo '<img src="images/'.$city_image_thumbnail.'" alt="" >';
echo '</li>
<li> '.$city_name.' </li>
<li> '.$Cnt_name.' </li>
<li> '.$Package1.' </li>
<li> '.$Package2.' </li>
<li> '.$Package3.' </li>
<li> '.$Package4.' </li>';
echo '<li><a href="add_city.php?edit='.$encodedCTYt_id.'"><img src="image/1438076866_editor_pencil_pen_edit_write_.png" style="width:auto; border-radius: inherit;"></a></li>
<li><a class="delbutton" href="#" id="'.$city_id.'"><img src="image/delete1.png"></a></li><div class="clear"></div>';

  } 
echo '</li>
<div class="clear"></div>
</ul>

</ul>';

  } 
echo '</div>';
		
	}else{ echo 'Result not found!';}	
		
		
		
	 

   

   }

}



  //  // for delete Business in Prixcom
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deletegiftImage'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		$sql = "DELETE FROM px_Gift WHERE Gid = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}
		
		 
    }
   
 



  //  // for delete Business in Prixcom
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteBusinessimgh'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		$sqlSelect = "SELECT banerid, banerName, banerthumb FROM px_business_baner WHERE banerid = '$Del_Id'";
		$reSelect = mysql_query($sqlSelect) or die( mysql_error());
		while($FetchImg = mysql_fetch_array($reSelect)){
		$business_img = $FetchImg['banerName'];
		$business_thumbnail = $FetchImg['banerthumb'];
		unlink('images/'.$business_img.''); 
		unlink('images/'.$business_thumbnail.''); 
		}
			 
		$sql = "DELETE FROM px_business_baner WHERE banerid = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }



  //  // for delete Business in Prixcom
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteBusinessDevd'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		$sqlSelect = "SELECT business_img_id, business_img, business_thumbnail FROM px_business_img WHERE business_imgFK = '$Del_Id'";
		$reSelect = mysql_query($sqlSelect) or die( mysql_error());
		while($FetchImg = mysql_fetch_array($reSelect)){
		$business_img = $FetchImg['business_img'];
		$business_thumbnail = $FetchImg['business_thumbnail'];
		unlink('images/'.$business_img.''); 
		unlink('images/'.$business_thumbnail.''); 
		}
			 
		$sql = "DELETE FROM px_business WHERE business_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	     echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }



  //  // for delete Business in Prixcom
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'DeleteOfferImg'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		$sqlSelect = "SELECT ofid, ofimg, ofimgthm FROM offer WHERE ofid = '$Del_Id'";
		$reSelect = mysql_query($sqlSelect) or die( mysql_error());
		while($FetchImg = mysql_fetch_array($reSelect)){
		$business_img = $FetchImg['ofimg'];
		$business_thumbnail = $FetchImg['ofimgthm'];
		unlink('images/'.$business_img.''); 
		unlink('images/'.$business_thumbnail.''); 
		}
			 
		$sql = "DELETE FROM offer WHERE ofid = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }

  //  // for delete city in Prixcom
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deletecat'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
		$sql = "DELETE FROM  px_city WHERE city_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }
   
   
  //  // for delete BlogPost
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteBLP'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
	 $sqlsDEL = "SELECT bl_img_id, bl_img_name,	bl_img_thumbnail FROM bl_post_images WHERE bl_img_FK = '$Del_Id'";
		$resssDEL = mysql_query($sqlsDEL) or die( mysql_error());
		while($FCHDEL = mysql_fetch_array($resssDEL)){
		$menu_img_name = $FCHDEL['bl_img_name'];
		$menu_thumbnail_img = $FCHDEL['bl_img_thumbnail'];
		unlink("images/".$menu_thumbnail_img); 
		unlink("images/".$menu_img_name); 
		}
	    $sql = "DELETE FROM  bl_post WHERE bl_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }
   
   
   //  // for delete locality in city
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteInsGp'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
	/* $sqlsDEL = "SELECT Ins_img_name, Ins_thumbnail_name FROM inspireimage WHERE Ins_Id = '$Del_Id'";
		$resssDEL = mysql_query($sqlsDEL) or die( mysql_error());
		while($FCHDEL = mysql_fetch_array($resssDEL)){
		$menu_img_name = $FCHDEL['Ins_img_name'];
		$menu_thumbnail_img = $FCHDEL['Ins_thumbnail_name'];
		unlink("images/".$menu_thumbnail_img); 
		unlink("images/".$menu_img_name); 
		}*/
	    $sql = "DELETE FROM  px_locality WHERE locality_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }
   

 //  // for delete area in locality in city
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteSubcat'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
		$sql = "DELETE FROM px_area WHERE  area_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }

 //  // for delete Blog Category
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteBlogCat'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
		$sql = "DELETE FROM  bl_category WHERE  BLC_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }

 //  // for delete category
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteSubcatdf'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
		$sql = "DELETE FROM px_category WHERE Category_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($re>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }
   
   
    //  // for delete category
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'testimonialdlt'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
	 
		$sql = "DELETE FROM px_testimonial WHERE px_testid = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($re>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
   
   }
   


//for Activate or deactivate the Testimonial by Admin

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'testimonialstatus'){

      $Idsds = mysql_real_escape_string(trim($_POST['GameId']));

    if( !empty($Idsds) && ($Idsds != 'undefined' ) ){

		$sqlSH = "SELECT px_testid,px_testatus FROM px_testimonial WHERE px_testid='$Idsds'";

		$reSH = mysql_query($sqlSH) or die( mysql_error());

		$nuMs = mysql_num_rows($reSH);

		$FRdt = mysql_fetch_array($reSH);

		if($nuMs>0){

		if($FRdt['px_testatus'] == 0){

		$sql = "UPDATE px_testimonial SET px_testatus = '1' WHERE px_testimonial.px_testid = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());

		if($re){

		    echo '<span style="color:green;" >Active</span> ';

		}

		}else{

		$sql = "UPDATE px_testimonial SET px_testatus = '0' WHERE px_testimonial.px_testid = '$Idsds'";

		$re = mysql_query($sql) or die( mysql_error());

		if($re){

		   echo '<span style="color:red;" class="srnum">Inactive</span>';

		 }

		}

		}

		
		}else { echo 'failed';}

      }

   }

// for insert city in Prixcom

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'insertmenus'){

   
			$cityName = mysql_real_escape_string(trim($_POST['cityName']));
	     
		if( !empty($cityName)){
		
		$sql = "INSERT INTO px_city VALUES ('', '$cityName', '1' )";

		 $re = mysql_query($sql) or die( mysql_error());
    	 $last_id =   mysql_insert_id();
		
		if($last_id>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }
   
    // for insert area in locality in city in Prixcom

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'insertArea'){

   
			$AreaName = mysql_real_escape_string(trim($_POST['AreaName']));
			$AreaPin = mysql_real_escape_string(trim($_POST['AreaPin']));
			$sltSubCatDyn = mysql_real_escape_string(trim($_POST['sltSubCatDyn']));
	     
		if( !empty($sltSubCatDyn) && !empty($sltSubCatDyn) && !empty($AreaPin)){
		
		$sql = "INSERT INTO px_area VALUES ('', '$AreaName', '$AreaPin', '$sltSubCatDyn' )";

		 $re = mysql_query($sql) or die( mysql_error());
    	 $last_id =   mysql_insert_id();
		
		if($last_id>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		}else { echo 'failed';}

    }
   }

 // for insert zone in city

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'insertadd_ons'){  

   
			$CitySelec = mysql_real_escape_string(trim($_POST['CitySelec']));
	       $localityName = mysql_real_escape_string(trim($_POST['localityName']));

		if(!empty($CitySelec) && !empty($localityName)){

		$sql = "INSERT INTO px_locality VALUES ('', '$localityName','$CitySelec')";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();
		 $last_id =   mysql_insert_id();
		// $encaprt = base64_encode($last_id);

		if($last_id>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }

 // for insert business

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'insertBusiness'){  
  

   
			$BusinessName = mysql_real_escape_string(trim($_POST['BusinessName']));
			$BusinessownerName = mysql_real_escape_string(trim($_POST['BusinessownerName']));
	       $CategoryPro = mysql_real_escape_string(trim($_POST['CategoryPro']));
		    $city = mysql_real_escape_string(trim($_POST['city']));
	       $zone = mysql_real_escape_string(trim($_POST['Locality']));
		   $area = mysql_real_escape_string(trim($_POST['area']));
	       $price = mysql_real_escape_string(trim($_POST['price']));
		   $address = mysql_real_escape_string(trim($_POST['address']));
	       $detail = mysql_real_escape_string(trim($_POST['detail']));
	        $email = mysql_real_escape_string(trim($_POST['email']));
	         $password = mysql_real_escape_string(trim($_POST['password']));
	          $Mobilen = mysql_real_escape_string(trim($_POST['Mobilen']));

		if(!empty($BusinessName) && !empty($CategoryPro) && !empty($city) && !empty($zone) &&
		 !empty($area) && !empty($price) && !empty($address) && !empty($email) && !empty($password)){

		$sql = "INSERT INTO px_business VALUES (NULL, '$BusinessName','$BusinessownerName','0', '$email', '$Mobilen' , '$password', '$price', '$address', '$detail','$CategoryPro', '$city', '$zone', '$area', '0', '0', '0')";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();
		 $last_id =   mysql_insert_id();
		 $encaprt = base64_encode($last_id);

		if($last_id>0){

		     echo $encaprt;

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }


 // for update locality in city

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'updatemenus'){

   $DecodeId = mysql_real_escape_string(trim($_POST['DecodeId']));
	       $CitySelec = mysql_real_escape_string(trim($_POST['CitySelec']));   
		   $localityName = mysql_real_escape_string(trim($_POST['localityName']));
		   

		if(!empty($DecodeId) && !empty($CitySelec) && !empty($localityName) ){
		
		$sql = "update px_locality set locality_name = '$localityName', locality_FKcity = '$CitySelec' where locality_id = '$DecodeId'";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();

		if($re>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }

  // for update area in locality in city

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'updateSubCategorys'){

   

	       $HDNEncide = mysql_real_escape_string(trim($_POST['HDNEncide']));

		    $AreaName = mysql_real_escape_string(trim($_POST['AreaName']));
		    $AreaPin = mysql_real_escape_string(trim($_POST['AreaPin']));

  

		if( !empty($HDNEncide) && !empty($AreaName) && !empty($AreaPin)){

	 	$sql = "UPDATE px_area SET area_name = '$AreaName', area_pin = '$AreaPin' WHERE  area_id ='$HDNEncide'";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();

		if($re>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

		

		 

    }

   

   }
   
 // for update business

if($_POST['r']){

$r = $_POST['r'];

   if($r == 'updateBusiness'){ 

	       $HDNIDEcode = mysql_real_escape_string(trim($_POST['HDNIDEcode']));

		    $BusinessName = mysql_real_escape_string(trim($_POST['BusinessName']));
		    $CategoryPro = mysql_real_escape_string(trim($_POST['CategoryPro']));
			$PriceBusin = mysql_real_escape_string(trim($_POST['PriceBusin']));
			$packNamePro1 = mysql_real_escape_string(trim($_POST['packNamePro1']));
			$PostDetail = mysql_real_escape_string(trim($_POST['PostDetail']));

		if( !empty($HDNIDEcode) && !empty($BusinessName) && !empty($CategoryPro) && !empty($PriceBusin) && !empty($packNamePro1) && !empty($PostDetail)){

	 	$sql = "UPDATE px_business SET business_name = '$BusinessName', business_price = '$PriceBusin', business_address = '$packNamePro1', business_detail = '$PostDetail', bs_cat = '$CategoryPro' WHERE  business_id ='$HDNIDEcode'";

		$re = mysql_query($sql) or die( mysql_error());

		$effect =  mysql_affected_rows();

		if($re>0){

		     echo 'success';

			 }else{  echo 'failed'; }

		

		}else { echo 'failed';}

    }

   

   }
   
 //  // for delete Business images
 
 
 if($_POST['r']){
$r = $_POST['r'];
   if($r == 'Adddgift'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		
	 	$sqls = "SELECT MAX( Gid ) FROM px_Gift";
		$resss = mysql_query($sqls) or die( mysql_error());
		$FCH = mysql_fetch_array($resss);
		$gids = $FCH['MAX( Gid )'];
		
	    $sql = "INSERT INTO winner VALUES (NULL, now(), '$Del_Id', '$gids')";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 }
    }
	
	
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteMenuIMG'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		
		$sqls = "SELECT business_img_id, business_img, business_thumbnail FROM px_business_img WHERE business_img_id = '$Del_Id'";
		$resss = mysql_query($sqls) or die( mysql_error());
		$FCH = mysql_fetch_array($resss);
		$menu_img_name = $FCH['business_img'];
		$menu_thumbnail_img = $FCH['business_thumbnail'];
		unlink("images/".$menu_img_name); 
		unlink("images/".$menu_thumbnail_img); 
	    $sql = "DELETE FROM  px_business_img WHERE  business_img_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 }
    }

	
	 //  // for delete BlogPost images
    
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'deleteBlogIMG'){
 
 	     $Del_Id = mysql_real_escape_string(trim($_POST['del_id']));
	     
		if( !empty($Del_Id)){
		
		$sqlsDEL = "SELECT bl_img_id, bl_img_name,	bl_img_thumbnail FROM bl_post_images WHERE bl_img_id = '$Del_Id'";
		$resssDEL = mysql_query($sqlsDEL) or die( mysql_error());
		$FCHDEL = mysql_fetch_array($resssDEL);
		$menu_img_name = $FCHDEL['bl_img_name'];
		$menu_thumbnail_img = $FCHDEL['bl_img_thumbnail'];
		unlink("images/".$menu_thumbnail_img); 
		unlink("images/".$menu_img_name); 
		
	    $sql = "DELETE FROM  bl_post_images WHERE bl_img_id = '$Del_Id'";
		$re = mysql_query($sql) or die( mysql_error());
		$effect =  mysql_affected_rows();
		if($effect>0){
	    echo 'success';
		}else{  echo 'failed'; }
		
		}else { echo 'failed';}
		
		 
    }
	
   
   }
   
  
  //for send order in
if($_POST['r']){
$r = $_POST['r'];
   if($r == 'OrderSend'){   
	  $GetIdsx = explode("," ,$_POST['GetIdsx']);
	  $GetName = explode("," ,$_POST['GetName']);
	  $GetQnt = explode("," ,$_POST['GetQnt']);
	  $Price = explode("," ,$_POST['Price']);
	  
	  $Addresxs =  trim($_POST['AddressNew']);
	  $DelivDate =  trim($_POST['NewDatein']);
	  $commentSMsg =  trim($_POST['commentSMsg']);
	  
	  $orderStatus = $_POST['orderStatus'];
	  $Allarray = array("GetId"=>$GetIdsx,"GetName"=>$GetName,"GetQnt"=>$GetQnt,"Price"=>$Price);
	  
	  //	$Addresxs = $_SESSION['AddressAX'];
		//$DelivDate = 
		 $_SESSION['orderDate'] = $DelivDate;
	 // print_r($Allarray);
	 // print_r(array_merge_recursive($GetIdsx,$GetName,$Price));
	   $JsonESX = json_encode($Allarray);
	   
	   $SQXs = "SELECT menu_id, menu_price FROM ro_menu WHERE menu_id in ($_POST[GetIdsx])";
	   $QXSA = mysql_query($SQXs) or die( mysql_error());
	   while($FeTX = mysql_fetch_array($QXSA)) {
	   	$PriceDb[] = $FeTX['menu_price'];
	   }

	if( !empty($GetIdsx) &&  !empty($GetName)){
		

		  $Emails = $_SESSION['SportsmUrId'];
		  $Name = $_SESSION['CustomUername'];
 		  $CustomMobile = $_SESSION['CustomMobile'];
		  $location = $_SESSION['location'];
		  $city = $_SESSION['city'];
		  $REs = "SELECT or_ids FROM ro_orders order by or_ids desc limit 1";
		  $resds = mysql_query($REs) or die( mysql_error());
		  $ferd = mysql_fetch_array($resds);
		  $orderNum = $ferd['or_ids']+1;
		  $cityLoc = $_SESSION['citys'];
		  $LOcatr = $_SESSION['locl'];

		 
	$message  = '<html><body>';
	$message .= '<div class="c-form" style="width:600px;margin:0 auto;padding:30px 20px;border-radius:10px; border:1px solid #999;">';
 	$message .= '<img src="http://dillifresh.com/images/Graphic1.png" alt="logo">';
	$message .= '<p style="font:14px calibri;color:#333;margin:12px 0; "></p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Name: &nbsp;</strong>'.strip_tags($Name).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Mobile: &nbsp;</strong>'.strip_tags($CustomMobile).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Location: &nbsp;</strong>'.strip_tags($LOcatr).' &nbsp; ,'.strip_tags($cityLoc).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Address: &nbsp;</strong>'.strip_tags($Addresxs).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Order Date & Time: &nbsp;</strong>'.strip_tags(date("F j, Y, g:i a")).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Delivery Date & Time: &nbsp;</strong>'.strip_tags($DelivDate).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Order No: &nbsp;DF-</strong>'.strip_tags($orderNum).'</p>';
	$message .= '<p style="font:14px/44px calibri;border-bottom: 1px solid #eee;margin:0 0 0 30px; border-top:1px solid #eee;"><strong> Comment: &nbsp;</strong>'.strip_tags($commentSMsg).'</p>';
 	$message .= '<table style="width: 100%; border-collapse: collapse;"  class="tableClassREs">
  	<tr>
    <th style="background: #333; color: white; font-weight: bold;" scope="col">Item Name</th>
    <th style="background: #333; color: white; font-weight: bold;" scope="col">Quantity</th>
    <th style="background: #333; color: white; font-weight: bold;" scope="col">Price</th>
    </tr>';
   
for ($i = 0; $i < count($GetName); ++$i) {
	if(!empty($GetQnt[$i])) {
      $message .= '<tr>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: centre;">&nbsp;'.$GetName[$i].'</td>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: centre;">&nbsp;'.$GetQnt[$i].'</td>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: centre;">&nbsp;'.$Price[$i].'</td>';
	$message .= '</tr>';
	}
	$ToTS[] = ($PriceDb[$i] * $GetQnt[$i]);
	}   
     $message .= '<tr>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: left;">&nbsp; </td>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: right; font-weight:bold;">&nbsp;Total Amount </td>';
    	$message .= '<td style="padding: 6px;  border: 1px solid #ccc; text-align: left;font-weight:bold;">&nbsp;'.array_sum($Price).'</td>';
	   $message .= '</tr>';

   $message .= '</table>';
	$message .= "</body></html>";

	
	   		//CHANGE THE BELOW VARIABLES TO YOUR NEEDS
	   	$From = 'dillifreshorder@gmail.com';
         $to = $Emails;//'manmohan@sigmawebsolutions.com';
			$to .= ','.$From;
			$subject = 'I AM DILLI FRESH Your Order Has Been Placed Thanks !';
			$headers = "From: " . $From . "\r\n";
			$headers .= "Reply-To: ". strip_tags($From) . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		 
  if(mail($to, $subject, $message, $headers)) {
  echo 'yes';//'Your message has been sent.';
  $Sqlzz = "INSERT INTO ro_orders (or_ids, or_unameIDs, or_allDetails, or_datetime, or_delivarytime, or_address, or_paystatus, or_status	)
  		 VALUES ('','$_SESSION[CustomUserid]','$JsonESX',NOW(),'$DelivDate','$Addresxs','1','1')";
  		  $re = mysql_query($Sqlzz) or die( mysql_error());
  	
            } else {
              echo 'faileds'; // mail not sent
            }	  
	 	   
	  }else{
	  echo 'failed';
	  }
   }	  
}		  
 

?>