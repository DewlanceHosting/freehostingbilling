<?php  include('fn/connect.php');
//$q = intval($_GET['q']);

 $q =  $_POST['state1'];
 $content = "SELECT * FROM  city  where stateid='$q'";
					  $cat_quer = mysqli_query($con,$content) ;
					  $cont=mysqli_num_rows($cat_quer); 
					  if($cont>0){?><option value="0">Select City</option><?php 
					while($mycat_row = mysqli_fetch_array($cat_quer)){
					?>
                    <option value="<?php echo $mycat_row['id']; ?>"><?php echo $mycat_row['city']; ?></option>
					
					<?php }} else {?>
                     <option value="0">No City Found</option><?php }?>

					