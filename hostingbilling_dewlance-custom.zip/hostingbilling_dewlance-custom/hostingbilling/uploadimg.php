<?php  include_once('fn/connect.php');
 
 
if(is_array($_FILES)) {
if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {

  $Subject=$_POST['Subject'];
$Department=$_POST['Department'];
$Priority=$_POST['Priority'];
$content=$_POST['content'];
 date_default_timezone_set("Asia/Kolkata");
$cdatetime =  date('d-m-Y h:i:s a');
$sourcePath = $_FILES['userImage']['tmp_name'];
$targetPath = "images/".$_FILES['userImage']['name'];

if(move_uploaded_file($sourcePath,$targetPath)) {

 $seed = str_split('OPQRSXTUVWXYZABABCDXEFGHIJKLMXNCDXEXXFGHXIJKLMN'.'ABCDXEFGXHIJKLMNABCXXDEXFGXHIJXXKLMNOPQRSTUVWXYZ'.'0123456789'); // and any other characters
     shuffle($seed); // probably optional since array_is randomized; this may be redundant
     $uniqCode = '';
     foreach (array_rand($seed, 8) as $k) $uniqCode .= $seed[$k]; 
		  $uniqCode;
		$insert_query = "INSERT INTO `ticket_sale` (`subjec`, `depname`, `priority`, `pro_massage`, `image`, `ticketnumber`, `status`, `cdatetime`) 
												VALUES ('$Subject', '$Department', '$Priority', '$content', '$sourcePath', '$uniqCode', '0','$cdatetime')";
		$run = mysqli_query($con,$insert_query);
		if($run) {
		echo " Department = ".$Department." Subject = ".$Subject." Content = ".$content." Data Stored"; 
	 }
	 
?>
<img class="image-preview" src="<?php echo $targetPath; ?>" class="upload-preview" />
<?php
}
}
}
 
 
 
 
 ?>