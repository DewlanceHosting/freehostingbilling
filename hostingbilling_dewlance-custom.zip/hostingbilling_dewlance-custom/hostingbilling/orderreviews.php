 <?php   session_start();  // error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}
 
 
 if(isset($_GET['1'])){
   $_SESSION["cardvalue"] = $_SESSION["cardvalue"] + $_SESSION["num"]; 
  
  $_SESSION["num"]='0';
			}
 /* 1=<?php echo base64_encode($userdetails->{'name'}) ?>//&did=<?php echo base64_encode( $ProducName['producid']) ?>&prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>&bill=<?php echo  $ProducName['billtype']; */
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata");  ?>
  
  <!--headerpart-end--> 
<?php $pdata1=base64_decode($_GET['did']); $queryProduc = mysqli_query($con,"SELECT * FROM `productadd` where producid='$pdata1'"); $ProducName =mysqli_fetch_array($queryProduc);   $ProducName['price']; ?>
<section class="clientdashh">
<div class="container">
<div class="listservisdata">
<div class="row">
<div class="col-sm-8">
<?php  if(!empty($_GET['don']) ){   ?>
<div class="listservisdata">
<h3>Order Review</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th><h3>Product</h3></th>
      <th><h3>Price</h3></th>
    </tr>
  </thead>
  <tbody>
  <?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>

   <?
//if(isset($_POST['1'])){ 
    $uds =  base64_decode($_GET['1']);
    $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
          $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
// echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		  //print_r($json);
         // echo "[+] Current cPanel users on the system:\n";
       foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            if($userdetails->{'name'} == $uds){
		 
           
?>
      <tr>
      <td>
      <h4 style="font-size:17px;">Domain Registration  &nbsp; &nbsp;<span><a href="hosting-category.php?prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>"><i class="fa fa-pencil"></i> Edit</a></span></h4>
      <h5 style="font-size:14px; margin:7px 0 0;"><a href="#"><?php echo base64_decode($_GET['don']); ?></a></h5>
      </td>
      <td>
      <h4 style="font-size:18px;"><!--<i class="fa fa-usd"></i>--> &dollar; <?php  echo $pricedomain= base64_decode($_GET['prs']); ?>  &nbsp; &nbsp;<span ><a href="orderreviews.php?1=<?php echo base64_encode($userdetails->{'name'}) ?>&did=<?php echo base64_encode( $ProducName['producid']) ?>&bill=<?php echo  $ProducName['billtype']; ?>" style="color:#FF0000;"> Delete <i class="fa fa-times"></i></a></span></h4>
      <h5  style="font-size:14px; margin:7px 0 0;">Register for : 1 Year</h5>
      
      </td>
    </tr>
     <?php  }  } //}
    } 
    curl_close($curl);
	
	?>
     
  </tbody>
</table>
</div>

</div>
<?php }?>
 
<?php // else{} ?>

</div>


<div class="col-sm-4">
<div class="odrsummry-sec">
<h4>Order Summary</h4>
<div class="odrdataa">
<div class="row"><?php   $pricestotal = $pricedomain + $ProducName['price']; ?>
<div class="col-xs-5"><h5>Price</h5></div>
<div class="col-xs-7"><h5 class="pull-right">&dollar; <?php  echo $pricestotal; ?> INR</h5></div>
</div>
<hr />
<div class="row">
<div class="col-xs-5"><h6>Package Name :</h6></div>
<div class="col-xs-7"><h6 class="pull-right"><strong>  <?php echo base64_decode($_GET['1']); ?></strong></h6></div>
</div>


<div class="totllse">
<h2>&dollar; <?php  echo $pricestotal;  ?> </h2>
<h5>Total Due Today</h5>
</div>
<div class="clearfix"></div>
<form action="checkoutfinal.php" method="POST">
<input type="hidden" name="1" value="<?php echo 'Package Name = '.$userdetails->{'name'}.' , '.'Bill Type= '.$_GET['bill'];?>">
<input type="hidden" name="did" value="<?php echo $ProducName['producid']; ?>">
<input type="hidden" name="prs" value="<?php echo  $pricestotal; ?>">
<input type="hidden" name="don" value="<?php echo $_GET['don']; ?>">
<input type="hidden" name="select_cycles" value="<?php echo $pricestotal; ?>"> 
<input type="hidden" name="bill" value="<?php  echo $_GET['bill'];  ?>">
  <button type="submit" name="submit" class="btn btn-success btn-lg">Check Out</button> 
 
   </form>
   <?php
// Set session variables
  $_SESSION["palanname"] = base64_decode($_GET['1']);
  $_SESSION["palan_amt"] = $ProducName['price'];
  $_SESSION["domainname"] = base64_decode($_GET['don']);
  $_SESSION["domain_amt"] = base64_decode($_GET['prs']);
  $_SESSION["proId"] = base64_decode($_GET['did']);
  $_SESSION["bill"] = $_GET['bill'];
  $_SESSION["total"] = $pricestotal; 
  $_SESSION["userid"];  
 
?>
  <!-- <form action="process.php" method="POST">
                        
                            <input type="hidden" id="select_plan" name="select_plan" value="Daily"> 
                        
                            <input type="hidden" id="select_cycles" name="select_cycles" value="23">
                                 
                        <button type="submit" name="submit" class="btn btn-success btn-lg">Check Out</button> 
                    </form>-->
   </div> 
</div>
</div> 
</div> 

</div> 

</div>

</section> 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>