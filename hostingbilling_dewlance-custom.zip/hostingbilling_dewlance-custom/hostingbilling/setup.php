<form id="myContainer" method="post" action="/checkout"></form>

<script>
   window.paypalCheckoutReady = function () {
     paypal.checkout.setup('seller@dewlance.com', {
         environment: 'sandbox',
         container: 'myContainer'
       });
  };
</script>

<script src="https://www.paypalobjects.com/api/checkout.js" async></script>