   
<?php  session_start();
include_once('fn/connect.php');

 if(isset($_GET['did']) && ($_GET['1'])){
    $First = base64_decode($_GET['First']); 
      $did = base64_decode($_GET['did']); 
   $prs = base64_decode($_GET['prs']); 
   $don = base64_decode($_GET['don']); 
   $plan_name = base64_decode($_GET['1']); 
$transectiondate = date('d-m-Y'); 
$oderid = mt_rand(100000, 999999);
  $transactionid='TID'.$oderid;

 echo $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);  
     $Paytoo= mysqli_query($con,"SELECT * FROM `company_detailadd`"); $rowDet = mysqli_fetch_array($Paytoo);
//$oderid=uniqid(); 
//$Password = $md5($_POST['Password']);  
 $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
 
		 	$insert_query = "INSERT INTO `user_hostingpay`(`producid`,`user_rid`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '$plan_name','$transectiondate', '$oderid', '$transactionid', 'Paytm', '$prs')";
	  
		$run = mysqli_query($con,$insert_query);
		if($run) {
	 echo "Invoice Create sucsessfully created"; 
		 $insert_query1 = "INSERT INTO `user_domainpay`(`producid`,`user_rid`, `domain_name`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '$don', '$plan_name','$transectiondate', '$oderid', '$transactionid', 'Paytm', '$prs')";
	 mysqli_query($con,$insert_query1);
		$to = $Email;
$subject = "Thanks For Hosting";
$txt = "Hello - " .$First." ".$Last." Thanks For Get Hosting";
$headers = "Hello - " .$First." ".$Last." Thanks For Get Hosting ";

mail($to,$subject,$txt,$headers);
echo "<script>alert('Invoice Create')</script>";
		echo "<script>window.open('hostingpayment.php','_self')</script>";
		}
		 } else{ 
		 
  $First = base64_decode($_GET['First']); 
    $did = base64_decode($_GET['did']); 
  $prs = base64_decode($_GET['prs']); 
  $don = base64_decode($_GET['don']); 
  $plan_name = base64_decode($_GET['1']); 
$transectiondate = date('d-m-Y'); 
$oderid = mt_rand(100000, 999999);
 $transactionid='TID'.$oderid;
//$oderid=uniqid(); 
//$Password = $md5($_POST['Password']);  
 $userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
 
			 $insert_query = "INSERT INTO `user_domainpay`(`producid`,`user_rid`, `domain_name`, `plan_name`, `transectiondate`,`oderid`, `transactionid`, `paymethod`, `total`)
	 VALUES ('$did','$userR', '$don', '0','$transectiondate', '$oderid', '$transactionid', 'Paytm', '$prs')";
		$run = mysqli_query($con,$insert_query);
		if($run) {
		 echo "Invoice Create sucsessfully created";  
		$to = $Email;
$subject = "Thanks For Hosting";
$txt = "Hello - " .$First." ".$Last." Thanks For Get Hosting";
$headers = "Hello - " .$First." ".$Last." Thanks For Get Hosting "; 

mail($to,$subject,$txt,$headers);
echo "<script>alert('Invoice Create')</script>";
		echo "<script>window.open('hostingpayment.php','_self')</script>";
		} 
 }
		  ?> 
          
 <?
include_once('fn/connect.php');  //Product: Product, Domain: Domain, cpuser: cpuser, Billing: Billing ?>
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; 

////<!-----------------------1--------Creat User in cPenal process-------------------------------------->

 if(isset ($_POST['unsusname'])){ 
 $unsusname = $_POST['unsusname'];
 $oldpass = $_POST['oldpass'];
 $newpass = $_POST['newpass'];
   $user = "root";
    $token = $rowc['apikdy'];
 
    $query = "https://$stval/json-api/cpanel?cpanel_jsonapi_user=user&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=Passwd&cpanel_jsonapi_func=change_password&oldpass=$oldpass&newpass=$newpass&user=$unsusname";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
    $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		//print_r($json);
        echo "User Unsuspend";
        foreach ($json->{'data'}->{'acct'} as $userdetails) {
            echo "\t" . $userdetails->{'user'} . "\n";
        }
    }
 
    curl_close($curl);
	
} ?>



 