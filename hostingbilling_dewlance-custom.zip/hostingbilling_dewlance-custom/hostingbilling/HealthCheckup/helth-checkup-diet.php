

<!doctype html>

<html>

<head>

<meta charset="utf-8">

<title>helth-checkup-diet</title>



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link href="../css/font-awesome.min.css" rel="stylesheet">

<link href="../css/custom.css" rel="stylesheet">

<link href="../css/menu.css" rel="stylesheet">

<link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>



 <!-- Javascript -->

      <script>

         $(function() {

            $( "#datepicker-8" ).datepicker({

               prevText:"click for previous months",

               nextText:"click for next months",

               showOtherMonths:true,

               selectOtherMonths: false

            });

            $( "#datepicker-9" ).datepicker({

               prevText:"click for previous months",

               nextText:"click for next months",

               showOtherMonths:true,

               selectOtherMonths: true

            });

         });

      </script>



</head>



<body>

<?php  include('header.php');?>

<div style="background:none;" class="content">

<div class="container">

<div class="row">

<div class="col-md-3">

<ul id="nav">

<h5>HELTH CHECKUP</h5>

<li><a href="#">master Setup<i style="float:right; font-size:16px;" class="fa fa-angle-right"></i></a>

<ul class="subs">

    <li><a href="helth-checkup-impression-master.php">impression master</a></li>

    <li><a href="helth-checkup-diet.php">diet master</a></li>

</ul></li>

   <li><a href="helth-checkup-helth-checkup.php">helth checkup</a></li>

</ul>

</div>

<div class="col-md-9">

<div class="trip">Diet Master</div>

<br>

<form>



<div class="row">

<div class="col-md-4">

<input type="text" class="form-control" placeholder="Diet ID" required>

</div>

<div class="col-md-4">

<input type="text" class="form-control" placeholder="Diet Name" required>

</div>

<div class="col-md-4">

<select required class="form-control"><option value="">Select Status</option><option value="">Active</option><option value="">In-active</option></select>

</div>

</div>

<br>

<br>

<div class="pull-right">

<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>

<button type="reset" class="btn btn-primary"><i class="fa fa-repeat"></i> Reset</button>

<button type="reset" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>

</div>

</form>

<br>

<br>

<table class="table table-bordered">

  <thead>

<tr style="background:#f1f1f1; border-top:2px solid #356b96;">

<th>Edit</th>

<th>Dite Name</th>

<th>Status</th>

</tr>

</thead>

<tbody>

<tr>

<td><i class=" fa fa-pencil"></i></td>

<td>Shaukin</td>

<td>Acvive</td>

</tr>

  </tbody>

</table>

</div>

</div>

</div>

</div>

</div>



<?php include_once('../footer.php'); ?>













 <!-- Modal -->

  <div class="modal fade" id="myModal" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div style="margin-top:20%;" class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">Search Impression Format</h4>

        </div>

        <div class="modal-body">

          <div class="input-group">

<input type="text" class="form-control" placeholder="Impression Name" required>

<span class="input-group-addon"><i style="cursor:pointer;" class="fa fa-search"></i></span>

</div>

        </div>

<div class="table-responsive dctrapoin">

<table class="table table-bordered">

  <thead>

<tr>

<th>No Record Found</th>

<th></th>

<th></th>

<th></th>

</tr>



</thead>

<tbody>

<tr>

<td></td>

<td></td>

</tr>

                          

  </tbody>

</table>





</div>

        

      </div>

      

    </div>

  </div>



</body>



</html>





