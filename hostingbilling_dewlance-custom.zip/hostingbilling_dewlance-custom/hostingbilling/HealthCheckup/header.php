<?php include_once('../fn/connect.php'); ?>
 <div class="header-top">
<div class="container">
<div class="row">
<div class="col-md-6">
<ul>
<li><a href="../home.php">Home</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Logout</a></li>
<li><a href="#">Help</a></li>
</ul>
</div>

<div class="col-md-3">
<div class="languagee_sec">
<label>Language </label>
<select><option>Select Language</option><option>English</option><option>Hindi</option></select>
</div>
</div>
<div class="col-md-3">
<div class="user_welcom pull-right">
<h4>Welcome : <span> Frontdeskg dfsvfsdf</span> </h4>
</div>
</div>

</div>

</div>
</div>

<header id="setheaderhospital">
<div class="container">
<div class="row">
<div class="col-md-6">
<div class="logosec_hosp"><img src="../images/hwlogo.png" alt="img"></div>
</div>
<div class="col-md-6 text-right">
<h5>the address xyz</h5>
<h5><span>Example@gmail.com</span></h5>
</div>
</div>
</div>
</header> 

