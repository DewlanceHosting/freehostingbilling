 <?php  session_start();   error_reporting(0); // if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-markdown.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-markdown.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    
<script type="text/javascript">
$(document).ready(function (e){
$("#uploadForm").on('submit',(function(e){
//alert();
e.preventDefault();
$.ajax({
url: "uploadimg.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
success: function(data){
//alert(data);
$("#targetLayer").html(data);
 alert(targetLayer);
},
error: function(){} 	        
});
}));
});
</script>
<script>
function SubmitFormData() { 
    var usr = $("#usr").val();  //alert(usr);
    $.post("tic.php", { usr: usr },
    function(data) {
	 $('#results').html(data);
	// alert(results);
	 $('#myForm')[0].reset();
    });
}
</script>
  </head>
  <body>
  
  <!--<div class="header">
    <nav class="navbar navbar-top">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo"></a>
        </div>
        <div class="navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li><a href="">Cart (<span style="color:#f00">0</span>)</a></li>
             <li><a href="">Logout</a></li>
            
          </ul>
        </div><!--/.nav-collapse  
      </div>
    </nav>
    <nav class="navbar navbar-default">
      <div class="container">
      <div class="row">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <!-- <a class="navbar-brand" href="#">Project name</a> 
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class=""><a href="index.php">Portal Home</a></li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Services <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="services.php">Hosting Services</a></li>
                
              </ul>
            </li>
           <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Domains <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="mydomain.php">For Domain Management</a></li>
               
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Billing <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="invoice.php">Invoice</a></li>
               
              </ul>
            </li>
            
           <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Support <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="openticket.php">Open Ticket</a></li>
                <li><a href="existingticket.php">Existing Ticket</a></li>
               
              </ul>


            </li> 
            
            
            <li class="dropdown menu">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">My Account <span class="caret"></span></a>
              <ul class="dropdown-menu menu1">
                <li><a href="myaccount.php">Modify Account</a></li>
                <li><a href="changepassword.php">Change Password</a></li>
                 <li><a href="securityquestion.php">Security Question</a></li>
              </ul>
            </li>
            
          </ul>
          
        </div><!--/.nav-collapse  
      </div>
      </div>
    </nav>
  </div>-->
    <?php include_once("header.php"); ?>
  <!--headerpart-end--> 
  
<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Open Ticket</h3>
 <?php   $namme=base64_decode($_GET['1']);?>
 
<div class="editrform">
<form id="uploadForm" action="upload.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="Subject">Subject</label>
      <input type="text" class="form-control" name="Subject" id="usr" onChange="SubmitFormData();">
    </div>
    <div id="results" style="color:#009999"></div>
    <div class="row">
    <div class="form-group col-sm-6">
      <label for="Subject">Department</label>
      <select class="form-control" id="" name="Department"><option><?php echo $namme; ?></option>
      <?php $dparque=mysqli_query($con,"SELECT * FROM `add_ticket_depart`"); while($rowdepr=mysqli_fetch_array($dparque)){ ?> 
       <option><?php echo $rowdepr['name']; ?></option>
       <?php }?>
      </select>
    </div>
    <div class="form-group col-sm-6">
      <label for="Subject">Priority</label>
     <select class="form-control" name="Priority" id="">
      <option>select</option>
       <option>Medium</option>
      </select>
    </div> 
    </div> 
    
    <div class="form-group">
      <label for="Message">Message</label>
   <textarea name="content" data-provide="markdown" rows="8" ></textarea>
    </div> 
    
    <div class="row">
    <div class="form-group col-sm-8">
      <label for="Attechment">Attechment</label>
      <input name="userImage" type="file" class="inputFile" /> 
    </div>
    <div class="form-group col-sm-4">
    
<p class="btn btn-primary form-control">Add More</p>
    </div>
    <div id="targetLayer" style="height:100px; width:100px;">No Image</div>
    </div> 
     
     <div class="form-group">
    <br><br>
<center>
<button type="submit" class="btn btn-danger" >Submit</button>
<button type="reset" class="btn btn-default">Cancel</button>
</center>
    </div>
    
  </form>

</div> 
</div>
</div>
</div> 
</div>

</section>

 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>