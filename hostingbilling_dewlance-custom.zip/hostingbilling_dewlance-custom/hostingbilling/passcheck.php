<?php  session_start();  include_once('fn/connect.php');?>
 
<script>$('#password, #confirm_password').on('keyup', function () {
  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('Matching').css('color', 'green');
  } else 
    $('#message').html('Not Matching').css('color', 'red');
});</script>

<?php if(isset($_POST['Old'])){
 $uName = $_SESSION['userid'];
 $passworkd = $_POST['Old'];
$pWord = md5($_POST['Old']);
$qry = "SELECT * FROM user_ragistration WHERE id='".$uName."' AND userpass='".$pWord."' AND status='1'";
$res = mysqli_query($con,$qry);
$num_row = mysqli_num_rows($res);
$row=mysqli_fetch_assoc($res);
if( $num_row == 1 ) { ?>
 <label for="Password">Old Password :</label>
	 <input type="password" class="form-control" id="Old" value="<?php echo $passworkd; ?>" onChange="OldPassData();">
 <span style="color:#9F9800;">Password Match</span>
 <div class="form-group">
    <label for="Password">New Password :</label>
    <input class="form-control" name="password" id="password" type="password">
  </div>

<div class="form-group">
    <label for="Password">Confirm Password :</label>
    <input class="form-control" type="password" name="confirm_password" id="confirm_password">
  </div>
	<?php }
else { ?>
<label for="Password">Old Password :</label>
	<input type="password" class="form-control" id="Old"  onChange="OldPassData();">
<span style="color:#F03228;">Pass Not Match</span>
<?php } }?>



<?php    
   if(isset($_POST['name'])){
 $iddata = $_SESSION['userid'];
  $pWord = md5($_POST['name']);
  $res = mysqli_query($con,"UPDATE `user_ragistration` SET `userpass` ='$pWord' WHERE id='$iddata'"); 
//$num_row = mysqli_num_rows($res);
//$row=mysqli_fetch_assoc($res);
if($res) {

echo "Update Password Data Succesfully";  
 
 }  } ?>
 
 
 <?php //name: name, email: email, Address: Address, Pin: Pin, status: status 
 //`fname`, `lname`, `cmpname`, `email_id`, `userpass`, `add`, `contryid`, `stateid`, `cityid`, `pin`, sid: sid, state1: state1, city1: city1, `mobile`, `status`, `ragdate  
   if(isset($_POST['Pin'])){
    $iddata = $_SESSION['userid'];
 $Name = $_POST['Name'];
 $email = $_POST['email'];
 $Address = $_POST['Address'];
 $Pin = $_POST['Pin'];
 $sid = $_POST['sid'];
 $state1 = $_POST['state1'];
 $city1 = $_POST['city1'];
 //$status = $_POST['status'];
  //$pWord = md5($_POST['name']); `contryid`, `stateid`, `cityid`,
 $res = mysqli_query($con,"UPDATE `user_ragistration` SET `fname`='$Name',`email_id`='$email',`add`='$Address', `contryid`='$sid',`stateid`='$state1',`cityid`='$city1' WHERE id='$iddata'"); 
//$num_row = mysqli_num_rows($res);
//$row=mysqli_fetch_assoc($res);
if($res) {

echo "Update Data Succesfully";  
 
 }  } ?>
 
  