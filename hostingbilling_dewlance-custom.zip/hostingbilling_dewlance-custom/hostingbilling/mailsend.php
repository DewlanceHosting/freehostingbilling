<?php  session_start();
include_once('fn/connect.php');?>

<?php ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(isset($_POST['massagedata'])){
$userR = $_SESSION['userid']; $Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where id='$userR'"); $rowDetai = mysqli_fetch_array($Rdata);
  $fromid=$rowDetai['email_id'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
  $Tomail=$rowg['useremail'];
//massagedata: massagedata
 

$to      = $Tomail; //can't receive notification!

$subject = 'Request Cancellation of this Product';
$message = $_POST['massagedata'];
$headers = 'From: '.$fromid.'"\r\n"'.$fromid.' "\r\n"'.'User Request/' . phpversion();

mail($to, $subject, $message, $headers);

echo 'Your mail has been sent successfully.';
 }
?>

<?php /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(isset($_POST['passcode'])){ 
  $Tomail=$_POST['passcode'];
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
  $fromid=$rowg['useremail']; 

$to      = $Tomail; //can't receive notification!
$codid = $codid = mt_rand(1000, 9999);
$querydata="UPDATE `user_ragistration` SET `otpcode`= '$codid' WHERE `email_id` ='$Tomail'";
$rundata=mysqli_query($con,$querydata);
$subject = 'You are forget your password';
$message = 'your email id'.$_POST['passcode'].'your OTP Code :'.$codid;
$headers = 'From: '.$fromid.'"\r\n"'.$fromid.' ""'.'User Request/' . phpversion();

mail($to, $subject, $message, $headers);

echo '<div class="form-group">
   <span id="DataAns"> <label for="Password">Enter OTP Code</label>
    <input type="text" class="form-control" id="OTPcode" placeholder="Enter your Code"/>
  </div>
   <span id="message"></span><br> 
<button type="button" class="btn btn-danger"   onClick="codeSubmit();">Submit</button>
  ';
 }
?>

<?php /////////////////////////////////////////OTPcode/////////////////////////////////////////////////////////////////////
if(isset($_POST['OTPcode'])){ 
  $Tomail=$_POST['OTPcode'];
$Rdata= mysqli_query($con,"SELECT * FROM `user_ragistration` where otpcode='$Tomail'"); $rowDetai = mysqli_fetch_array($Rdata);
  $fromid=$rowDetai['otpcode'];
 $eiddata =$rowDetai['email_id']; 
 if($Tomail == $fromid){
 echo '<input type="hidden" id="iddatacpc" value="'.$fromid.'" />';
 echo '<input type="hidden" id="eiddata" value="'.$eiddata.'" />';
 echo '<div class="form-group">
   <span id="DataAns"> <label for="Password">Enter New Password</label>
    <input type="text" class="form-control" id="newpassd" placeholder="Enter your Pass"/>
  </div>';
  echo ' 
  <span id="message"></span><br> 
<button type="button" class="btn btn-danger"   onClick="ChangePassubmitd();">Submit</button>';
 }else{ 
  echo '<div class="form-group">
   <span id="DataAns"> <label for="Password">Enter OTP Code</label>
    <input type="text" class="form-control" id="OTPcode" placeholder="Enter your Code"/>
  </div>
   <span id="message"></span><br> 
<button type="button" class="btn btn-danger"   onClick="codeSubmit();">Submit</button>
  ';
 } }
?>

<?php //newpassd: newpassd, iddatacpc: iddatacpc, eiddata: eiddata
if(isset($_POST['newpassd'])){ 
  $Tomail=$_POST['eiddata'];
  $newpassd=md5($_POST['newpassd']);
$querygroup= mysqli_query($con,"SELECT * FROM `admin` where status=0 "); $rowg=mysqli_fetch_array($querygroup);
  $fromid=$rowg['useremail']; 

$to      = $Tomail; //can't receive notification!
 
$querydata="UPDATE `user_ragistration` SET `userpass`= '$newpassd' WHERE `email_id` ='$Tomail'";
$rundata=mysqli_query($con,$querydata);

if($rundata){
$subject = 'You are forget your password';
$message = 'your email id'.$_POST['eiddata'].'your New PassWord is :'.$_POST['newpassd'];
$headers = 'From: '.$fromid.'"\r\n"'.$fromid.'""'.'User Request/' . phpversion();

mail($to, $subject, $message, $headers);

echo 'Change Your Password has been  Change successfully';
}else{ echo ' Your Password not change'; }
 }
?>