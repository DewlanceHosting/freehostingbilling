   <form action="process.php" method="POST">
                       
                            <input id="select_plan" name="select_plan" value="Daily"> 
                         
                            <input id="select_cycles" name="select_cycles" value="33">
                            
                        <input type="submit" value="Subscrive ($4/Day)" name="submit" id="subscribe">
                    </form>
                 
        
    