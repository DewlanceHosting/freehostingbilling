<?php  session_start();
include_once('fn/connect.php');
//mysqlii_select_db('test');
$query="SELECT * FROM country";
$result=mysqli_query($con,$query);
?>

<div class="header">
    <nav class="navbar navbar-top">
      <div class="container">
        <div class="navbar-header header_rsponsic">
          <a class="navbar-brand" href="index.php"><img src="images/<?php echo $rowdata['urlink']; ?>" alt="logo"></a> <?php //echo $_SESSION['userpassSession']; ?>
        </div>
        <div class="navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li><a href="">Cart (<span style="color:#f00"><?php  echo $_SESSION["cardvalue"]; ?></span>)</a></li>
            <?php if( (empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){ ?>
              <li><a href="" data-toggle="modal" data-target="#loginmodel">Login</a></li>
             <li><a href="" data-toggle="modal" data-target="#loginmodelR">Register</a></li>
	         <?php }else{?>
             <li><a href="logout.php?edit=<?php echo $_SESSION['EmailIdSession'];?>">Logout</a></li>
             
             <li><a href="#"><strong>Welcome to Dewlance  <samp style="color:#FF0000; font-size:20px;"> <?php echo $_SESSION['fnamess'];?></samp></strong> </a></li> 
            <?php }?>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <nav class="navbar navbar-default">
      <div class="container">
      <div class="row">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <!-- <a class="navbar-brand" href="#">Project name</a>-->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class=""><a href="index.php">Portal Home</a></li>
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Services <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="services.php">Hosting Services</a></li>
                
              </ul>
            </li>
             <?php session_start(); if( (isset($_SESSION['EmailIdSession'])) && (isset($_SESSION['userpassSession']))){  ?>
           <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Domains <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="mydomain.php">For Domain Management</a></li>
               
              </ul>
            </li>
            
            <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Billing <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="invoice.php">Invoice</a></li>
               
              </ul>
            </li>
             <?php }?>
           <li class="dropdown">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">Support <span class="caret"></span></a>
              <ul class="dropdown-menu">
              
                <li><a href="openticket.php">Open Ticket</a></li>
                <li><a href="existingticket.php">Existing Ticket</a></li>
               
              </ul>


            </li> 
            
              <?php session_start(); if( (isset($_SESSION['EmailIdSession'])) && (isset($_SESSION['userpassSession']))){  ?>

            <li class="dropdown menu">
              <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">My Account <span class="caret"></span></a>
              <ul class="dropdown-menu menu1">
                <li><a href="myaccount.php">Modify Account</a></li>
                <li><a href="changepassword.php">Change Password</a></li>
<!--                 <li><a href="securityquestion.php">Security Question</a></li>
-->              </ul>
            </li>
            <?php }?>
          </ul>
          
        </div><!--/.nav-collapse -->
      </div>
      </div>
    </nav>
  </div>
  
   <!----------------------------- Modal for Ragestration --------------------------------------->
  <div class="modal fade" id="loginmodelR" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="loginmodels">
          <h4 class="modal-title">Register to Dewlance</h4><br>

    <div class="loginpart">   
  <div class="form-group"> 	 
                <label for="firstname"><span class="req"> </span> First name: </label>
                    <input class="form-control" type="text" name="firstname" id="First" onkeyup="Validate(this)" placeholder="First name" required /> 
                        <div id="errFirst"></div>    
            </div>

            <div class="form-group">
                <label for="lastname"><span class="req"> </span> Last name: </label> 
                    <input class="form-control" type="text" name="lastname" id="Last" onkeyup = "Validate(this)" placeholder="Last name" required />  
                        <div id="errLast"></div>
            </div>
   
   <div class="form-group">
    <label for="email">Compony Name:</label>
    <input type="text" class="form-control" id="Compony" name="Compony" placeholder=" Compony Name"> 
  </div>
  <div class="form-group">
    <label for="email">Address:</label>
    <input type="text" class="form-control" id="Address" name="Compony" placeholder=" Address.."> 
  </div>
  <div class="form-group">
                <label for="email"><span class="req"> </span> Email Address: </label> 
                    <input class="form-control" required type="text" name="email" id="Email"  onchange="email_validate(this.value);" placeholder="Enter validate Email Address"  onblur="checkMailStatus()" />   
                        <div class="status" id="status"></div>
            </div> 
  <script type="text/javascript">
function checkMailStatus(){
    // alert("came");
var email=$("#Email").val();// value in field email
	$.ajax({    type:'post',
				url:'checkMail.php',// put your real file name 
				data:{email: email},
				success:function(msg){
				alert(msg); // your message will come here.     
				} }); } 
</script>
  <div class="form-group">
                <label for="password"><span class="req"></span> Password: </label>
                    <input required name="password" type="password" class="form-control inputpass" minlength="4" maxlength="16"  id="pass1" placeholder="Enter validate" onBlur="checkLength(this)"/> </p>

                <label for="password"><span class="req"></span> Password Confirm: </label>
                    <input required name="password" type="password" class="form-control inputpass" minlength="4" maxlength="16" placeholder="Enter again to validate" id="pass2" onkeyup="checkPass(); return false;" />
                        <span id="confirmMessage" class="confirmMessage"></span>
            </div>
  <div class="row">
                  <div class="col-md-4">  <label for="example-text-input" class="col-sm-4"><strong>Country</strong><span style="color:#FF0000">*</span></label>
                    <select  class="form-control" id="country"  name="compony" onChange="showUser(this.value)">
                      <option value="0">Select Country</option>
                      <?php  $content = "SELECT * FROM   country  order by id desc "; 
					  $cat_quer = mysqli_query($con,$content) ; 
					while($mycat_row = mysqli_fetch_array($cat_quer)){ 
					$patientid=$mycat_row['id'];?>
                      <option value="<?php  echo $mycat_row['id'];?>">
                      <?php  echo $mycat_row['country'];?>
                      </option>
                      <?php }?>
                    </select>
                  </div>
                  <div class="col-md-4">  <label for="example-text-input" class="col-sm-4"><strong>State</strong><span style="color:#FF0000">*</span></label>
                    <select  class="form-control" id="state"  name="state" onChange="showUser1(this.value)">
                      <option value="0">Select</option>
                    </select>
                  </div>
                  <div class="col-md-4"> <label for="example-text-input" class="col-sm-4"><strong>City</strong><span style="color:#FF0000">*</span></label>
                    <select  class="form-control"  name="city" id="city" >
                      <option value="0">Select</option>
                    </select>
                  </div>
                </div>
  <div class="form-group">
    <label for="pwd">Pin No:</label> 
    <input required type="text" name="phonenumber" id="Pin" class="form-control phone" maxlength="15" onkeyup="validatephone(this);" placeholder="not used for Pin" onBlur="checkLength(this)"/> 
  </div>
   <div class="form-group">
            <label for="phonenumber"><span class="req"></span> Phone Number: </label>
                    <input required type="text" name="phonenumber" id="Mobile" class="form-control phone" maxlength="15" onkeyup="validatephone(this);" placeholder="not used for Phone Number"/> 
            </div>
   
  
  
            <div class="form-group">
            
                <?php //$date_entered = date('m/d/Y H:i:s'); ?>
                <input type="hidden" value="<?php //echo $date_entered; ?>" name="dateregistered">
                <input type="hidden" value="0" name="activate" />
                <hr>
 
                <input type="checkbox"  name="terms"  value="1"  id="labid" required>   <label for="terms">I agree with the <a href="terms.php" title="You may read our terms and conditions by clicking on this link">terms and conditions</a> for Registration.</label><br /><span style="background:#FF6633;" class="req">* </span>
            </div>
  <button type="button" class="btn btn-danger" id="AppointDataSubmited">Register</button>
   
 <!-- <p align="center">New to Dewlance? <a href="#">Create Account</a></p>-->
 
     
     
     </div>

          </div>
          
        </div>
        
      </div>
    </div>
  </div>
 
    <!-- ------------------------------end- Modal for Ragestration --------------------------------------->
     
    <!----------------------------- Modal for login --------------------------------------->
  <div class="modal fade" id="loginmodel" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="loginmodels">
          <h4 class="modal-title">Login to Dewlance</h4><br>

    <div class="loginpart">   
    
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="loginemail" placeholder=" Enter your Email Address"> 
  </div>
  
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="loginpwd" placeholder=" Enter your Password">
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <div class="error-message"><?php if(isset($message)) { echo $message; } ?></div>	
  <button type="button" class="btn btn-danger" id="UserLoginN">Login</button>
  <a href="#" class="pull-right" data-toggle="modal" data-target="#forgotpass" data-dismiss="modal" >Forgot Password</a>
  <p align="center">  <a href="#" data-toggle="modal"  data-target="#loginmodelR" data-dismiss="modal">Create Account</a></p>  
     </div> 
          </div> 
        </div> 
      </div>
    </div>
  </div>
  <script>/*function checkLength(el) {
  if (el.value.length <= 5) {
    alert("length must be Min 6 characters")
  }
}*/</script>
    <!-- ------------------------------- Modal for Login --------------------------------------->
    <!----------------------------- Pass check --------------------------------------->
  <div class="modal fade" id="forgotpass" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="loginmodels">
<div class="row">
<div class="col-md-offset-3 col-md-6 col-md-offset-3">
 <div class="proftabb"><h3>Forgot Password</h3></div> 
<div class="proftabb">
<span id="DataAns"> 
<span id="SuccesData">
<div class="form-group">
   <span id="DataAns"> <label for="Password">Enter You email Id</label>
    <input type="text" class="form-control" id="passcode" placeholder="Enter your Email Address"/>
  </div> 
  
   <span id='message'></span><br> 
<button type="button" class="btn btn-danger"   onClick="submitData();">Submit</button>
</span>
</span>
  </span> 
  <span id='newmsg'></span><br>
</div> 
</div></div>
 
</div>
</div>


</div>
    </div>
  </div>
  <?php  ?> 
  <script>
 function ChangePassubmitd() {
    var newpassd = $("#newpassd").val(); //alert(name);
	var iddatacpc = $("#iddatacpc").val(); //alert(name); 
	var eiddata = $("#eiddata").val(); //alert(name); 
    $.post("mailsend.php", { newpassd: newpassd, iddatacpc: iddatacpc, eiddata: eiddata},
    function(data) {
	 $('#newmsg').html(data);  //alert(data); 
	 $('#myForm')[0].reset();
    });
}</script>
  
<script>
 function submitData() {
    var passcode = $("#passcode").val(); //alert(name); 
    $.post("mailsend.php", { passcode: passcode},
    function(data) {
	 $('#SuccesData').html(data);  //alert(data); 
	 $('#myForm')[0].reset();
    });
}</script>

<script>
 function codeSubmit() {  
    var OTPcode = $("#OTPcode").val(); ///alert(OTPcode);
    $.post("mailsend.php", { OTPcode: OTPcode},
    function(data) {
	 $('#DataAns').html(data);
	// alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
    <!-- ------------------------------- Modal for Login --------------------------------------->
    <script>function checkPass()
{
    //Store the password field objects into variables ...
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
    //Store the Confimation Message Object ...
    var message = document.getElementById('confirmMessage');
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
    if(pass1.value == pass2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Passwords Match"
    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Passwords Do Not Match!"
    }
} 
function validatephone(phone) 
{
    var maintainplus = '';
    var numval = phone.value
    if ( numval.charAt(0)=='+' )
    {
        var maintainplus = '';
    }
    curphonevar = numval.replace(/[\\A-Za-z!"£$%^&\,*+_={};:'@#~,.Š\/<>?|`¬\]\[]/g,'');
    phone.value = maintainplus + curphonevar;
    var maintainplus = '';
    phone.focus;
}
// validates text only
function Validate(txt) {
    txt.value = txt.value.replace(/[^a-zA-Z-'\n\r.]+/g, '');
}
// validate email
function email_validate(email)
{
var regMail = /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

    if(regMail.test(email) == false)
    {
	
    document.getElementById("status").innerHTML    = "<span class='warning'>Email address is not valid yet.</span>";
    }
    else
    {
    document.getElementById("status").innerHTML	= "<span class='valid'>Thanks, you have entered a valid Email address!</span>";	
    }
}
// validate date of birth
function dob_validate(dob)
{
var regDOB = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/;

    if(regDOB.test(dob) == false)
    {
    document.getElementById("statusDOB").innerHTML	= "<span class='warning'>DOB is only used to verify your age.</span>";
    }
    else
    {
    document.getElementById("statusDOB").innerHTML	= "<span class='valid'>Thanks, you have entered a valid DOB!</span>";	
    }
}
// validate address
function add_validate(address)
{
var regAdd = /^(?=.*\d)[a-zA-Z\s\d\/]+$/;
  
    if(regAdd.test(address) == false)
    {
    document.getElementById("statusAdd").innerHTML	= "<span class='warning'>Address is not valid yet.</span>";
    }
    else
    {
    document.getElementById("statusAdd").innerHTML	= "<span class='valid'>Thanks, Address looks valid!</span>";	
    }
}
</script>
    <script src="function.js" type="text/javascript">></script>
  <script> 
function showUser(str) { 
    if (str == "") { 
        document.getElementById("state").innerHTML = ""; 
        return;
 
    } else { 
 
        if (window.XMLHttpRequest) { 
            // code for IE7+, Firefox, Chrome, Opera, Safari 
            xmlhttp = new XMLHttpRequest(); 
        } else {
 
            // code for IE6, IE5 
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
        }
 
        xmlhttp.onreadystatechange = function() { 
            if (this.readyState == 4 && this.status == 200) { 
                document.getElementById("state").innerHTML = this.responseText; 
            } 
        };
 
        xmlhttp.open("GET","getstate.php?q="+str,true); 
        xmlhttp.send(); 
    }
 
} 
</script>
<script> 
function showUser1(str) { 
    if (str == "") {
 
        document.getElementById("city").innerHTML = ""; 
        return; 

    } else {  
        if (window.XMLHttpRequest) { 
            // code for IE7+, Firefox, Chrome, Opera, Safari
 
            xmlhttp = new XMLHttpRequest(); 
        } else { 
            // code for IE6, IE5 
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
        }
 
        xmlhttp.onreadystatechange = function() { 
            if (this.readyState == 4 && this.status == 200) { 
                document.getElementById("city").innerHTML = this.responseText;   } 
  };
 xmlhttp.open("GET","getcity.php?q="+str,true); 
        xmlhttp.send(); 
    } 
}  
</script> 

 <script src="js/markdown.js" type="text/javascript"></script>