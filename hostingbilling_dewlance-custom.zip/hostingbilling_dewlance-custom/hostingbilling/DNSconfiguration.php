  <?php   session_start();   error_reporting(0);  
  if(isset($_GET['prs'])){
   $_SESSION["cardvalue"] = $_SESSION["cardvalue"] + $_SESSION["num"]; 
  
  $_SESSION["num"]='0';
			}
			//if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
  <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  <?php include_once("header.php"); ?>
   
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="row">

<div class="col-md-offset-2 col-md-8 col-md-offset-2">

<div class="dnsconfigsec">

<h3>DNS Configuration</h3>

<h4>Enter your custom name server or our system will use default nameserver.</h4>

<br /><br /><br />
<div class="row">
<div class="col-sm-6">
<?php 
$_SESSION["palanname"] = '';
  $_SESSION["palan_amt"] = '';
  $_SESSION["domainname"] = base64_decode($_GET['don']); 
  $_SESSION["domain_amt"] = base64_decode($_GET['prs']);
  $_SESSION["proId"] = '';
  $_SESSION["bill"] = '';
  $_SESSION["total"] = base64_decode($_GET['prs']); 
  $_SESSION["userid"];
   ?>
   <form action="process.php" method="POST">
    <div class="form-group">
    <label for="Nameserver">Nameserver 1</label>
    <input type="text" name="Nameserver1" class="form-control" id="Nameserver">
  </div>
  <div class="form-group">
    <label for="Nameserver2">Nameserver 2</label>
    <input type="text" name="Nameserver2" class="form-control" id="Nameserver2">
  </div>
 <input type="hidden" name="1" value="<?php echo base64_decode($_GET['don']);?>"> 
  <input type="hidden" name="prs" value="<?php echo  base64_decode($_GET['prs']); ?>"> 
  <input type="hidden" name="domainAdd" value="22"> 
<input type="hidden" name="select_cycles" value="<?php echo $pricestotal; ?>"> 
<input type="hidden" name="bill" value="<?php  echo $_GET['bill'];  ?>">
<?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){   ?>
  <button type="button" data-toggle="modal" data-target="#loginmodel" class="btn btn-success btn-lg">Check Out</button>
 <?php } else{?>
 <button type="submit" name="submit" class="btn btn-success btn-lg">Check Out</button> 
 <?php } ?> 
   </form> 
</div>
<div class="col-sm-6">

<div class="addhostplan">
<h3>You don't have hosting</h3> 
 <a href="hosting-category.php?prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>"><button type="submit" class="btn btn-success btn-lg">Add Hosting Plan</button></a>
 
</div>
</div>
</div>
</div> 

</div> 

</div> 
</div>

</section> 
 <!--home--contant----end--->  
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>