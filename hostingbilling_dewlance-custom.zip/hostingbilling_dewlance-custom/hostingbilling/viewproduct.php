 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
    <?php include_once("header.php"); ?> 
    
<section class="clientdashh">
<div class="container">
<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where  status='1'"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>
<?php   $domaidata=base64_decode($_GET['1']);
//`id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`, `domainstatus`, `ordercancel`
 $queryrdata = mysqli_query($con,"SELECT * FROM `user_hostingpay` where id='$domaidata'"); $rowdata=mysqli_fetch_array($queryrdata);
$producid= $rowdata['producid'];  $user_rid= $rowdata['user_rid']; ?>

<?php
$querypro = mysqli_query($con,"SELECT * FROM `productadd` where producid='$producid'"); $rowprod=mysqli_fetch_array($querypro);
 $groupid= $rowprod['groupid']; ?>
 <?php
$querygroup= mysqli_query($con,"SELECT * FROM `productgroupadd` where pgroupid='$groupid'"); $rowg=mysqli_fetch_array($querygroup);
 $producid= $rowg['producid']; ?>
  <?php $queuser=mysqli_query($con,"SELECT * FROM `user_ragistration` where  id ='$user_rid'");  $rowuser=mysqli_fetch_array($queuser); 
   $pass=md5($rowuser['userpass']);   $usrp=$rowuser['producid'];?>
<div class="listservisdata">
<h3>View product</h3>

<div class="row">

<div class="col-md-6">
<div class="prodboxs">
<h4>Hosting Package</h4>

<h5>Group Name : <?php echo $rowg['producname']; ?></h5>

<h5>Product Name : <?php echo $rowprod['modulid']; ?></h5>

<h5>Domain Name : <?php echo $rowdata['domain_name']; ?></h5>
 
</div> 
</div> 

<div class="col-md-6"> 
<div class="prodboxs">
<h4>Other Function</h4>

<ul class="functton">
  <?
    $user = "root";
     $token = $rowc['apikdy']; 
    $query = "https://$stval/json-api/listaccts?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
        $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		// print_r($json);
        
        foreach ($json->{'data'}->{'acct'} as $userdetails) { 
	 if(($userdetails->{'user'} == $rowuser['fname']) && ($userdetails->{'email'} == $rowuser['email_id'])){ 
	 echo'<input type="hidden" id="cpaneluserName" value="'.$userdetails->{'user'}.'">';
	 $whmusername = "root";
$cpanel_user = $rowuser['fname'];
# The contents of /root/.accesshash
$token = $rowc['apikdy']; 
    $query = "https://$stval/json-api/create_user_session?api.version=1&user=$cpanel_user&service=cpaneld";

$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);

$header[0] = "Authorization: WHM $whmusername:" . preg_replace("'(\r|\n)'","",$token);

curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl, CURLOPT_URL, $query);

$result = curl_exec($curl);

if ($result == false) {
  
    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");
}


$decoded_response = json_decode( $result, true );
$session_url = $decoded_response['data']['url'];
$cookie_jar = 'cookie.txt';
//print_r($session_url);
curl_setopt($curl, CURLOPT_HTTPHEADER, null);             // Unset the authentication header.
curl_setopt($curl, CURLOPT_COOKIESESSION, true);          // Initiate a new cookie session.
curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie_jar);       // Set the cookie jar.
curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie_jar);      // Set the cookie file.
curl_setopt($curl, CURLOPT_URL, $session_url);            // Set the query url to the session login url.

echo $result = curl_exec($curl); 
                              // Execute the session login call.
if ($result == false) {
    error_log("curl_exec threw error \"" . curl_error($curl) . "\" for $query");
                                                    // Log an error if curl_exec fails.
} ?>
   
		<li><a href="<?php echo  $session_url; ?>">Login to cPanel</a></li>
        <li><a href="<?php echo  $session_url; ?>">Login to cPanel Webmail</a></li>
        <li><a href="#"><span id="showmenu">Upgrade or Downgrade Plan</span></a></li>
<div class="menu" style="display: none;"><ul><li>Button1</li><li>Button2</li><li>Button3</li></ul></div>

<li><a href="#"><span id="showmenu2">Change cPanel Password</span></a></li>
<div class="menu2" style="display: none;">
<table align="center">
<tr><td>  User Name: 
  <input type="text" class="form-control" name="User" id="User" value="<?php echo $userdetails->{'user'}; ?>"></td></tr>
<tr><td> OldPass: 
  <input type="text" class="form-control" name="OldPass" id="OldPass" ></td></tr>
<tr><td> New Pass:  
  <input type="text" class="form-control" name="Newpass" id="Newpass"  ></td></tr> 
 
</table><br>
<button  class="btn btn-success" onClick="chagngePass();">Change Password</button> 
 </div>

<li><a href="#"><span id="showmenu3">Request Cancellation of this Product</span></a></li>
<div class="menu3" style="display: none;">
<div class="input-group" style="padding:0 10%"> 
  <textarea cols="60" rows="10" id="massagedata"></textarea> 
  </div>
<button  class="btn btn-success" onClick="MailSend();">Send Request</button> 
 </div><br><div id="MaiRview"></div>
<br>

 
 
<?php //echo $session_url; 
//print_r(str_replace("URL=/","URL=https://167.160.174.209:2087/",$result)); 
curl_close($curl);  
		 }  }   } 
    curl_close($curl); 
?>  

 
</ul> 
</div> 
</div> 

</div><!--xcvxvvvvvvvvvvvvvvvvvvvvvvvvvvvjfashdkfas-->
 <script>function MailSend() { 
  var massagedata = $("#massagedata").val(); //alert(massagedata);
  $.post("mailsend.php", {massagedata: massagedata },
   function(data) { 
   $('#MaiRview').html(data); //alert(data);  
    });}</script>
<div id="chagepassv"></div>
<!--xcvxvvvvvvvvvvvvvvvvvvvvvvvvvvvjfashdkfas-->
 <script>function chagngePass() {
confirm("Do You want Change Password");
    var User = $("#User").val(); //alert(Product); 
	 var OldPass = $("#OldPass").val(); //alert(Product); 
	  var Newpass = $("#Newpass").val(); //alert(Product); 	  
    $.post("apichagepass.php", {User: User, OldPass: OldPass, Newpass: Newpass  },
    function(data) {
	 $('#chagepassv').html(data);
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>

 <script>function SuspendApiFormData() {
confirm("Do You want Change Password");
    var unsusname = $("#unsusname").val(); //alert(Product); 
	 var oldpass = $("#oldpass").val(); //alert(Product); 
	  var newpass = $("#newpass").val(); //alert(Product); 	  
    $.post("1.php", {unsusname: unsusname,oldpass: oldpass,newpass: newpass  },
    function(data) {
	 $('#results').html(data);
	 //alert(data);
	 $('#myForm')[0].reset();
    });
}</script>
<script>
  $(document).ready(function() {
        $('#showmenu2').click(function() {
                $('.menu2').slideToggle("fast");
        });
    });
</script> 
<script>
  $(document).ready(function() {
        $('#showmenu3').click(function() {
                $('.menu3').slideToggle("fast");
        });
    });
</script>
<div class="row">

<div class="col-md-6">
<div class="prodboxs">
<h4>Usage Statistics</h4>

<br><br>
<?
    $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
   // $query = "https://167.160.174.209:2087/json-api/listaccts?api.version=1";
 $query = "https://167.160.174.209:2087/json-api/cpanel?cpanel_jsonapi_user=jjitendre&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=DiskUsage&cpanel_jsonapi_func=fetchdiskusagewithextras";
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
          $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		// print_r($json);
        //echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'cpanelresult'}->{'data'} as $userdetails) {  ?> 
   <h5>Disk Usage : &nbsp; <span><?php echo $userdetails->{'quotaused'}; ?>MB</span></h5>
    <h5>Bandwidth Usage : &nbsp; <span><?php echo $userdetails->{'quotalimit'}; ?>MB</span></h5> 
	<?php	if($userdetails->{'uid'} == 1002){
		echo "\t" .$userdetails->{'user'}. "\n";
		
		}         }    } 
    curl_close($curl); 
?>



</div> 
</div> 


<div class="col-md-6">

<div class="prodboxs">
<h4>Create Email Account</h4>
<br>
<form>
  <div class="input-group" style="padding:0 10%">
   <span class="input-group-addon" style="background:#d9534f;"><span class="btn btn-danger btn-xs">Email Name</span></span> 
   <input id="emailName" class="form-control"  placeholder="Desired Password" type="text" /> 
  </div>
  <div class="input-group" style="padding:0 10%"> 
    <span class="input-group-addon" style="background:#d9534f;"><span class="btn btn-danger btn-xs">Domain Name</span></span>
      <input id="domainname" class="form-control"  placeholder="Desired Domain Name" type="text" /> 
  </div>
  <div class="input-group" style="padding:0 10%"> 
      <span class="input-group-addon" style="background:#d9534f;"><span class="btn btn-danger btn-xs">Password</span></span>
        <input id="validepass" class="form-control"  placeholder="Desired Password" type="text" /> 
  </div>
</form>
<br>
<!--<button type="submit" class="btn btn-default">Desired Password</button><br><br>
-->
<button type="submit" class="btn btn-success" onClick="createdEmailid();">Create Email Account</button><br>
<div id="resultCreatview"></div> 
</div> 
</div> 
</div>
<script>
function createdEmailid() {
confirm("Do You want Create Emailid");
    var emailName = $("#emailName").val();
    var domainname = $("#domainname").val();
    var validepass = $("#validepass").val();
	var cpaneluserName = $("#cpaneluserName").val();    
    $.post("apiemaiid.php", { emailName: emailName, domainname: domainname, validepass: validepass, cpaneluserName: cpaneluserName},
    function(data) {
	 $('#resultCreatview').html(data);
	 $('#myForm')[0].reset();
    });
} 
 </script>
<!--id`, `producid`, `user_rid`, `domain_name`, `plan_name`, `transectiondate`, `oderid`, `transactionid`, `paymethod`, `total`, `status`, `domainstatus`, `ordercancel`-->




<h3>Billing Detail</h3>
<div class="bllinggsec">
<div class="row">
<div class="col-md-8">

<div class="row">
<div class="col-sm-5">
<h4>Requiring Amount :</h4>
</div>
<div class="col-sm-7">
<h4><span> $<?php if($rowdata['total'] == '0'){?> 
        <?php echo $rowprod['price']; ?> 
<?php } else{?>
  0 
 <?php } ?></span></h4>
</div>
</div>
<div class="row">
<div class="col-sm-5">
<h4>Billing Cycle :</h4>
</div>
<div class="col-sm-7">
<h4><span>  <small> <?php echo $rowprod['billtype']; ?></small></span></h4>
</div>
</div>
<div class="row">
<div class="col-sm-5">
<h4>Product Creation Date :</h4>
</div>
<div class="col-sm-7">
<h4><span><?php echo $rowdata['transectiondate']; ?></span></h4>
</div>
</div>
<div class="row">
<div class="col-sm-5">
<h4>Next Renewal Date :</h4>
</div>
<div class="col-sm-7">
<h4><span><?php if($rowdata['total'] == '0'){?> 
  Pending    
<?php } else{?>
 <?php echo $rowdata['transectiondate']; ?>
 <?php } ?></span></h4>
</div>
</div>
<div class="row">
<div class="col-sm-5">
<h4>Payment Method :</h4>
</div>
<div class="col-sm-7">
<h4><span>Paypal</span></h4>
</div>
</div>


</div>


<div class="col-md-4"></div>
</div>

</div>





</div>
</div>
</section> 
 <!--home--contant----end---> 
 
 
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>