<?php include_once('fn/connect.php'); $pdata = $_POST['updatename']; ?>
 <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>
<div id="webhost1" class="tab-pane fade in active">
<div class="hosting_detailss clientdashh">
 <?php $queryProductG1 = mysqli_query($con,"SELECT * FROM `productgroupadd` where pgroupid='$pdata'"); $ProducNameG1 = mysqli_fetch_array($queryProductG1); $pdata1=$ProducNameG1['pgroupid']; ?>
 
<h3><?php  echo $_POST['prs']; echo $ProducNameG1['producname']; ?></h3>

<ul class="hostdom_list">
<?php $queryProduc = mysqli_query($con,"SELECT * FROM `productadd` where groupid='$pdata1'"); while($ProducName = mysqli_fetch_array($queryProduc)){ ?>

<?php $querc=mysqli_query($con,"SELECT * FROM `cpenal_control` where status=1"); $rowc=mysqli_fetch_array($querc); $stval=$rowc['ipnumber']; ?>

<li>
<h4><?php echo $uds= $ProducName['modulid']; ?> - Supercheap</h4>
<div class="about-domain">
<div class="row">
<div class="col-sm-8">
 <?
    $user = "root";
    $token =$rowc['apikdy'];
 
    $query = "https://$stval/json-api/listpkgs?api.version=1";
 
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
       $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        //echo "[!] Error: " . $http_status . " returned\n";
    } else {
        $json = json_decode($result);
		// print_r($json);
       // echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'data'}->{'pkg'} as $userdetails) {
            if($userdetails->{'name'} == $uds){
?>  
<h5><?php echo  $userdetails->{'name'} ;?></h5>
<h5>Disk Space- <span><?php echo  $userdetails->{'QUOTA'} ;?> MB</span></h5>

<h5>Bandwidth- <span><?php echo  $userdetails->{'BWLIMIT'} ;?> MB per month</span></h5>

<h5>Cpanel & Softaculous</h5>

<h5>Setup - <span><?php echo  $ProducName['billtype']; ?></span></h5>

<h5><?php echo  $ProducName['decrip']; ?></h5>
<!--<h5>100% FTP Email and Mysql accounts</h5>-->

<!--<h5><strong><?php echo  $ProducName['decrip']; ?></strong></h5>
--><!--<h5>Server Location</h5>
-->



</div>

<div class="col-sm-4">
<div class="ordersect">
<h3>&dollar; <?php echo $ProducName['price']; ?>.00 USD</h3>
<h6><?php echo $ProducName['billtype']; ?></h6>

<a href="orderreviews.php?1=<?php echo base64_encode($userdetails->{'name'}) ?>&did=<?php echo base64_encode( $ProducName['producid']) ?>&prs=<?php echo $_POST['prs']; ?>&don=<?php echo $_POST['don']; ?>"><button class="btn btn-success btn-xs"><i class="fa fa-cart-plus"></i> Order Now</button></a>
</div> 
</div>
</div>

</div>

</li>
  <?php }         }
    }
 }
    curl_close($curl); 
?> 
 

</ul>

</div>
</div>
</script>
<style>
.content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}
</style>
<script>
$(function() {
    $(".preload").fadeOut(2000, function() {
        $(".clientdashh").fadeIn(1000);        
    });
});
</script>
