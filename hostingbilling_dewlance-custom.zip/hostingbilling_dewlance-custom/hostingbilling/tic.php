<?php  include_once('fn/connect.php');
if(isset($_POST['usr'])){
echo $pdata=$_POST['usr'];
 $queryds= mysqli_query($con,"SELECT * FROM `ticket_sale` where closeticket=1 && subjec='$pdata'"); $Prodc = mysqli_fetch_array($queryds);
 
 if($Prodc){
  echo "<br /><strong  style='color:#009999;'>subjec ".$Prodc['subjec']."</strong> Exists In list";
 }else{
 echo "This Type Name Ticket Not <strong>Exists In list</strong>";
 }
 } 
 
 
 ?>