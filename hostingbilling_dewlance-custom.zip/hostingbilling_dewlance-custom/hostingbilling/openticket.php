 <?php  session_start();   error_reporting(0); //if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<div class="listservisdata">
<h3>Open Ticket</h3>
<p>You can Open Ticket selecting approciate department below</p>

<div class="categry">
 <?php  if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){?>
 <ul>
<?php $dparque=mysqli_query($con,"SELECT * FROM `add_ticket_depart`"); while($rowdepr=mysqli_fetch_array($dparque)){ $Deparname=$rowdepr['name']; ?> 
<li>
<a href="#" data-toggle="modal" data-target="#loginmodel">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; <?php echo $rowdepr['name']; ?></h4>
<p><?php echo $rowdepr['description']; ?></p>
</a>
</li>
<?php }?>

<!--<li>
<a href="open-department.php?1=<?php   echo base64_encode("Sales")  ?>">
<h4><span><i class="fa fa-envelope" aria-hidden="true"></i></span>&nbsp; Sales</h4>
<p>Support Inquires</p>
</a>
</li>

<li>
<a href="open-department.php?1=<?php echo base64_encode("Domain") ?>">
<h4><span><i class="fa fa-dot-circle-o"></i></span>&nbsp; Domain</h4>
<p>Domain Registered with Dewlance</p>
</a>
</li>

<li>
<a href="open-department.php?1=<?php echo base64_encode("Department") ?>">
<h4><span><i class="fa fa-building"></i></span>&nbsp; Abuse Department</h4>
<p>Reporting Abuse Issues</p>
</a>
</li>-->


</ul>
  <?php }else{?>
 <ul>
<?php $dparque=mysqli_query($con,"SELECT * FROM `add_ticket_depart`"); while($rowdepr=mysqli_fetch_array($dparque)){ $Deparname=$rowdepr['name']; ?> 
<li>
<a href="open-department.php?1=<?php echo base64_encode($Deparname) ?>">
<h4><span><i class="fa fa-calendar-minus-o"></i></span>&nbsp; <?php echo $rowdepr['name']; ?></h4>
<p>Sales Inquires & Custom Orders</p>
</a>
</li>
<?php }?>

<!--<li>
<a href="open-department.php?1=<?php   echo base64_encode("Sales")  ?>">
<h4><span><i class="fa fa-envelope" aria-hidden="true"></i></span>&nbsp; Sales</h4>
<p>Support Inquires</p>
</a>
</li>

<li>
<a href="open-department.php?1=<?php echo base64_encode("Domain") ?>">
<h4><span><i class="fa fa-dot-circle-o"></i></span>&nbsp; Domain</h4>
<p>Domain Registered with Dewlance</p>
</a>
</li>

<li>
<a href="open-department.php?1=<?php echo base64_encode("Department") ?>">
<h4><span><i class="fa fa-building"></i></span>&nbsp; Abuse Department</h4>
<p>Reporting Abuse Issues</p>
</a>
</li>-->


</ul>
 
  <?php header('location:index.php');}?>


</div>






</div>
</div>
</div>






</div>

</section>


 
 
 <!--home--contant----end--->
 
 
 
 
 
 
 <br><br><br><br>
 
   <?php include_once("footer.php"); ?>
 <!----------footer---end------->
 

  

  </body>
</html>