<?php
session_start();
 echo $_SESSION['userpassSession'];
if(!empty($_GET["edit"])) {
	$_SESSION["EmailIdSession"] = "";
	$_SESSION["userpassSession"] = "";
	session_destroy();
	header("Location: index.php");
}
 
/*if(session_destroy())
{
header("Location: index.php");
}*/
?>