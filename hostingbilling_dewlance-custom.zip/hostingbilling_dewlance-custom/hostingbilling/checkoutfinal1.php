 <?php  //session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); date_default_timezone_set("Asia/Kolkata");  ?>
  
  <!--headerpart-end--> 
<section class="clientdashh">
<div class="container">
<div class="row">
<div class="col-md-offset-2 col-md-8 col-md-offset-2">
<h3 style="font-weight:600;">Checkout</h3><br />

 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){   ?>
<div class="checkoutsystm">
<h4>Please enter yours details and billing information to checkout.</h4>
<!--<button type="button" class="btn btn-info">You are Not Registered? Please Registered First</button>
--><h2></h2>
 <span style="background-color:#EEEEEE; padding:5px;">are you Already Registered?  &nbsp; ->&nbsp;<a href="#" data-toggle="modal" data-target="#loginmodel"> Login</a> 
           &nbsp;&nbsp;  Please enter yours details ->  <a  data-toggle="modal" data-target="#loginmodelR">Register</a></span>
 
 

<!--<form action="hostingpayment.php?1=<?php echo $_GET['1']; ?>&did=<?php echo$_GET['did']; ?>&prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>" method="post" enctype="multipart/form-data">
<div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label for="First_n">First Name :</label>
    <input type="text" class="form-control" id="First_n">
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label for="Last_n">Last Name :</label>
    <input type="text" class="form-control" id="Last_n">
  </div>
</div>
</div>
  
 <div class="form-group">
    <label for="Email">Email Address :</label>
    <input type="email" class="form-control" id="Email" >
  </div> 
    
<div class="form-group">
    <label for="Company_n">Company Name :</label>
    <input type="text" class="form-control" id="Company_n">
  </div>
  
  <div class="form-group">
    <label for="Street_add">Street Address :</label>
    <textarea class="form-control" id="Street_add"></textarea>
  </div>
  
    <div class="form-group">
    <label for="Street_add2">Street Address 2 :</label>
    <textarea class="form-control" id="Street_add2"></textarea>
  </div>
  
  <div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label for="pwd">&nbsp;</label>
    <input type="password" class="form-control" id="pwd">
  </div>
</div>
</div>
  
    
 <div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label for="Location">Location :</label>
    <select class="form-control" id="Location">
    <option>Choose Your Country</option>
    <option>India</option>
    </select>
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label for="Location">&nbsp;</label>
    <select class="form-control" id="Location">
    <option>Choose Your State</option>
    <option>Haryana</option>
    </select>
  </div>
</div>
</div> 


<div class="row">
<div class="col-sm-6">
<div class="form-group">
    <label for="Location">&nbsp; </label>
    <select class="form-control" id="Location">
    <option>Choose Your City</option>
    <option>India</option>
    </select>
  </div>
</div>
<div class="col-sm-6">
<div class="form-group">
    <label for="Code">Post Code</label>
    <input type="text" class="form-control" id="Code">
  
  </div>
</div>
</div>
  
 
 <h3 align="center">Payment Details & Payment Method</h3>
 
 
 <h3>Total Due Today: &dollar;<?php echo base64_decode($_GET['prs']); ?></h3>
 
 <p><small>Please choose your preferred method of payment.</small></p>
  
      <label class="radio-inline">
      <input type="radio" name="optradio"> PayPal
    </label>
  
  
  
 <center> <div class="checkbox">
  <label><input type="checkbox" value=""> I have read and agree to the <a href="#">terms of service </a></label>
</div></center>
  
  
  
  
  <center> <button type="submit" class="btn btn-primary">Complete Order</button> </center>
</form>-->
 
</div>
<?php } else{?>
<div class="checkoutsystm">
 <!--<h4>Do you watnt to pay click on Buy Button.</h4>
 <button type="button" class="btn btn-info">Already Registered?</button>
 <h2>-</h2> -->
<?php
	$paypalUrl='https://www.sandbox.paypal.com/cgi-bin/webscr';
	$queryemail= mysqli_query($con,"SELECT * FROM `paygetwaydata`"); $rowemailid=mysqli_fetch_array($queryemail);
	   $emailId=$rowemailid['paymentaccount'];
	$paypalId=$emailId;
?>
  

<h3>Your Details</h3>
 <form action="<?php echo $paypalUrl; ?>" method="post" name="frmPayPal1" enctype="multipart/form-data">
					<div class="panel price panel-red">
						    <input type="hidden" name="business" value="<?php echo $paypalId; ?>">
						    <input type="hidden" name="cmd" value="_xclick">
						    <input type="hidden" name="item_name" value='<?php echo base64_decode($_GET['1']); ?>'>
						    <input type="hidden" name="item_number" value='<?php echo base64_decode($_GET['1']); ?>'>
						    <input type="hidden" name="amount" value='<?php echo base64_decode($_GET['prs']); ?>'>
						    <input type="hidden" name="no_shipping" value="1">
						    <input type="hidden" name="currency_code" value="USD">
                            <input type='hidden' name='notify_url' value='payment.php'>
						    <input type="hidden" name="cancel_return" value="cancel.php">
						    <input type="hidden" name="return" value="hostingpayment.php">  
  
 
 <div class="row">
 <div class="col-md-6">
 <h4>Package Name: <strong><?php echo base64_decode($_GET['1']); ?></strong></h4>
 </div>
 <div class="col-md-6">
 <h4 class="pull-right"> Total Due Today: <strong  >&dollar;<?php echo base64_decode($_GET['prs']); ?> </strong> </h4>
 </div>
 </div> 

 <strong class="pull-right"> <input type="image" src="images/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
</strong> 
</form> 

<form action="1.php?1=<?php echo $_GET['1']; ?>&did=<?php echo$_GET['did']; ?>&prs=<?php echo $_GET['prs']; ?>&don=<?php echo $_GET['don']; ?>" method="post" enctype="multipart/form-data">
 <button type="submit" class="btn btn-primary " >Skip -> continue </button> </form>
</div>
<?php } ?> 
</div>
</div>  
</div> 
</section> 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>