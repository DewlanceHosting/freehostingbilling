$(document).ready(function(){
	 
$("#AppointDataSubmited").click(function(){ 
			 var labid = $('#labid:checked').val();  //alert(labid);
			 
var First = $("#First").val();  //alert(PicName);
var Last = $("#Last").val(); //alert(PicDate);
var Compony = $("#Compony").val(); //alert(PicDate);
var Email = $("#Email").val(); //alert(Totime);
var Password = $("#pass2").val(); //alert(contact);
var country = $("#country").val();
var state = $("#state").val();
var city = $("#city").val();
var Mobile = $("#Mobile").val();
var Pin = $("#Pin").val();
var Address = $("#Address").val();
if(labid != 1  ){
  $('.req').html('Select terms and condition ').show().delay(2800).fadeOut();
  $('#labid').focus();
  return false;
 }
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'First='+ First + '&Last='+ Last + '&Compony='+ Compony + '&Email='+ Email + '&Password='+ Password + '&country='+ country + '&state='+ state + '&city='+ city + '&Mobile='+ Mobile + '&Pin='+ Pin + '&Address='+ Address;
  
if(First==''|| Last=='')
{
alert("Please Fill All cheked compony name");
}
else
{
	// alert(dataString);
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "ragistrationData.php",
data: dataString,
cache: false,
success: function(result){
 //window.location.reload();
alert(result);
location.reload();
// $("#loginmodelR").modal('hide');

}
});
}
return false;
});
});

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function(){
$("#UserLoginN").click(function(){
										 
var loginemail = $("#loginemail").val();  //alert(PicName);
var loginpwd = $("#loginpwd").val(); //alert(PicDate);
 // Returns successful data submission message when the entered information is stored in database.
var dataString = 'loginemail='+ loginemail + '&loginpwd='+ loginpwd ;
 // alert(dataString);
if(First==''|| Last=='')
{
alert("Please Fill All cheked compony name");
}
else
{
// AJAX Code To Submit Form.
$.ajax({
type: "POST",
url: "ragistrationData.php",
data: dataString,
cache: false,
success: function(result){ 
 alert(result);
location.reload();
//window.open('index.php','_self');
// $("#loginmodel").modal('hide');
 
}
});
}
return false;
});
});