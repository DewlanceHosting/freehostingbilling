<?php  include('fn/connect.php');
  $q = intval($_GET['q']);
     
 //$querydata= mysqli_query($con,"SELECT * FROM state");
     $content = "SELECT * FROM state where countryid='$q'";
					  $cat_quer = mysqli_query($con,$content) ;
					  ?> <option value="1">Select State</option>
					  <?php
					while($mycat_row = mysqli_fetch_array($cat_quer)){  echo $mycat_row['statename'];
					?>
                    <option value="<?php echo $mycat_row['id']; ?>"><?php echo $mycat_row['statename']; ?></option><?php }?>
					