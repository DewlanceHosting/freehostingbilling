 <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
     <?php include_once("tiltlechange.php"); ?>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
  </head>
  <body>
  
    <?php include_once("header.php"); ?>
  
  <!--headerpart-end-->
  


<section class="clientdashh">
<div class="container">

<div class="listservisdata">
<h3>List of Services</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Package Name</th>
      <th>Date of Registration</th>
      <th>Next Due</th>
      <th>Status</th>
       <th>Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4>HW Infotech</h4>
      <p>www.dewlance.com</p>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Active</td>
       <td>Hosting</td>
    </tr>
    
    <tr>
      <td>
      <h4>HW Infotech</h4>
      <p>www.dewlance.com</p>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Active</td>
       <td>Hosting</td>
    </tr>
    
    <tr>
      <td>
      <h4>HW Infotech</h4>
      <p>www.dewlance.com</p>
      </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Active</td>
       <td>Hosting</td>
    </tr>
    
    
  </tbody>
</table>
</div>

</div>


<div class="listservisdata">
<h3>List of Paid or Unpaid Invoice</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Invoice </th>
      <th>Creation Date</th>
      <th>Due Date</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4>AX - Link to Invoice</h4>
       </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Paid</td>
    </tr>
    
<tr>
      <td>
      <h4>AX - Link to Invoice</h4>
       </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Unpaid</td>
    </tr>
    
    <tr>
      <td>
      <h4>AX - Link to Invoice</h4>
       </td>
      <td>18/04/2013</td>
      <td>18/04/2013</td>
      <td>Refunded</td>
    </tr>
    
  </tbody>
</table>
</div>

</div>



<div class="listservisdata">
<h3>List of Ticket</h3>
<div class="table-responsive">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Invoice </th>
      <th>Creation Date</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
      <h4>AX - Link to Ticket</h4>
       </td>
      <td>18/04/2013</td>
      <td>Replied</td>
    </tr>
    
<tr>
      <td>
      <h4>AX - Link to Ticket</h4>
       </td>
      <td>18/04/2013</td>
      <td>Answered</td>
    </tr>
    
    <tr>
      <td>
      <h4>AX - Link to Ticket</h4>
       </td>
      <td>18/04/2013</td>
      <td>Customer Replied</td>
    </tr>
    
    
    <tr>
      <td>
      <h4>AX - Link to Ticket</h4>
       </td>
      <td>18/04/2013</td>
      <td>Hold</td>
    </tr>
    
  </tbody>
</table>
</div>

</div>


</div>

</section>


 
 
 <!--home--contant----end--->
  <?php include_once('footer.php'); ?>
 <!----------footer---end------->
 

  

  </body>
</html>