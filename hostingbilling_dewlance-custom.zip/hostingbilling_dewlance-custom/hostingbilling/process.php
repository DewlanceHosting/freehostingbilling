<?php
if (isset($_POST['submit'])) { 
	
if (isset($_POST['domainAdd'])) {  
    $product_name = $_POST['1'];
    $product_currency = 'USD';
	  $cycle_amount = $_POST['prs'];
	 $cycle = 'Y';
}else{ 
	$product_name = $_POST['1'];
    $product_currency = 'USD';
	 $cycle_amount = $_POST['prs'];
	 
     if ($_POST['bill'] == 'Quarterly') { 
        $cycle = 'M';
		$total_cycle = '4';
    } else if ($_POST['bill'] == 'Monthly') { 
        $cycle = 'M';
		$total_cycle = '1';
    } else if ($_POST['bill'] == 'Yearly') { 
        $cycle = 'Y';
    } 
}	 
    
    //Here we can use paypal url or sanbox url.
    $paypal_url = $_POST['paypalurl'];
    //Here we can used seller email id. 
    $merchant_email = $_POST['paypalemailid'];
    //here we can put cancle url when payment is not completed.
    $cancel_return = "http://dewlance.xyz/hostingbilling/orderreviews.php";
    //here we can put cancle url when payment is Successful.
    $success_return = "http://dewlance.xyz/hostingbilling/success.php";
    ?>
    <div style="margin-left: 38%"><img src="images/ajax-loader.gif"/><img src="images/processing_animation.gif"/></div>
    <form name = "myform" action = "<?php echo $paypal_url; ?>" method = "post" target = "_top">
        <input type="hidden" name="cmd" value="_xclick-subscriptions">
        <input type = "hidden" name = "business" value = "<?php echo $merchant_email; ?>">
        <input type="hidden" name="lc" value="IN">
        <input type = "hidden" name = "item_name" value = "<?php echo $product_name; ?>">
        <input type="hidden" name="no_note" value="1"> 
        
        <input type="hidden" name="a3" value="<?php echo $cycle_amount; ?>">
         <?php if (!empty($total_cycle)) { ?>
           <input type="hidden" name="p3" value="<?php echo $total_cycle; ?>">
        <?php }else{?>
        <input type="hidden" name="p3" value="1">
		<?php } ?> 
        <input type="hidden" name="t3" value="<?php echo $cycle; ?>">
        <input type="hidden" name="currency_code" value="<?php echo $product_currency; ?>">
        <input type = "hidden" name = "cancel_return" value = "<?php echo $cancel_return ?>">
        <input type = "hidden" name = "return" value = "<?php echo $success_return; ?>">
        <input type="hidden" name="bn" value="PP-SubscriptionsBF:btn_subscribeCC_LG.gif:NonHostedGuest">
    </form>
    <script type="text/javascript">
        document.myform.submit();
    </script>
<?php }
?>