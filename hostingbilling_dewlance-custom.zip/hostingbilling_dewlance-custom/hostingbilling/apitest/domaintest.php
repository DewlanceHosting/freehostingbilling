<meta http-equiv="refresh" content="800" />
<meta name="revisit" content="1 day" /><style type="text/css">.ad{}.bar4{background-color:#399;color:#ffffff;text-bold:1px 1px #fff;link-color:1px 1px #ffffff;padding:4px;}.bmenu{color:#fff;background-color:#4b4d4d;padding-top:5px;padding-bottom:5px;margin-top:1px;margin-bottom:1px;border-bottom:1px outset #676a6a;}.hidex{}.msgbody{background:#fffafa;padding:5px;display:block;border:dotted 1px #cae1ff;margin:5px;color:black;border-radius:4px;}.msgfoot{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;padding:5px 5px 5px 5px;border-radius:4px;margin:4px 4px 4px 4px;}.msgtitle{color:#ffffff;background-color:#538dc3;background-repeat:no-repeat;background-position:right 50%;text-align:left;padding:3px;font-weight:bold:padding-left:5px;margin:4px 4px 4px 4px;border:1px solid #538dc3;border-radius:4px;}.rana2{padding:5px 5px 5px 8px;background:#000000;border-top:1px solid #ccc;border-bottom:1px solid #ccc;}.rmenu{background:#f5e9eb;border:1px solid #e2c0c7;margin:3px;padding:4px;border-radius:4px;}.xlist{}.xlist2{}    </style>        <link rel="shortcut icon" href="http://icons.iconarchive.com/icons/iconexpo/speech-balloon-orange/16/speech-balloon-orange-l-icon.png"/>    <style media="all,handheld" type="text/css" style="display:none">body{margin:0px;padding:0px;font-size:18px;font-family:Verdana,Arial,Helvetica,sans-serif;background-color:#ffffff;min-width:100%;}img{border-style :none;vertical-align:middle;max-width:100%;}.a a:link,.a a:visited{color :#ffffff;text-decoration :none;}a:link{text-decoration:none;}a:link,a:active,a:visited{color :#3399FF;text-decoration :none;}a:hover,a:focus{font-width:bold;text-shadow:0 0 5px #00076e;}input[type='submit'],input[type='button']{background-color:#3BB9FF;color:#ffffff;border:1px lightsteelblue;solid;padding-top:4px;padding-bottom:4px;padding-left:10px;padding-right:10px;border-radius:4px;}input,select{border:1px #3399FF solid;color:#000;font-weight:bold;background-color:#FFFAFA;padding:4px;margin:2px;border-radius:4px;}input:hover,input:focus,textarea:focus,textarea:hover{-moz-box-shadow:0 0 10px #6699ff;-webkit-box-shadow:0 0 10px #6699ff;box-shadow:0px 0px 10px #6699ff;}textarea{color:#333;background:#FFFAFA;width:85%;height:90px;margin:2px;padding:4px;font-family:Arial;font-size:13px;font-weight:bold;border:1px solid #333333;border-radius:4px;}img{border-style :none;vertical-align:middle;max-width:100%;}body{margin:0px;padding:0px;}.gmenu{background-color:#e9e9e9;margin:0;padding:2px;border-radius:4px;}.gmenu{color :#75bf00;background-color :#fafff0;margin-top :1px;margin-bottom :1px;padding :2px;border :1px solid #d4eba1}.gmenu a{color :#6db900;border-bottom :1px dotted #cfe798;}.gmenu a:hover{color :# 92e31d;border-bottom :1px dotted #e3f0c5;}.menu{background-color:#ffffff;border-left:1px solid #e9e9e9;border-right:1px solid #e9e9e9;border-bottom:1px solid #e9e9e9;margin:0px;padding:5px 5px 5px 5px;}.list1{background-color:#ffffff;padding:4px;border:1px solid #e9e9e9;}.list2{background-color:#ffffff;padding:4x;}.ad{border:1px solid lightsteelblue;padding:2px;margin-top:1px;margin-left:2px;margin-right:2px;}.ad a:link,.a a:visited{color :red;text-decoration :none;target-new:tab!important;}.ad a{target-new:tab!important;}.ad img{vertical-align:middle;padding-right:4px;max-width:100%;}.ad a:hover,.ad a:focus{color :#000000;}.lines{border-top:1px solid lightsteelblue;}.bordersolid{border-top:1px solid lightsteelblue;}.lined{border-top:1px dotted lightsteelblue;}.pad4{padding:5px;}.ftext img{max-width:100%;display:blok;margin-top:3px;margin-bottom:3px;border :1px solid #dfdfdf;background-color :#f8f8f8;padding :3px;}.adz{border:1px solid lightsteelblue;padding:2px;margin-top:1px;display:none;}.nfooter,.rana{background-color:#333333;padding:4px;font-weight:bold;color:#ffffff;}.rana a:link,rana a:visited{color:#ffffff;font-weight:bold:padding-left:5px;}.mainbox{padding-left:2px;padding-right:2px}.mainblok{border:1px solid #3BB9FF;padding:0px;margin-left:0px;margin-right:0px;margin-top:1px;margin-bottom:0px;}.nfooter a{color:#ffffff;}.clip{color :#459bb1;border :1px solid #dfdfdf;font-size :x-small;background-color :#f8f8f8;padding :4px 4px 8px;}.end{text-align :center;}.hdr{background-color:#7797ac;color:#ffffff;border:1px solid #5a7f97;padding:4px 4px 4px 4px;}.hdr2{background-color:#7797ac;color:#ffffff;text-shadow:#ffffff 0px 1px 0px;border:1px solid #5a7f97;padding:4px 1px 4px 1px;}.line{padding:10px}.sec{background-color:#ffffff;margin-left:2px;margin-right:2px;margin-bottom:11px;border:1px solid #7797ac;}.tr{border-bottom:1px solid #e7e7e7;}.icon{padding:1px}.td{border-left:1px solid #e7e7e7}.tr2{border-bottom:1px dashed #bbb;padding:4px;color :red;background-color:#fff0d2;}.tr3{border-bottom:1px dashed #bbb;padding:4px;color :red;background-color:#fff;}.line{padding:10px;}.line a{color:#ffffff}.notice{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;padding:5px 5px 5px 5px;}.omenu{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;padding:5px 5px 5px 5px;border-radius:4px;margin:4px 4px 4px 4px;}.quote{color:#333333;border:1px solid #e6b868;background-color:#fff5bc;margin:1px 1px 2px;padding:5px 5px 5px 5px;display :block;text-align:center;vertical-align:middle;}.wcode{background:#fffafa;padding:5px;display:block;border:dotted 1px #cae1ff;margin:5px;color:black;border-radius:4px;}.wcode input{height:20px;width:85%;}.nexzz{background-image :url(http://nasirnobin.xtgem.com/trickbd_css_by_nasir/);}.line{padding:10px}.frame{padding:2px;border:1px solid #e7e7e7;}.menu3{color:#333333;border:1px solid #93db2e;background-color:#c1ffc1;padding:5px 5px 5px;}    </style>    <style>    .xlist { padding: 5px 5px 5px 8px; background: #f4f4f4 url(/images/bgr.png) repeat-x top; border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; }    .xlist2 { padding: 5px 5px 5px 8px; background: #ffffff url(/images/bgr.png) repeat-x top; border-top: 1px solid #ffffff; border-bottom: 1px solid #ffffff; }    .nfooter{ border: 1px solid #000000; padding: 4px 4px 4px 4px; margin: -1px -1px 0px -1px; }    .hdn {display: none;}            .download_blue a { display: block;  color: #ffffff; width: 250px;  font: 17px Helvetica, Verdana, sans-serif; text-decoration: none; text-align: center; text-transform: uppercase;  background: #00b7ea;    padding: 5px; margin: 1px;  -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;}            .download_green a { display: block;  color: #ffffff; width: 250px;  font: 17px Helvetica, Verdana, sans-serif; text-decoration: none; text-align: center; text-transform: uppercase;  background: #7fbf4d;    padding: 5px; margin: 1px;  -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;}            </style>
<b>Check Domain Availability</b>
 <form action="" method="post">
<table>
<tr>
<td>Enter Domain Name:</td>
<td><input type="text" name="domain_name" /></td>
<td>
<select name="ubhbz">
<option value=".com">.com</option>
<option value=".xyz">.xyz</option>
<option value=".net">.net</option>
<option value=".org">.org</option>
<option value=".tk">.tk</option>
<option value=".ml">.ml</option>
<option value=".cf">.cf</option>
<option value=".ga">.ga</option>
<option value=".gq">.gq</option>
<option value=".com.bd">.com.bd</option>
<option value=".net.bd">.net.bd</option>
</select>
 
</td>
<tr>
<td align="right" colspan="3"><input type="submit" name="check" value="Check" /></td>
</tr>
</tr>
</table>
</form>
<?php
 
if(isset($_POST['check'])) {
 
 if (!empty($_POST['domain_name'])){
 $name_domain = trim($_POST['domain_name']).$_POST['ubhbz'];
 $response = @dns_get_record($name_domain, DNS_ALL);
 if(empty($response)){
 echo "<h2 style='color:green;' >Domain $name_domain is available.</h2>";
 
 }else{
 echo "<h2 style='color:red;'>Sorry, domain $name_domain has taken.</h2>";
 }
 }
 else {
 echo "<h2 style='color:red;'>Error: Domain name can not be left empty.</h2>";
 }
}
?>