<table background="">
  <tr>
    <th>user id</th>
    <th>name</th>
    <th>domain</th>
    <th>email id</th>
  </tr>
<?
    $user = "root";
    $token = "YG6QPHQ4D5ZKNIIN7LS01929Y049502O";
 
   // $query = "https://167.160.174.209:2087/json-api/listaccts?api.version=1";
 $query = "https://167.160.174.209:2087/json-api/cpanel?cpanel_jsonapi_user=jjitendre&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=DiskUsage&cpanel_jsonapi_func=fetchdiskusagewithextras";
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
 
    $header[0] = "Authorization: whm $user:$token";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
 
       echo  $result = curl_exec($curl);
 
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_status != 200) {
        echo "[!] Error: " . $http_status . "returned\n";
		} else {
        $json = json_decode($result);
		// print_r($json);
        echo "[+] Current cPanel users on the system:\n";
        foreach ($json->{'cpanelresult'}->{'data'} as $userdetails) { print_r($userdetails);?> 
  <tr>
    <td><?php echo $userdetails->{'quotalimit'}; ?></td>
    <td><?php echo $userdetails->{'quotaused'}; ?></td>
    <td><?php echo $userdetails->{'user_contained_usage'}; ?></td>
    <td><?php echo $userdetails->{'usage'}; ?></td>
    
  </tr> 
	<?php	if($userdetails->{'uid'} == 1002){
		echo "\t" .$userdetails->{'user'}. "\n";
		
		}         }    } 
    curl_close($curl); 
?>
</table>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>