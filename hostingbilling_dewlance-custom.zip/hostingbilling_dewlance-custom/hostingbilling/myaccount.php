  <?php  session_start();   error_reporting(0); if( ( empty($_SESSION['EmailIdSession'])) && ( empty($_SESSION['userpassSession']))){  header('location:index.php');}?>
  <?php  

 // session_start();

include_once('fn/connect.php');



?>

<!DOCTYPE html>

<html lang="en">

  <head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

     <?php include_once("tiltlechange.php"); ?>

    <!-- Bootstrap -->

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="css/style.css" rel="stylesheet" type="text/css">

  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="js/bootstrap.min.js" type="text/javascript"></script>

    <script src="js/custom.js" type="text/javascript"></script>

  </head>

  <body>

  

    <?php include_once("header.php"); ?>

  

  <!--headerpart-end-->

  

<?php $uid = $_SESSION['userid'];

  

//$pWord = md5($_POST['Old']);  `fname`, `lname`, `cmpname`, `email_id`, `userpass`, `add`, `contryid`, `stateid`, `cityid`, `pin`, `mobile`, `status`, `ragdate

$qry = mysqli_query($con,"SELECT * FROM user_ragistration WHERE id='$uid'"); $rowdata = mysqli_fetch_array($qry);  $contt=$rowdata['contryid']; $stateid=$rowdata['stateid']; $cityid=$rowdata['cityid'];?>



<div class="clientprofile">

<div class="container">

<div class="row">

<div class="col-md-offset-2 col-md-8 col-md-offset-2">

<h3>My Account</h3>



<div class="proftabb"> 

 

<div class="form-group">

    <label for="Name">First Name :</label>

    <input type="text" class="form-control" value="<?php echo $rowdata['fname']; ?>" id="Name">

  </div>

  <div class="form-group">

    <label for="Name">Last Name :</label>

    <input type="text" class="form-control" value="<?php echo $rowdata['lname']; ?>" id="Name">

  </div>



  <div class="form-group">

    <label for="email">Email :</label>

    <input type="email" class="form-control"  value="<?php echo $rowdata['email_id']; ?>" id="email">

  </div>

  <div class="form-group">

    <label for="Address">Your Address :</label>

    <textarea class="form-control"  id="addd" placeholder="Address"><?php echo $rowdata['add']; ?></textarea>

  </div> 

  

   <div class="form-group">

    <label for="Phone">Country :</label>

    <select  class="form-control" id="sid"  name="compony" onChange="shoafdaswUser();">

    <?php  $conte= mysqli_query($con,"SELECT * FROM   country  where id='$contt'"); $r=mysqli_fetch_array($conte); ?>

 <option value="<?php   if(isset($rowdata['contryid'])){ echo $r['id'];}?>"> <?php   if(isset($rowdata['contryid'])){ echo $r['country'];}else{echo  "Select Country";}  ?> </option>

                      <?php  $content = "SELECT * FROM   country "; 

					  $cat_quer = mysqli_query($con,$content) ; 

					while($mycat_row = mysqli_fetch_array($cat_quer)){ 

					$patientid=$mycat_row['id'];?>

                      <option value="<?php  echo $mycat_row['id'];?>">

                      <?php  echo $mycat_row['country'];?>

                      </option>

                      <?php }?>

                    </select>

  </div>

  

  

  
      <?php  $conts = mysqli_query($con,"SELECT * FROM   state  where id='$stateid'"); $s=mysqli_fetch_array($conts); ?>
  <div class="form-group">

    <label for="City">State :</label>

     <select  class="form-control" id="state1"  name="state" onChange="showUser1();">  
 <option value="<?php  if(isset($rowdata['stateid'])){ echo $s['id'];} ?>"> <?php   if(isset($stateid)){ echo $s['statename'];}else{echo  "Select";}  ?> </option>
 
                    </select>

  </div>

  
   <?php  $contc = mysqli_query($con,"SELECT * FROM city where id='$cityid'"); $c=mysqli_fetch_array($contc); ?>
  <div class="form-group">

    <label for="Country">City :</label>

     <select  class="form-control"  name="city1" id="city1" >

   <option value="<?php  if(isset($rowdata['cityid'])){ echo $c['id'];}?>"> <?php   if(isset($cityid)){ echo $c['city'];}else{echo  "Select";}  ?> </option>

                    </select>

  </div> 
  <div class="form-group">

    <label for="Code">Pin Code :</label>

    <input type="text" class="form-control"  value="<?php echo $rowdata['pin']; ?>" id="Pin">

  </div> 

    <button type="button" class="btn btn-danger" onClick="UpdateFormData();">Update &amp; Save</button>  

</div>
 
</div>

</div> 

</div>

</div>

  

  <script> 

  function shoafdaswUser() {

    var sid = $("#sid").val(); //alert(sid); 

    $.post("getstate1.php", { sid: sid },

    function(data) {

	 $('#state1').html(data);

	 $('#myForm')[0].reset();

    });

}

 

</script>

<script> 

function showUser1() {

    var state1 = $("#state1").val();// alert(state1); 

    $.post("getcity1.php", { state1: state1 },

    function(data) {

	 $('#city1').html(data);

	 $('#myForm')[0].reset();

    });

}
 
</script>



<script>

function UpdateFormData() {

    var Name = $("#Name").val();  //alert(Name);

    var email = $("#email").val(); //alert(email);

    var Address = $("#addd").val(); // alert(Address);

	var Pin = $("#Pin").val();  //alert(Pin);

	 var sid = $("#sid").val(); //alert(sid);

    var state1 = $("#state1").val();  //alert(state1);

	var city1 = $("#city1").val(); // alert(city1);

   // var status = $("input[type=radio]:checked").val();

    $.post("passcheck.php", { Name: Name, email: email, Address: Address, Pin: Pin, sid: sid, state1: state1, city1: city1 },

    function(data) {

	 $('#results').html(data);

	 alert(data);

	 $('#myForm')[0].reset();

    }); 
}

</script> 
 

 <!--home--contant----end--->

  <?php include_once('footer.php'); ?>

 <!----------footer---end------->

 



  



  </body>

</html>